"""Read saved text/metadata only. Never starts SCF, inference, or density analysis."""
import csv, hashlib, io, json, re, shutil, statistics, zipfile
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
Q = ROOT / 'qe_native_20261103'
S = Q / 'density_fourier_20261115'
V = Q / 'b_vacancy_reinject_20261117'
for name in ['data', 'sources', 'figures', 'existing_figures', 'raw_logs', 'model_configs']:
    (OUT / name).mkdir(exist_ok=True)
def load(p): return json.loads(Path(p).read_text())
def rows(p): return list(csv.DictReader(Path(p).open()))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_json(name, value): (OUT/name).write_text(json.dumps(value, indent=2)+'\n')
def write_csv(name, values):
    fields=list(dict.fromkeys(k for v in values for k in v))
    with (OUT/name).open('w') as f:
        w=csv.DictWriter(f, fieldnames=fields);w.writeheader();w.writerows(values)
def table(headers, values):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+
                     ['| '+' | '.join(str(v) for v in r)+' |' for r in values])
audits=[]
def audit_qe(p, n):
    p=Path(p); t=p.read_text(errors='replace')
    found=re.findall(r'convergence has been achieved in\s+(\d+) iterations', t)
    assert found and int(found[-1]) == n, (str(p), found, n)
    assert 'JOB DONE.' in t
    audits.append(dict(kind='QE',source=str(p.relative_to(ROOT)),sha256=sha(p),iterations=n))
    dest=OUT/'raw_logs'/str(p.relative_to(ROOT));dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)

manifest=load(S/'manifest.json')['cases']
manifest=[c for c in manifest if c['id']!='B298_mvac02']
assert len(manifest)==12
case_by_id={c['id']:c for c in manifest}
summary=[r for r in rows(S/'analysis/case_summary.csv') if r['case'] in case_by_id]
pristine={r['system']:r for r in rows(S/'author_handoff_20261117/reinjection_results.csv')}
vacancy={r['case']:r for r in rows(V/'report/results.csv')}
vacmanifest={c['name']:c for c in load(V/'manifest.json')['cases']}
reinjections=load(V/'summary.json')
assert reinjections['status']=='COMPLETE'
def label(c):
    if not c['vacancies']:return c['system']+' pristine'
    short=c['id'].replace('B298_','');v=vacancy[short]
    return f"B298, {v['vacancies']} "+('vacancy' if int(v['vacancies'])==1 else 'vacancies')+f", set {v['set']}"
results=[]
for r in summary:
    c=case_by_id[r['case']]; nA=int(r['ATOMIC_steps']);nM=int(r['MALA_steps'])
    nR=int(pristine[c['system']]['reinjection_iterations']) if not c['vacancies'] else int(vacancy[c['name']]['reinjection_steps'])
    for b,n in [('mala',nM),('atomic',nA)]:audit_qe(Path(c[b])/'scf.out',n)
    result=dict(label=label(c),case=c['id'],snapshot=c['snapshot'],vacancies=c['vacancies'],
        set=vacancy[c['name']]['set'] if c['vacancies'] else '',removed_indices_zero_based=c['removed_indices'],
        atoms=r['atoms'],electrons=r['electrons'],MALA_steps=nM,ATOMIC_steps=nA,reinjection_steps=nR,
        iterations_saved=nA-nM,ATOMIC_relative_reduction_percent=100*(nA-nM)/nA,
        reinjection_referenced_reduction_percent=100*(nA-nM)/(nA-nR),cutoffs_Ry=r['cutoffs_Ry'],
        grid=r['grid'],conv_thr_Ry_per_cell=r['conv_thr_Ry'],
        MALA_final_energy_Ry=r['MALA_final_energy_Ry'],ATOMIC_final_energy_Ry=r['ATOMIC_final_energy_Ry'],
        absolute_MALA_ATOMIC_endpoint_difference_Ry=abs(float(r['final_energy_difference_Ry'])),
        MALA_ATOMIC_final_density_relative_L2=r['final_density_relative_L2'],
        initial_MALA_relative_L2_percent=100*float(r['initial_MALA_global_relative_L2']),
        initial_ATOMIC_relative_L2_percent=100*float(r['initial_ATOMIC_global_relative_L2']),
        first_MALA_relative_L2_percent=100*float(r['first_MALA_global_relative_L2']),
        first_ATOMIC_relative_L2_percent=100*float(r['first_ATOMIC_global_relative_L2']),
        original_case_json=c['case_json'],source_mala=c['mala'],source_atomic=c['atomic'])
    results.append(result)
    for ext in ['pdf','png']:
        for name in ['fourier_maps','fourier_spectra','scf_convergence']:
            src=S/'analysis'/c['id']/f'{name}.{ext}'
            dest=OUT/'existing_figures'/c['id']/src.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(src,dest)
    for n in ['fourier_shells.npz','fourier_plane.npz']:
        dest=OUT/'data'/c['id'];dest.mkdir(exist_ok=True);shutil.copy2(S/'analysis'/c['id']/n,dest/n)
    dest=OUT/'sources'/c['id'];dest.mkdir(exist_ok=True)
    shutil.copy2(c['case_json'],dest/'case.json')
    for b in ['mala','atomic']:shutil.copy2(Path(c[b])/'input.in',dest/f'{b}.in')
for c in load(V/'manifest.json')['cases']:
    n=int(vacancy[c['name']]['reinjection_steps'])
    f=V/'run-856943'/c['name']/'output.out'
    if not f.exists():
        matches=list((V/'run-856943'/c['name']).rglob('scf.out'));assert len(matches)==1;f=matches[0]
    audit_qe(f,n)
    shutil.copy2(c['input_template'],OUT/'sources'/('B298_'+c['name'])/'reinjection.in')
for system,r in pristine.items():
    source=Path(r['source']);d=load(source)
    # The native own-density controls are full SCFs, independent of first-response replays.
    matches=list(source.parent.rglob('*.out'))
    matches=[p for p in matches if re.search(r'convergence has been achieved in\s+3 iterations',p.read_text(errors='replace'))]
    assert len(matches)==1,(system,[str(p) for p in matches]);audit_qe(matches[0],3)
    shutil.copy2(source,OUT/'sources'/f'{system}_reinjection_results.json')
results.sort(key=lambda r: (['Al298','Al933','B298'].index(case_by_id[r['case']]['system']),int(r['vacancies']),int(r['set'] or 0)))
write_csv('data/QE_iterations_and_improvements.csv',results)
for f in ['density_errors.csv','fourier_metrics.csv','scf_trajectories.csv','charge_and_positivity.csv']:
    write_csv('data/'+f,[r for r in rows(S/'analysis'/f) if r['case'] in case_by_id])
for f in ['results.csv','group_consistency.csv','SCF_trajectories.csv']:
    shutil.copy2(V/'report'/f,OUT/'data'/('vacancy_reinjection_'+f))
for f in ['1_vacancies','2_vacancies','4_vacancies']:
    for ext in ['pdf','png']:shutil.copy2(V/'report'/f'{f}.{ext}',OUT/'existing_figures'/f'QE_reinjection_{f}.{ext}')
write_json('sources/QE_manifest_retained.json',manifest)
for src in [V/'verification.json',V/'summary.json',V/'manifest.json']:
    shutil.copy2(src,OUT/'sources'/('vacancy_reinjection_'+src.name))

# Checkpoint archive identities: all metadata only; no model is evaluated here.
models=load(S/'author_handoff_20261117/model_metadata_and_hashes.json')
model_rows=[]
for m in models:
    sizes=m['network']['layer_sizes'];p=m['prefix'];sys=m['system']
    for suffix in ['.params.json','.info.json']:
        src=ROOT/(p+suffix)
        if src.exists():shutil.copy2(src,OUT/'model_configs'/src.name)
    specs=dict(system=sys,input_features=sizes[0],hidden_layers=' → '.join(map(str,sizes[1:-1])),
        output_LDOS_channels=sizes[-1],full_layer_sizes=' → '.join(map(str,sizes)),
        trainable_parameters_from_layer_sizes=sum((a+1)*b for a,b in zip(sizes[:-1],sizes[1:])),
        twojmax=m['descriptors']['bispectrum_twojmax'],cutoff_A=m['descriptors']['bispectrum_cutoff'],
        switchflag=m['descriptors']['bispectrum_switchflag'],activation=m['network']['layer_activations'],
        LDOS_offset_eV=m['targets']['ldos_gridoffset_ev'],LDOS_spacing_eV=m['targets']['ldos_gridspacing_ev'],
        LDOS_channels=m['targets']['ldos_gridsize'],
        LDOS_last_eV=m['targets']['ldos_gridoffset_ev']+(m['targets']['ldos_gridsize']-1)*m['targets']['ldos_gridspacing_ev'],
        recorded_Te_K={'Al298':299.98637294316444,'Al933':931.5366317708792,'B298':298.0}[sys],
        checkpoint_prefix=p,network_SHA256=m['sha256'][Path(p).name+'.network.pth'],
        RODARE_record='https://rodare.hzdr.de/record/'+('3746' if sys=='B298' else '2725'))
    model_rows.append(specs)
    for name,expected in m['sha256'].items():
        file=ROOT/Path(p).parent/name
        # Large weights already have verified audit identities; recheck params/scalers/info only.
        if not name.endswith('.network.pth'):assert sha(file)==expected,(file,expected)
archives=[]
for path,expected in [('downloads/Al_298K_0.zip','fa0c7db7acc6fd01c978195428acd524'),
                      ('downloads/Al_933K_liquid_record2725.zip','397f2de4df02b63ee1c6023591b8c144'),
                      ('boron_298K/source/models.zip','988242476b02f61228f6833cefc0fb7b')]:
    p=ROOT/path;digest=hashlib.md5(p.read_bytes()).hexdigest();assert digest==expected
    archives.append(dict(path=path,published_MD5=expected,local_MD5=digest))
with zipfile.ZipFile(ROOT/'downloads/Al_933K_liquid_record2725.zip') as z:
    p=next(n for n in z.namelist() if n.endswith('.params.json'))
    assert json.loads(z.read(p))['network']['layer_sizes']==[91,4000,4000,4000,250,250]
    assert hashlib.sha256(z.read(p)).hexdigest()==models[1]['sha256']['Al_933K_liquid.params.json']
audit=load(ROOT/'933K_liquid/provenance_audit_20261021/job-743314/audit.json')
write_json('sources/Al933_existing_tensor_audit.json',audit['checkpoints']['liquid'])
write_json('data/checkpoint_archive_checks.json',archives)
write_json('data/model_metadata_and_hashes.json',models)
write_csv('data/model_specifications.csv',model_rows)

# CP2K: reparse saved stdout, retain exact cutoff/Hamiltonian identities.
CP=load(ROOT/'reports/mala_cp2k_study_20261102/compiled_data.json')
cp_records=[];cp_curves=[]
def cp_parse(path):
    p=Path(path);p=p if p.is_absolute() else ROOT/p
    t=p.read_text(errors='replace');h=[]
    for line in t.splitlines():
        s=line.split()
        if len(s)==7 and s[0].isdigit() and s[1].endswith('/Diag.'):
            h.append(dict(iteration=int(s[0]),residual=float(s[4]),energy_Ha=float(s[5])))
    n=re.findall(r'SCF run converged in\s+(\d+) steps',t)
    assert n and len(h)==int(n[-1]),(p,n,len(h))
    assert h[-1]['iteration']==len(h)
    audits.append(dict(kind='CP2K',source=str(p.relative_to(ROOT)),sha256=sha(p),iterations=len(h)))
    dest=OUT/'raw_logs'/str(p.relative_to(ROOT));dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    return h
def cp_add(case,system,cutoff,hamiltonian,threshold,branch,path,source_note=''):
    h=cp_parse(path)
    p=Path(path);p=p if p.is_absolute() else ROOT/p
    inp=p.parent/'input.inp'
    if not inp.exists():inp=p.with_suffix('.inp')
    if inp.exists():
        text=inp.read_text();m=re.search(r'^\s*CUTOFF\s+(\d+)',text,re.M)
        assert m and int(m[1])==cutoff,(inp,m[1] if m else None,cutoff)
        dest=OUT/'sources/CP2K_inputs'/str(inp.relative_to(ROOT));dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(inp,dest)
    r=dict(case=case,system=system,cutoff_Ry=cutoff,Hamiltonian=hamiltonian,EPS_SCF=threshold,
        branch=branch,iterations=len(h),first_crossing_1e5=next((p['iteration'] for p in h if p['residual']<1e-5),None),
        final_residual=h[-1]['residual'],final_energy_Ha=h[-1]['energy_Ha'],source_log=str(path),source_note=source_note,
        source_input=str(inp) if inp.exists() else 'unavailable',source_input_SHA256=sha(inp) if inp.exists() else '')
    cp_records.append(r)
    for p in h:cp_curves.append(dict(case=case,branch=branch,**p))
for sys,key,folder in [('Al298','al298','298K_0/broyden800_20261021/run-743428'),
                       ('Al933','al933','933K_liquid/cutoff800_20261021/run-743403')]:
    case=sys+'_GTH800'
    for name,b in [('MALA','seeded'),('ATOMIC','atomic')]:
        cp_add(case,sys,800,'GTH-PBE-q3 / PBE',1e-5,name,CP[key][b]['path'])
    cp_add(case,sys,800,'GTH-PBE-q3 / PBE',1e-5,'QE_reference',CP['qe'][sys]['path'],
           'QE-reference LDOS integrated to scalar density; original dense-mesh reference, not native Gamma QE restart')
    if sys=='Al298':
        cp_add(case,sys,800,'GTH-PBE-q3 / PBE',1e-5,'CP2K_reinjected',folder+'/positive/output.out',
               'Own-Hamiltonian converged MALA-seeded endpoint, native 288^3 precision-reheadered cube; not ATOMIC endpoint')
    else:
        cp_add(case,sys,800,'GTH-PBE-q3 / PBE',1e-5,'CP2K_reinjected',CP['reinject_histories']['al933']['path'],
               'Own-Hamiltonian converged ATOMIC endpoint')
for b,key in [('ATOMIC','b800_atomic'),('QE_reference',None)]:
    v=CP[key] if key else CP['qe']['B298']
    cp_add('B298_GTH800','B298',800,'GTH-PBE-q3 / PBE',1e-5,b,v['path'])
for b,key in [('MALA','mala'),('ATOMIC','atomic')]:
    cp_add('B298_GTH8000_historical','B298',8000,'GTH-PBE-q3 / PBE',1e-5,b,CP['b8000'][key]['path'])
cp_add('B298_GTH8000_historical','B298',8000,'GTH-PBE-q3 / PBE',1e-5,'CP2K_reinjected',CP['reinject_histories']['b_reinjected']['path'],
       'Later matched-settings producer/control; cross-allocation iteration comparison only')
up=ROOT/'298K_0/upf_pbesol_inputs_20261108'
for b,folder in [('ATOMIC','atomic'),('MALA','mala'),('QE_reference','qe'),('CP2K_reinjected','cp2k')]:
    cp_add('Al298_UPF800','Al298',800,'NC-UPF Al.sr-pbesol.upf / PBEsol',1e-5,b,up/'runs'/folder/'output.out')
for r in rows(ROOT/'reports/mala_cp2k_study_20261102/branch_records.csv'):
    if r['system']=='B298' and r['case'] in ['vac02','vac03','vac06','mvac04','v4_c1','v4_c2'] and r['branch'] in ['mala','atomic','CP2K_reinjected']:
        cp_add('B298_'+r['case'],'B298',800,'GTH-PBE-q3 / PBE',1e-7,
               {'mala':'MALA','atomic':'ATOMIC','CP2K_reinjected':'CP2K_reinjected'}[r['branch']],r['source_log'])
cp_summary=[]
for case in dict.fromkeys(r['case'] for r in cp_records):
    rs=[r for r in cp_records if r['case']==case];d={r['branch']:r for r in rs}
    nA=d['ATOMIC']['iterations'];nM=d.get('MALA',{}).get('iterations');nR=d.get('CP2K_reinjected',{}).get('iterations');nQ=d.get('QE_reference',{}).get('iterations')
    cp_summary.append(dict(case=case,system=rs[0]['system'],cutoff_Ry=rs[0]['cutoff_Ry'],Hamiltonian=rs[0]['Hamiltonian'],
        EPS_SCF=rs[0]['EPS_SCF'],ATOMIC_steps=nA,MALA_steps=nM,own_CP2K_reinjection_steps=nR,QE_reference_steps=nQ,
        ATOMIC_relative_reduction_percent=100*(nA-nM)/nA if nM is not None else None,
        own_reinjection_referenced_percent=100*(nA-nM)/(nA-nR) if nM is not None and nR is not None and nA>nR else None,
        QE_reference_transfer_referenced_percent=100*(nA-nM)/(nA-nQ) if nM is not None and nQ is not None and nA>nQ else None))
write_csv('data/CP2K_branches.csv',cp_records);write_csv('data/CP2K_trajectories.csv',cp_curves)
write_csv('data/CP2K_iterations_and_improvements.csv',cp_summary)
shutil.copy2(up/'reinjection_verified_summary.json',OUT/'sources/CP2K_UPF_PBEsol_verified_summary.json')

# Compact global / atom-centred spatial density tables, retaining units and reference.
errors=[r for r in rows(S/'analysis/density_errors.csv') if r['case'] in case_by_id]
spatial=[]
for r in errors:
    if r['stage'] not in ['initial_MALA','initial_ATOMIC','first_MALA','first_ATOMIC','final_MALA']:continue
    if r['region'] not in ['global_region','near_nuclei_r_le_0p75A','nuclear_shell_0p75_to_1p5A','interstitial_r_gt_1p5A']:continue
    spatial.append(dict(label=label(case_by_id[r['case']]),**r))
write_csv('data/QE_spatial_density_errors.csv',spatial)
# Region labels are checked below, to prevent silent empty spatial tables.
write_json('data/density_region_names.json',sorted({r['region'] for r in errors}))

group=[]
for n in [1,2,4]:
    g=[r for r in results if r['vacancies']==n]
    group.append(dict(vacancies=n,placements=len(g),
        MALA_steps_mean=statistics.mean(r['MALA_steps'] for r in g),
        ATOMIC_steps_mean=statistics.mean(r['ATOMIC_steps'] for r in g),
        reinjection_steps_mean=statistics.mean(r['reinjection_steps'] for r in g),
        reinjection_steps_min=min(r['reinjection_steps'] for r in g),reinjection_steps_max=max(r['reinjection_steps'] for r in g),
        mean_case_reinjection_referenced_percent=statistics.mean(r['reinjection_referenced_reduction_percent'] for r in g),
        pooled_reinjection_referenced_percent=100*sum(r['iterations_saved'] for r in g)/sum(r['ATOMIC_steps']-r['reinjection_steps'] for r in g)))
write_csv('data/QE_vacancy_group_statistics.csv',group)
write_csv('data/log_count_rechecks.csv',audits)
assert len([a for a in audits if a['kind']=='QE'])==36
write_json('validation.json',dict(status='TEXT_AND_METADATA_CHECKED',retained_QE_pairs=12,
    genuine_QE_reinjection_controls=12,QE_converged_logs_rechecked=36,CP2K_converged_logs_rechecked=len([a for a in audits if a['kind']=='CP2K']),
    excluded_case='B298_mvac02',new_SCF_runs=0,new_inference_runs=0,new_FFTs=0,
    original_files_untouched=True))
print(json.dumps(load(OUT/'validation.json'),indent=2))
