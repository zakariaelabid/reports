# Evidence and instructions for ChatGPT Web Pro: MALA → QE SCF manuscript

**Prepared 17 November 2026. This is a data/figure handoff, not a manuscript revision.**

Use this package with the supervisor's LaTeX. Preserve its scientific intent, improve the exposition, and insert only supported results. Do not manufacture missing measurements, cite unavailable checks as completed, or write `TBD` into the paper. Report a qualification where it affects a conclusion; keep requests for new evidence outside the manuscript.

This handoff supersedes the earlier author handoff on vacancy reinjection availability: nine genuine boron vacancy reinjection controls are now complete. They are saved results, not estimated group values. No new SCF, QE, MALA prediction, density analysis or FFT was run to prepare this package. Metadata/log auditing ran on the login node; figure rendering used one Slurm compute core and 2 GiB.

## 1. Scope, names and priority changes

Retain **12 configurations**: pristine Al298, pristine Al933, pristine B298, and three placements each for B298 with **1, 2 and 4 vacancies**. There are 24 matched production SCFs plus 12 genuine density-only reinjection controls. Exclude the earlier `B298_mvac02` divacancy everywhere, including aggregates and appendices. Al vacancies and other exploratory branches are outside this manuscript cohort.

Use readable vacancy counts and set numbers; retain internal IDs only in reproducibility tables. Set numbers are labels within each concentration, not nested vacancy sequences. The observed two-step group is **four vacancies**, not three. No retained three-vacancy QE experiment exists.

Priority work for the LaTeX agent:

1. Correctly explain the Al933 architecture and provenance, using Section 2 rather than guessing stale metadata.
2. Identify frozen checkpoints and dataset roles (Section 3).
3. Add a separate CP2K appendix, with real cutoffs, Hamiltonians and both reinjection definitions (Section 6).
4. Insert exact per-case vacancy counts and iteration-reduction percentages (Section 4), with density-error tables (Section 5).
5. Use the supplied framework figure, Fourier maps, spectra and SCF trajectories; captions and interpretations are provided below.
6. Rework or remove ambiguous Table VIII after checking the actual TeX. The current task has the supplied model-parameter screenshot, not the full current Table VIII or manuscript. Do not pretend its complete contents have been inspected here.
7. Explain the specific reasons for selecting MALA and the evidence for data-efficient training (Section 8).
8. Center the current contribution on **SCF iterations and density behavior**, not an end-to-end wall-time acceleration claim (Section 10).

## 2. Al933: what differs, and why it is not stale metadata

### 2.1 The 4000-wide network is the official frozen model

The screenshot's Al933 widths are correct. The downloaded official liquid-model ZIP has published MD5 **397f2de4df02b63ee1c6023591b8c144**. Its unchanged `.params.json` directly records `91 → 4000 → 4000 → 4000 → 250 → 250`. An existing compute-node audit also strict-loaded the actual tensors and verified finite values and legacy-forward compatibility. Weight-matrix shapes are `(4000,91)`, `(4000,4000)`, `(4000,4000)`, `(250,4000)`, `(250,250)`, with matching biases. See `sources/Al933_existing_tensor_audit.json` and `data/checkpoint_archive_checks.json`.

Thus this is a different **pretrained architecture**, not an SCF setting and not a value copied from an unrelated old benchmark. Al298 and B298 have 800-wide early layers. The final two 250 entries in the aluminum networks represent a 250-unit **hidden layer** followed by a 250-channel **output layer**, not two LDOS grids. The stored sizes, rather than the generic `num_hidden_layers` metadata field, establish the real architecture.

The official solid-933 archive also has 4000-wide layers. We have no model-ablation evidence identifying a physical reason that the liquid model *needs* this width, so do not invent one based on disorder or temperature. Different saved architectures are legitimate pretrained design choices; optimality has not been tested in this study.

This is tied to the actual current QE seed: its saved `al933_mala_20261103/run-817432/source_audit.json` records the same network SHA256, snapshot 9, and `model_info_geometry_used=false`. The reused source array is `933K_liquid/execution_20261021/run-743317/mala_finalized/fresh_liquid_density.npy`, SHA256 `21e46f88cf7255b6a979904af6371c14bb237145e1ad53a9da27a75adabd88b6`. The source audit is included under `sources/upstream_support/records/`. This connects architecture, weights, density and production snapshot; the parameter table is not free-standing historical metadata.

Recommended replacement for a crowded architecture row:

| Parameter | Al298 | Al933 | B298 |
| --- | --- | --- | --- |
| Descriptor inputs | 91 | 91 | 91 |
| Hidden-layer widths | 800, 800, 800, 250 | 4000, 4000, 4000, 250 | 800, 800, 800, 250 |
| LDOS outputs | 250 | 250 | 241 |
| Trainable weights + biases | 1,618,200 | 33,439,000 | 1,615,941 |
| Bispectrum 2j_max | 10 | 10 | 10 |
| Bispectrum cutoff (Å) | 4.67637 | 4.67637 | 4.67637 |
| bispectrum_switchflag | 0 | 0 | 1 |
| Saved activation | LeakyReLU | LeakyReLU | LeakyReLU |
| LDOS energy grid (eV) | −10.0 to 14.9 | −10.0 to 14.9 | −8.0 to 16.0 |
| LDOS spacing (eV) | 0.1 | 0.1 | 0.1 |
| Recorded electronic T (K) | 299.98637 | 931.53663 | 298.0 |

The architecture and counts above come from local frozen configurations; parameter counts are the sum of `(n_in+1)n_out` over the saved linear layers. Preserve every layer, including the last hidden 250. `data/model_specifications.csv` supplies machine-readable values.

### 2.2 Nominal temperature and convergence behavior are separate differences

“Al933” is the nominal dataset temperature. Its recorded electronic temperature is **931.5366317709 K**, consistent with Fermi–Dirac broadening `degauss=0.0059 Ry`. For Al298, `0.0019 Ry` corresponds to **299.9863729432 K**. These are saved reference settings, not evidence of an unrelated snapshot. Keep nominal system labels and report actual smearing separately.

Current Gamma QE is **13 MALA / 16 ATOMIC** steps for Al933 snapshot 9; the old GTH/PBE CP2K 800-Ry pair was **17 / 17**. Those numbers belong to different Hamiltonian/basis/grid/SCF implementations and stopping criteria. Do not pool or rename them. The density diagnostics show that Al933's initial MALA density is better globally than ATOMIC, but its first-response error grows and exceeds ATOMIC's first-response global error. That supports investigating response-sensitive long-wavelength components, not a causal claim that network width or one specific code feature explains the iteration difference.

### 2.3 Training-composition qualification remains separate

The [official aluminum model record](https://rodare.hzdr.de/record/2725) labels the checkpoint liquid-trained. However, its unchanged saved training/validation manifest points to `phase_boundaries/solid` mixed-snapshot paths. We verified the correct archive and actual model tensors; that does not resolve what physical snapshots those mixed files contained. State “the officially liquid-labelled Al933 checkpoint” and preserve the unresolved liquid-only qualification. Do not silently replace it with hybrid-trained weights. Author reconciliation of the path discrepancy is still needed before claiming a verified liquid-only model.

## 3. Checkpoint sources, parent snapshots and validation/test status

The aluminum checkpoints are from [RODARE 2725](https://rodare.hzdr.de/record/2725), DOI **10.14278/rodare.2725**. Boron is from [RODARE 3746](https://rodare.hzdr.de/record/3746), DOI **10.14278/rodare.3746**. These must be cited as model/data sources, alongside the MALA methodological papers. We reused the frozen pretrained files; no vacancy retraining was performed.

| System | Frozen checkpoint / member | Parent snapshot | Documented role / limitation |
| --- | --- | --- | --- |
| Al298 | Al_298K_0 | 1 | Explicit validation entry; training entry is snapshot 0. Not an independent unseen test set. |
| Al933 | Al_933K_liquid | 9 | Nominal liquid holdout, selected favorably before SCF by published energy error; training-composition ancestry unresolved. |
| B298 | boron_model_multi_0 | 6 | Explicit validation entry; six shuffled training files are labelled 0–5. Raw shuffle ancestry not independently reconstructed. |

Do not call these all “training snapshots,” and do not call validation entries independent held-out test cases. Their selection/validation role is the supported statement. For B298, a validation label alone does not prove absence of all parent-grid-point overlap in shuffled training files; distinguish the published split from incomplete historical shuffle provenance.

All vacancy configurations are generated by removing the listed atoms from **B298 snapshot 6**, keeping the same cell and remaining positions. They are defect-transfer tests of a frozen model. The published training design and saved manifests describe pristine parent data; no vacancy training entries have been found. We have not reconstructed every original optimization/shuffle history, so avoid stronger unsupported “zero overlap” or universal out-of-distribution claims.

Al933 snapshot 9 was selected before CP2K trials for the smallest published absolute ML-versus-Kohn–Sham free-energy error among nominal liquid holdouts 5–9: approximately **0.506 meV/atom**. This is a favorable-case selection, not representative liquid performance or a density-error guarantee. Its geometry comes from the explicit snapshot-9 QE output, not the checkpoint `.info.json`, which embeds snapshot 0.

Exact network identities:

- **Al298:** `298K_0/model/Al_298K_0.network.pth`; SHA256 `1a4bcd531feac9f1a040cb239fa2541087cdb51ecb82ff5cd341ef03f09c1f0e`.
- **Al933:** `933K_liquid/model_record2725/Al_933K_liquid.network.pth`; SHA256 `1c7edc27c7df1bfa02d76ee1f925515b6de40d02359d05a011bf9846377e8052`.
- **B298:** `boron_298K/model_archives/boron_model_multi_0.network.pth`; SHA256 `a1d8c32983f70ba8f20351401ce32595c53f08253cf3929ce38bffe2cba169d4`.


`data/model_metadata_and_hashes.json` includes checkpoint/scaler/config hashes and complete saved manifests. Small saved configs are in `model_configs/`; large weights/density fields remain at their original server paths. The public ZIPs' MD5s were rechecked against the published records; these archive identities should not be confused with hashes of local repacked containers.

**Original training version:** RODARE 2725 explicitly states **MALA 1.2.1** for its aluminum models. This is distinct from later inference/compatibility environments (including the saved Al933 MALA 1.4.0 audit). That authoritative training-version statement updates the earlier handoff's uncertainty for aluminum. An exact original boron training runtime is not established by this package; do not simply copy the aluminum version to boron.

The RODARE boron landing page's grid description contains `108×108×35`; the actual saved arrays/native calculations use **108×108×135**, as verified in the experiment audits. It also contains inconsistent structural labels. Use inspected geometry/grid metadata for this study, rather than silently adopting the landing-page typo or claiming amorphous boron from that one line.

## 4. Iterations and reinjection-referenced improvement: exact retained QE results

Let `N_A`, `N_M`, and `N_R` denote genuine converged SCF iterations for ATOMIC, MALA and reinjection of the same-case own-QE converged density. Report both:

\[
s_N=100\frac{N_A-N_M}{N_A},\qquad
\eta_N=100\frac{N_A-N_M}{N_A-N_R}.
\]

The second quantity is an **empirical reinjection-referenced iteration reduction**. It is not a theoretical maximum acceleration, a fraction of density error removed, or a direct measurement of importer error. It is undefined when `N_A=N_R`; a negative numerator would indicate a MALA regression. Do not mix time and iteration versions of this formula.

| Case | MALA N | ATOMIC N | Own QE reinjection N | Saved N | s_N | η_N |
| --- | --- | --- | --- | --- | --- | --- |
| Al298 pristine | **10** | 14 | 3 | 4 | 28.57% | 36.36% |
| Al933 pristine | **13** | 16 | 3 | 3 | 18.75% | 23.08% |
| B298 pristine | **8** | 11 | 3 | 3 | 27.27% | 37.50% |
| B298, 1 vacancy, set 1 | **15** | 16 | 2 | 1 | 6.25% | 7.14% |
| B298, 1 vacancy, set 2 | **15** | 17 | 3 | 2 | 11.76% | 14.29% |
| B298, 1 vacancy, set 3 | **16** | 18 | 3 | 2 | 11.11% | 13.33% |
| B298, 2 vacancies, set 1 | **18** | 21 | 3 | 3 | 14.29% | 16.67% |
| B298, 2 vacancies, set 2 | **21** | 22 | 3 | 1 | 4.55% | 5.26% |
| B298, 2 vacancies, set 3 | **21** | **21** | 3 | 0 | 0.00% | 0.00% |
| B298, 4 vacancies, set 1 | **17** | 18 | 2 | 1 | 5.56% | 6.25% |
| B298, 4 vacancies, set 2 | **18** | **18** | 2 | 0 | 0.00% | 0.00% |
| B298, 4 vacancies, set 3 | **17** | **17** | 2 | 0 | 0.00% | 0.00% |

Bold compares MALA and ATOMIC only; exact ties are bolded in both columns. Reinjection is a separate diagnostic reference. Each value is one saved trajectory, not an average of repeated runs.

The user's proposed rounded group summary can be phrased as “about three steps for one and two vacancies, and two steps for four vacancies.” **Do not replace the measured two-step first single-vacancy control by three** in a per-case table. Its exact group mean is 2.667. Use the actual denominator for each percentage above.

| B vacancy count | Placements | Mean MALA N | Mean ATOMIC N | Mean reinjection N | η_N: mean of case ratios | η_N: pooled counts |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 3 | 15.333 | 17.000 | 2.667 | 11.59% | 11.63% |
| 2 | 3 | 20.000 | 21.333 | 3.000 | 7.31% | 7.27% |
| 4 | 3 | 17.333 | 17.667 | 2.000 | 2.08% | 2.13% |

The pooled score is `sum(N_A−N_M)/sum(N_A−N_R)`, which differs from averaging per-case percentages. Label the aggregation explicitly. Three deliberately selected placements per concentration do not establish a population mean or statistical significance.

Within this cohort MALA saves 1–2 steps in all three single vacancies, 0–3 in divacancies, and 0–1 in four-vacancy placements. The observed decline in benefit is descriptive. Placement, density response, and concentration vary together; no universal monotonic concentration law has been demonstrated. Density locality does not guarantee the best global SCF trajectory.

### 4.1 Geometry and electron-count mapping

| Manuscript label | Internal ID | Removed parent indices (zero-based) | Retained atoms | Valence electrons |
| --- | --- | --- | --- | --- |
| B298, 1 vacancy, set 1 | B298_vac02 | [89] | 143 | 429 |
| B298, 1 vacancy, set 2 | B298_vac03 | [29] | 143 | 429 |
| B298, 1 vacancy, set 3 | B298_vac06 | [62] | 143 | 429 |
| B298, 2 vacancies, set 1 | B298_dv2_c1 | [5, 106] | 142 | 426 |
| B298, 2 vacancies, set 2 | B298_dv2_c2 | [15, 26] | 142 | 426 |
| B298, 2 vacancies, set 3 | B298_dv2_c3 | [45, 92] | 142 | 426 |
| B298, 4 vacancies, set 1 | B298_mvac04 | [5, 34, 88, 95] | 140 | 420 |
| B298, 4 vacancies, set 2 | B298_v4_c1 | [84, 91, 109, 138] | 140 | 420 |
| B298, 4 vacancies, set 3 | B298_v4_c2 | [17, 28, 46, 71] | 140 | 420 |

Electron count is `3(144−n_vac)`: 429, 426 and 420 for one, two and four boron vacancies. It is a consistency check, not an accuracy score, because integration solves the chemical potential for the known charge. Configurations retain periodic boundaries and fixed geometry; this is not a relaxed formation-energy benchmark. `figures/Boron_vacancy_placements.pdf` visualizes all nine placements in a periodic fractional-coordinate projection.

All retained QE pairs use the saved **non-spin-polarized `nspin=1`** setup with fractional Fermi–Dirac occupations. In particular, the 429-electron single-vacancy cells are restricted finite-temperature calculations, not demonstrated spin-polarized defect ground states. No spin-state or relaxation search was performed. Keep this caveat when interpreting vacancy physics or discussing transferability beyond this controlled initialization comparison.

### 4.2 Reinjection is a scalar-density control, not a state restart

For all 12 QE controls, the actual matched ATOMIC endpoint's native `charge-density.hdf5` is copied unchanged into a fresh run, and `startingpot='file'` replaces `startingpot='atomic'`. Fresh atomic+random orbitals and empty mixing history are used. Hamiltonian, positions, charge, cutoffs, grid, smearing, diagonalizer and outer tolerance are retained within the case. No fitted reference, new MALA prediction, wavefunction restart, or density conversion is needed for these native controls.

Even an excellent density does not provide self-consistent wavefunctions/occupations or solver history. Finite inner diagonalization, rebuilding states, outer tolerances and self-consistent response all affect the remaining 2–3 steps. Consequently, `N_R` does **not** isolate an external-density module defect. The small within-count single-vacancy difference (2 versus 3) is an observed outcome, not something that must be made identical.

The new vacancy controls are the saved job **856943**, `qe_native_20261103/b_vacancy_reinject_20261117/run-856943/`, and are genuine full SCFs at `conv_thr=1e-6 Ry/cell`. They are different from the earlier one-outer-step response diagnostics. Their endpoint density relative-L2 discrepancy to the copied source is at most approximately **3.58e-5**, with finite-tolerance energy differences at most approximately **3.4e-7 Ry**. Exact electronic-state identity has not been demonstrated.

### 4.3 QE settings and unequal stopping thresholds

| Cohort | ecutwfc / ecutrho (Ry) | Native grid | conv_thr (Ry/cell) | Smearing degauss (Ry) | MPI × threads |
| --- | --- | --- | --- | --- | --- |
| Al298 pristine | 100 / 400 | 200³ | 2.56e-4 | .0019 | 8 × 1 |
| Al933 pristine | 100 / 400 | 200³ | 2.56e-4 | .0059 | 8 × 1 |
| B298 pristine | 80 / 320 | 108 × 108 × 135 | 1.44e-4 | .0018874 | 4 × 1 |
| B298 vacancies | 80 / 320 | 108 × 108 × 135 | 1.0e-6 | .0018874 | 4 × 1 |

All retained QE calculations are Gamma-only diagnostics, not the original dense training-reference k meshes. Aluminum uses original NC-UPF `Al.sr-pbesol.upf` / PBEsol; boron uses `B_ncrs_v041_pbe.upf` / PBE. The actual pseudopotential files and hashes are included in upstream support. Both retain three valence electrons per atom, with core corrections handled by the Hamiltonian and excluded from valence-density error comparisons.

QE input uses `mixing_mode='plain'`, `mixing_beta=.1`, `mixing_ndim=8`, with QE's Broyden history; do not translate it into CP2K's keyword spelling. The diagonalizer is Davidson, `diago_thr_init=1e-5 Ry`; original production inputs and reinjection copies are supplied. `conv_thr` is QE's estimated SCF-accuracy criterion in Ry per cell, not directly CP2K's `EPS_SCF` residual or VASP's `EDIFF`. A shared numeric exponent across codes is not an equal physical stopping rule. These definitions are documented in the [QE 7.5 input reference](https://www.quantum-espresso.org/Doc/INPUT_PW.html) (`conv_thr`, `mixing_mode`, `startingpot` and `startingwfc` entries).

The pristine and vacancy **outer** thresholds differ substantially. Compare methods **within each matched case**. Do not attribute all extra defective-system iterations relative to pristine B to vacancy-induced generalization failure; the tighter vacancy criterion is a confounder. Likewise, the pristine reinjection count of three and defective count of two are not evidence that defects intrinsically make reinjection easier.

## 5. Density-error tables, endpoint checks and Fourier interpretation

The common density reference is each case's own converged ATOMIC-initialized **Gamma QE valence density**. It is not the model-training LDOS reference, a fitted reference, NLCC core density, or an all-electron density. Native cell/origin/reciprocal-grid alignment is retained. No post-hoc spatial shift, clipping or charge normalization was applied in the native error analysis. All six fields per retained case passed finite/charge/positivity checks in the saved audit.

Definitions for a region Ω:

- `MAE = mean_Ω |ρ−ρ_ref|` in e/Å³.
- `MSE = mean_Ω (ρ−ρ_ref)²` in e²/Å⁶.
- `RMSE = sqrt(MSE)` in e/Å³.
- Relative L1 is `sum_Ω |ρ−ρ_ref| / sum_Ω |ρ_ref|`.
- Relative L2 is `sqrt(sum_Ω (ρ−ρ_ref)² / sum_Ω ρ_ref²)`.

The saved table contains MAE, RMSE and relative L1/L2. If MSE is wanted, square the supplied RMSE (or use the explicitly derived MSE column added with this handoff); do not call RMSE “MSE.” Region counts and volume fractions are retained. Electron conservation alone is not evidence of density accuracy.

### 5.1 Global errors, before diagonalization and at the saved first response

| Case | Initial MALA rel.L2 (%) | Initial ATOMIC rel.L2 (%) | First MALA rel.L2 (%) | First ATOMIC rel.L2 (%) |
| --- | --- | --- | --- | --- |
| Al298 pristine | 0.7416 | 10.9468 | 0.9399 | 2.3033 |
| Al933 pristine | 2.0213 | 11.5036 | 5.6300 | 4.2924 |
| B298 pristine | 1.0230 | 14.9307 | 1.0848 | 7.2677 |
| B298, 1 vacancy, set 1 | 2.3818 | 14.8594 | 10.4336 | 7.3070 |
| B298, 1 vacancy, set 2 | 2.4280 | 14.8567 | 9.4918 | 7.4807 |
| B298, 1 vacancy, set 3 | 2.5539 | 14.8649 | 10.4828 | 7.4166 |
| B298, 2 vacancies, set 1 | 3.2223 | 14.7988 | 9.6886 | 7.5278 |
| B298, 2 vacancies, set 2 | 3.1729 | 14.8062 | 8.2396 | 7.6613 |
| B298, 2 vacancies, set 3 | 3.2887 | 14.7664 | 10.1355 | 7.6635 |
| B298, 4 vacancies, set 1 | 4.3313 | 14.6438 | 10.6244 | 7.7700 |
| B298, 4 vacancies, set 2 | 4.2297 | 14.6454 | 10.6001 | 7.8605 |
| B298, 4 vacancies, set 3 | 4.2973 | 14.6638 | 10.0312 | 7.8213 |

MALA's initial density is closer globally in all retained cases, but that does not guarantee proportionately fewer SCF steps. After the first saved response, ATOMIC is globally closer for Al933 and the nine defective B cases, while pristine Al298/B retain the better MALA first response. This is an important result to discuss candidly rather than hiding unfavorable columns.

The first-response fields were saved using bounded one-outer-step replays (`electron_maxstep=1`, `scf_must_converge=false`) and diagnostic output changes. They are the unmixed density response associated with the first Hamiltonian, **not** genuine one-step outer convergence or the next mixed input density. Sixteen of the 24 retained diagnostics have Davidson warnings for one to three unconverged eigenvalues. The warning does not identify their occupations. Treat these as finite-inner-tolerance response diagnostics; do not assume all warned states are empty or exact Kohn–Sham response has been obtained.

### 5.2 Near-nucleus versus interstitial errors

Periodic nearest-surviving-nucleus distance partitions the cell into **r ≤ 0.75 Å**, **0.75 < r ≤ 1.5 Å**, and **r > 1.5 Å**. The last region is labelled interstitial/far from nuclei. It is not the same as being far from a vacancy. Defective cases also have a separate vacancy-centered partition: union of vacancy cores r ≤ 1.5 Å, surrounding 1.5–3 Å shell, and farther than 3 Å from every vacancy.

The following table gives initial MALA RMSE values for the atom-centered partition. Full matched MALA **and ATOMIC**, initial/first/final, MAE/RMSE/relative-L1/L2 and vacancy-centered metrics are in `data/density_errors.csv` and `data/QE_spatial_density_errors.csv`. Bold the better matched result per metric and stage in the final LaTeX tables, including ATOMIC wins. Use a consistent rule for ties at displayed precision.

| Case | Near nuclei RMSE (e/Å³) | Nuclear shell RMSE (e/Å³) | Interstitial RMSE (e/Å³) |
| --- | --- | --- | --- |
| Al298 pristine | 0.001466 | 0.001380 | 0.001209 |
| Al933 pristine | 0.005169 | 0.003715 | 0.002934 |
| B298 pristine | 0.007234 | 0.004064 | 0.002057 |
| B298, 1 vacancy, set 1 | 0.015658 | 0.009797 | 0.008625 |
| B298, 1 vacancy, set 2 | 0.016244 | 0.009981 | 0.007057 |
| B298, 1 vacancy, set 3 | 0.016710 | 0.010647 | 0.008202 |
| B298, 2 vacancies, set 1 | 0.021046 | 0.013214 | 0.011695 |
| B298, 2 vacancies, set 2 | 0.021033 | 0.012930 | 0.010533 |
| B298, 2 vacancies, set 3 | 0.021240 | 0.013580 | 0.012322 |
| B298, 4 vacancies, set 1 | 0.028014 | 0.017591 | 0.015737 |
| B298, 4 vacancies, set 2 | 0.027290 | 0.017307 | 0.014368 |
| B298, 4 vacancies, set 3 | 0.027965 | 0.017489 | 0.014381 |

### 5.3 Endpoint agreement

| Case | |E_M−E_A| (Ry/cell) | Final density M/A relative L2 |
| --- | --- | --- |
| Al298 pristine | 2e-07 | 0.0003447 |
| Al933 pristine | 8.483e-05 | 0.0003652 |
| B298 pristine | 4.911e-05 | 0.0003379 |
| B298, 1 vacancy, set 1 | 1.8e-07 | 2.368e-05 |
| B298, 1 vacancy, set 2 | 2.1e-07 | 2.569e-05 |
| B298, 1 vacancy, set 3 | 1.9e-07 | 2.509e-05 |
| B298, 2 vacancies, set 1 | 4e-08 | 1.987e-05 |
| B298, 2 vacancies, set 2 | 1e-07 | 1.16e-05 |
| B298, 2 vacancies, set 3 | 2e-08 | 1.048e-05 |
| B298, 4 vacancies, set 1 | 4e-08 | 2.042e-05 |
| B298, 4 vacancies, set 2 | 3e-08 | 2.137e-05 |
| B298, 4 vacancies, set 3 | 5e-08 | 1.873e-05 |

Report finite-tolerance endpoint agreement. More-negative final energy is not automatically a better initializer; finite smearing, independent trajectories and stopping errors matter. No retained-cohort tighter-threshold state-identity study has been located. Do not invent one from small density differences or empty-top-band checks.

### 5.4 Fourier plots: what to include and what they mean

**Al298 and Al933 Fourier maps are both available.** New consistent-format versions are `figures/Al298_Fourier_comparison.{pdf,png,svg}` and `figures/Al933_Fourier_comparison.{pdf,png,svg}`. Corresponding full spectra are in `existing_figures/Al298/fourier_spectra.pdf` and the Al933 equivalent. Every retained case also has its original Fourier spectra, maps and MALA/ATOMIC SCF curves under `existing_figures/CASE/`.

Recommend keeping Al933's map/spectrum in the main text because the large first-response amplification is informative; place Al298 alongside it if space permits, or in the appendix with a clear citation. The contrast is useful even when both seeds eventually converge. The writing agent may choose layout; the figure data are supplied, not silently discarded.

Map columns compare (i) MALA to converged ATOMIC, (ii) ATOMIC to converged ATOMIC, and (iii) MALA to ATOMIC. The top row uses initial densities; the bottom row uses first responses. Maps show **|Δρ_G|**, not signed real-space density error. They are the native `h₃=0` reciprocal plane, |G| ≤ 6 Å⁻¹, with DC omitted and a common logarithmic color scale within each case. Cartesian reciprocal coordinates preserve the skew boron cell. A plane slice is not the full 3D spectrum or a projection. Separate new Al298/Al933 figures have case-specific color limits: do not compare their colors without reading the scales.

Radial shell plots use conjugate-pair-weighted **sums** of |Δρ_G|²; they are not averages per mode. Their integral/sum is tied to real-space mean-square error by Parseval. Long-wavelength Hartree-potential sensitivity is assessed by the `4π/G²` kernel with G=0 excluded and potential zero fixed. The reported Hartree RMS is in **eV of potential**, not an SCF residual, total-energy difference or electrostatic energy. Real-space proximity to nuclei and reciprocal wave number are different axes of analysis; do not identify “near atoms” with “high G.”

Energy trajectories use `|E_n−E_final,ATOMIC|` in meV/atom for each same-case Hamiltonian. This is a finite-tolerance endpoint reference, not a known exact ground-state energy. The zero ATOMIC endpoint is omitted on a logarithmic axis. “F reference” or `ρ_ref` must be defined explicitly in the actual manuscript caption rather than left as an unexplained symbol.

## 6. CP2K appendix: preserve code, Hamiltonian and cutoff distinctions

The appendix should document why the earlier cross-code density-transfer controls motivated moving the main benchmark into QE. It must **not** present a universal speed ranking between codes. CP2K uses Gaussian orbitals with an auxiliary plane-wave/grid representation; QE uses plane-wave orbitals. A CP2K 800-Ry density-grid cutoff is not equivalent to QE `ecutwfc=800 Ry`, and equal nominal grid dimensions do not guarantee the same representation.

### 6.1 Main pristine CP2K results

Here `R_C` means own-CP2K converged valence density reinjected into CP2K; `R_Q` means a density constructed by integrating the **original QE-reference LDOS** and transferred into CP2K. These are separate controls. The latter originates from dense-mesh QE reference data and is not a native restart of the matched Gamma QE production calculation reported in Section 4.

| CP2K case | Cutoff (Ry) | MALA N | ATOMIC N | R_C N | R_Q N | s_N | η using R_C | η using R_Q |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Al298_GTH800 | 800 | 15 | 17 | 4 | 14 | 11.76% | 15.38% | 66.67% |
| Al933_GTH800 | 800 | 17 | 17 | 4 | 15 | 0.00% | 0.00% | 0.00% |
| B298_GTH800 | 800 | unavailable | 16 | unavailable | 12 | unavailable | unavailable | unavailable |
| B298_GTH8000_historical | 8000 | 14 | 16 | 2 | unavailable | 12.50% | 14.29% | unavailable |
| Al298_UPF800 | 800 | 14 | 17 | 4 | 14 | 17.65% | 23.08% | 100.00% |

The `η using R_Q` column is the user's requested `(ATOMIC−MALA)/(ATOMIC−QE-reference-density)` comparison. Label it **QE-transfer-referenced**, not a theoretical upper bound or the same metric as own-density reinjection. The Al298 UPF case's 100% says only that MALA and the transferred QE-reference density both took 14 steps in that experiment. It does not mean perfect density, optimal initialization or all possible acceleration recovered.

Pristine B800 has ATOMIC=16 and QE-reference=12, but **no matched MALA result was found**. Its MALA score is unavailable. Preserve the historical B8000 14/16 result as **8000 Ry**; never relabel it 800 or combine it with the 800-Ry QE-reference control. The historical B8000 own-density control was produced later at matched numerical settings; iterations may be tabulated, but this is not a matched timing-repetition study.

The Al298 GTH800 own-density control in this package is the saved **MALA-seeded converged endpoint** reimported at the same Hamiltonian/grid (4 steps), not a separately generated ATOMIC endpoint. This is documented in `CP2K_branches.csv`. The Al933 control uses its ATOMIC endpoint. Distinguish the source instead of silently claiming both were ATOMIC-density controls.

### 6.2 CP2K numerical settings

Main GTH800 tests: PBE / GTH-PBE three-valence pseudopotentials; DZVP-MOLOPT-SR-GTH; Gamma; periodic XYZ; `CUTOFF=800 Ry`, `REL_CUTOFF=60 Ry`; diagonalization with `BROYDEN_MIXING`, `ALPHA=.10`, `NBUFFER=8`; pristine `EPS_SCF=1e-5`, `MAX_SCF=50`; Fermi–Dirac smearing. Aluminum has `ADDED_MOS=256`; boron has 64. Electronic T is 300 K (Al298), 931.5366317709 K (Al933), or 298 K (B). Each matched pair retains its settings and geometry.

Aluminum's 200³ external source cube is projected onto the **288³ native finest CP2K grid** at 800 Ry; an external cube's dimensions do not set CP2K's internal grid. The finest-grid importer/runtime audit is part of the provenance. This auxiliary-grid cutoff, native grid and transfer must be stated separately from the ML training grid.

The additional Al298 **UPF/PBEsol** control retains DZVP-MOLOPT-SR-GTH and 800/60 Ry, with the original NC-UPF `Al.sr-pbesol.upf` including NLCC, rather than GTH/PBE. It gives 14/17 MALA/ATOMIC, own-density 4 and transferred QE-reference 14. Both production branches meet `EPS_SCF=1e-5`, but their energy difference is **0.001043070908 Ha** (about 0.11087 meV/atom), slightly exceeding the old bookkeeping flag of 0.001 Ha. Do not describe exact common-endpoint energy equality as verified. See `sources/CP2K_UPF_PBEsol_verified_summary.json`.

Matching pseudopotential and XC improved this one Al298 iteration difference from 2 to 3, but did not turn the transferred QE density into a near-one-step CP2K solution. Remaining basis, k sampling, representation, numerical/inner-solver and finite-tolerance differences preclude isolating one mechanism. This is evidence for Hamiltonian/representation sensitivity, not proof that the importer alone is responsible.

Historical 11,000-Ry aluminum and 8,000-Ry boron experiments can be mentioned briefly as costly exploratory controls. The old hybrid Al933 snapshot-8/model pair is not the current liquid-labelled snapshot-9 case. No need to foreground their resource costs or imply the large grids were required by MALA. A shared iteration count at two cutoffs is not permission to relabel the actual cutoff.

### 6.3 Retained-geometry CP2K boron vacancy appendix

These old boron cases use **800 Ry / PBE / GTH**, `EPS_SCF=1e-7`; the QE cases use `conv_thr=1e-6 Ry/cell`. These are distinct convergence measures. The table reports actual 1e-7 completion counts. The `first_crossing_1e5` columns in `CP2K_branches.csv` are **retrospective first crossings**, not independent 1e-5 reruns, and should be labelled accordingly.

| QE-style case label | MALA CP2K N | ATOMIC CP2K N | Own CP2K density N | η using matched own density |
| --- | --- | --- | --- | --- |
| B298, 1 vacancy, set 3 | 26 | 27 | 8 | 5.26% |
| B298, 1 vacancy, set 1 | 25 | 26 | 6 | 5.00% |
| B298, 1 vacancy, set 2 | 24 | 26 | 6 | 10.00% |
| B298, 4 vacancies, set 1 | 27 | 29 | unavailable | unavailable |
| B298, 4 vacancies, set 2 | 31 | 31 | unavailable | unavailable |
| B298, 4 vacancies, set 3 | 28 | 27 | unavailable | unavailable |

Three new retained divacancy placements have no matching CP2K baseline in the audited set. Do not substitute the excluded old `mvac02` or borrow new QE reinjection counts as CP2K controls. The reused four-vacancy set 1 is counted once. Old CP2K density-blending experiments are historical method variants and are not part of the present pure-MALA/ATOMIC QE claim; include them only if the paper explicitly broadens its appendix scope.

The old 1e-7 choice aimed at stable density/formation-energy reference calculations. It was not selected by a measured observable-convergence study for this cohort. Tighter convergence is reasonable to investigate, but neither this exponent nor QE's later 1e-6 is automatically validated by a superficially matching VASP threshold. Do not invent a paper citation proving numerical equivalence between these stopping rules. Existing defect-study references in the old presentation are examples, not an observable-convergence proof for these systems.

For continuity, the prior presentation's defect-study example is Polfus, Peters, Bredesen and Løvvik, **Vacancy diffusion in palladium hydrides**, PCCP 23, 13680–13686 (2021), [10.1039/D1CP01960K](https://doi.org/10.1039/D1CP01960K). It illustrates a separately controlled defect-calculation methodology, not an argument that CP2K `EPS_SCF=1e-7` equals a VASP energy threshold. The exact prior-note excerpt and primary source locator are preserved in `sources/previous_threshold_rationale.txt`; do not promote that contextual example into a convergence test of our boron cells.

The [CP2K SCF input documentation](https://manual.cp2k.org/trunk/CP2K_INPUT/FORCE_EVAL/DFT/SCF.html#eps-scf) defines `EPS_SCF` as the inner-SCF convergence target (current documented default 1e-5). This supports reporting the keyword meaning, not claiming that the specific tighter 1e-7 setting was validated for our vacancy observables. Current online implementation details must not be substituted for the saved historical executable/importer behavior.

### 6.4 Supporting CP2K figures and raw sources

- `figures/CP2K_800Ry_comparison.pdf`: four initializations where available, missing B800 MALA explicit.
- `figures/CP2K_pristine_trajectories.pdf`: saved energy/residual trajectories, including UPF/PBEsol.
- `figures/CP2K_vacancy_trajectories.pdf`: six retained-geometry old vacancy pairs and three saved single-vacancy reinjections; solid 1e-7 and dashed retrospective 1e-5 guides.
- `data/CP2K_iterations_and_improvements.csv`, `CP2K_branches.csv`, and `CP2K_trajectories.csv`: exact per-branch counts, cutoff, source, threshold and trajectories.
- `raw_logs/`: inspected original stdout copies; no density fields or large checkpoints are duplicated.

## 7. Table VIII: concrete repair instructions

The actual supervisor TeX is held by ChatGPT Web Pro. **Check what Table VIII currently contains before changing it.** Numbering alone is not a stable identifier. If it is the model-parameter screenshot, replace the long “Full layer sizes” row with separate descriptor input, hidden-layer widths and LDOS output rows from Section 2; retain full sizes in the appendix. Define `2j_max`, cutoff units, switchflag, endpoint-inclusive LDOS grids, and electronic temperature separately from nominal system labels. Cite the actual checkpoint/config source, not a claim of an architecture invented here.

If Table VIII instead summarizes density errors or comparisons, split heterogeneous quantities into (a) initial/first/final density quality with reference/region/units and (b) actual SCF iterations plus the explicitly defined reinjection score. Do not combine Hartree-potential RMS, SCF estimated accuracy, energy-endpoint distance and density MSE under one unqualified “error.” Every ratio needs its denominator in the caption. Remove a redundant table if the text/another table already reports the same information more clearly. The writing agent should choose after inspecting the real manuscript.

For matched error tables, bold the smaller value for each MALA/ATOMIC pair separately by stage, region and metric. At displayed ties, bold both or neither consistently; do not imply meaningful hidden-digit wins. Do not bold a more-negative total energy as “better.” Reinjection columns should remain visually separate from the primary MALA/ATOMIC comparison.

## 8. Why MALA is a strong choice: evidence, not promotional extrapolation

The methodological choice is particularly useful here because the frozen model already supplies **a spatially resolved LDOS and charge-consistent scalar density from atomic structure**, while QE retains the final self-consistent physics. No target-case converged density is used to prepare the MALA seed; the converged reference enters only evaluation and the explicit reinjection control. We reuse public checkpoints and demonstrate defect transfer without retraining. The low initial density errors and the 0–4 saved iterations are the directly measured benefits in this cohort.

Training-data efficiency must be stated as **few atomic configurations with dense volumetric supervision**, not “a few data points.” The local saved Al298 manifest has one training snapshot (0) and one validation snapshot (1). A 200³ snapshot contains **8,000,000 grid positions**; these are correlated spatial samples, not independent geometries. Boron's 108×108×135 grid has **1,574,640 positions**. Counting training files after shuffling is not a substitute for identifying original parent configurations.

The official aluminum record describes four-snapshot melting-point models and MALA 1.2.1 retraining with inter-snapshot shuffling. Keep the Al933 composition/path qualification from Section 2 alongside that author statement. [RODARE 2725](https://rodare.hzdr.de/record/2725).

Published MALA support, separate from our measurements: the package paper's boron example uses **six training, one validation and eight test snapshots**; its training-cost table reports **3.37 GPUh** for room-temperature Al and **9.26 GPUh** for liquid melting-point Al, averaged over initializations on a single V100 per model. Its implementation supports Kokkos GPU descriptors and PyTorch GPU networks, with MPI capabilities; not all integration/postprocessing is GPU-accelerated. These literature figures exclude any claim about our measured full training-data-generation/HPO expense or our QE-SCF speedup. [Cangi et al., MALA package paper, Sections 3.5, 4.2 and Table 2](https://arxiv.org/html/2411.19617v1).

For practical training, the documented high-level API follows parameters → snapshot registration/splitting → preprocessing/scaling → network → trainer → saved model/scalers. That makes implementation accessible, but reference DFT/LDOS generation, choosing representative configurations, hyperparameter selection and validation remain substantive scientific work. It does not mean arbitrary defective chemistries can be trained reliably in minutes. [Official MALA training documentation](https://mala-project.github.io/mala/basic_usage/trainingmodel.html).

Suggested positive argument for the authors to develop in their own prose: MALA is a reproducible, reusable initializer with structure-aware local descriptors, rich LDOS supervision from few parent configurations, and a physics-based occupation/electron-count integration step. It reduces SCF iterations in the three pristine systems and several defect placements while leaving the final electronic solution to QE. Initial density accuracy is much better than a simple atomic superposition, but the self-consistent response reveals why that advantage is not converted one-for-one into iteration savings. The result supports a useful initializer and a diagnostic framework, rather than universal acceleration or perfect defect generalization.

Do not confuse MALA–ATOMIC density blending with an ensemble of separately trained networks. This retained QE cohort uses one frozen model per system and no density blending. Any historical CP2K blends belong in a clearly separate appendix subsection, not a new claim that the current QE results are an ensemble.

## 9. Full framework figure: files, intended caption and integration

Use `figures/framework_MALA_QE.pdf` for LaTeX. An editable text-preserving SVG and high-resolution PNG are also supplied. Its source is `make_figures.py`. The figure is vector artwork describing the actual method, not generated density data.

Suggested caption content (adapt to manuscript style):

> Framework for comparing frozen MALA and ATOMIC density initialization in Quantum ESPRESSO. Atomic positions and the periodic cell define local SNAP descriptors. A pretrained network predicts LDOS on its saved energy grid; finite-temperature integration determines the chemical potential for the known valence electron count. Unit/grid conversion supplies the native QE density without using a converged target reference. The matched ATOMIC branch uses the pseudopotential atomic superposition. Each branch starts an independent SCF with the same case-specific Hamiltonian and numerical parameters. Converged densities support spatial/Fourier diagnostics; copying the same-case converged native density into a fresh SCF provides a separate density-only reinjection control. No orbitals or mixing history are transferred in that control.

The dashed control loop must not be presented as a step required for deployment. Likewise, any initial ATOMIC native template used to establish QE's reciprocal-grid/file layout is a preparation artifact, not a converged DFT reference used to correct the MALA seed. The inference pipeline does not need a known converged density.

Colors consistently distinguish MALA (blue), ATOMIC (orange), own-density reinjection (green), and comparison/transfer diagnostics (purple). The figure shows charge checks without asserting that density-only processing enforces an N-representable density matrix, exact Kohn–Sham states, or occupation-state equivalence.

## 10. Iterations versus cost: required limitation and future work

**This paper should emphasize iteration savings, density errors and response diagnostics.** The current small systems converge rapidly enough that measured descriptor/inference/preparation overhead can erase the SCF savings. We do not establish a uniform fresh end-to-end runtime advantage. Saved cached timings exclude previous inference, and raw stage timers do not define an identical fresh deployment boundary across all cases. Retain the source timing records for reproducibility, but do not turn them into a headline speedup or combine cached and fresh totals.

Iteration counts are less dependent on cluster speed than wall time, but remain conditional on Hamiltonian, threshold, mixing, diagonalizer, band count and numerical precision. Hardware/library differences can also influence finite-tolerance trajectories; do not call counts a universal hardware-independent material property. Current timing entries are single observations, not repeated estimates with uncertainty bars.

Scaling to larger systems and accelerating descriptors/network execution on GPUs are motivated routes to improving the preparation/SCF balance. Published MALA GPU/scaling evidence supports that research direction. **Our dataset does not establish that scaling or GPU optimization will guarantee an end-to-end speedup**, let alone a “100%” certainty. State it as a testable future opportunity requiring full-pipeline benchmarks, amortization policy and matched resources.

## 11. Six additional author questions: current availability

| Question | Available now | Still unestablished / manuscript treatment |
| --- | --- | --- |
| 1. Al933 training composition | Official archive identity, saved configs/tensors, author-labelled liquid four-snapshot model | No authoritative reconciliation of solid-directory mixed paths; keep liquid-only qualification. |
| 2. Dataset ancestry / original history | Explicit Al298/B298 validation manifests; nominal Al933 holdout selection; published boron 6/1/8 protocol | No complete shuffle-generation ancestry, independent overlap exclusion, original MD equilibration/sampling or full optimization history. |
| 3. Historical prediction environments | Al298 saved version dictionary; existing Al933 compatibility audit; current source/runtime; boron workers/configs | No complete contemporaneous original environment for every older Al933/B density job. Al training version 1.2.1 is now authoritative; do not infer all inference/training versions from today. |
| 4. Consistent fresh accounting | Raw stage/worker timers, conversion audits, deployment scripts, cached boundaries | No uniform fresh launch-to-export benchmark. Shared divacancy startup is not measured as pure model-load time. No timing headline. |
| 5. Timing repeatability / cache policy | Job IDs, hardware/runtime/library paths, MPI/thread settings, recorded core binding and run order | No controlled repetitions or standardized filesystem/page-cache/run-order noise policy for these exact pairs. Treat as single observations. |
| 6. Tighter endpoints / state checks | Finite-tolerance pair endpoints, empty-top-band checks, all 12 genuine QE reinjection controls | No complete tighter same-settings cohort study, exact electronic-state identity or state-resolved occupations of Davidson warning eigenvalues. |

Do not add speculative measurements to close these gaps. The local presence of a source/config file is not proof of a run that was never recorded. A successful SCF does not establish training ancestry, and a model archive label does not settle conflicting embedded paths.

## 12. Exact asset and source map

### Core data

- `data/QE_iterations_and_improvements.csv`: 12 exact per-case iteration counts, both percentage definitions, parent snapshot, removal indices, cutoff/grid/threshold, energy endpoints and density errors.
- `data/QE_vacancy_group_statistics.csv`: exact control means/ranges plus mean-of-ratios and pooled scores.
- `data/density_errors.csv`: all **450** retained regional metrics; `density_errors_with_MSE.csv` additionally gives `MSE=(saved RMSE)^2` and display-friendly names.
- `data/QE_paired_density_errors_and_winners.csv`: matched initial/first MALA and ATOMIC metrics, per-metric smaller-result labels and explicit ATOMIC-relative density-error reductions for table formatting. These percentages concern density quality and must not be confused with iteration reductions.
- `data/QE_spatial_density_errors.csv`: atom-centered compact subset; full vacancy-centered partition remains in the full table.
- `data/fourier_metrics.csv`: **72** retained six-stage reciprocal-space scalar metric rows.
- `data/scf_trajectories.csv`: matched MALA/ATOMIC production trajectories; pristine reinjection trajectories are in `sources/SYSTEM_reinjection_results.json` and vacancy three-way curves in `data/vacancy_reinjection_SCF_trajectories.csv`.
- `data/model_specifications.csv`, `model_metadata_and_hashes.json`, `checkpoint_archive_checks.json`: architecture and model/archive provenance.
- `data/literature_training_counts.csv`: configuration counts, train/validation roles and their evidence level; keep these distinct from shuffled-file counts and independent statistical samples.
- `data/CP2K_branches.csv`, `CP2K_iterations_and_improvements.csv`, `CP2K_trajectories.csv`: independent old-code appendix evidence.
- `data/log_count_rechecks.csv`: stdout identities and rechecked completed iterations for **36 QE + 32 CP2K** trajectories. This is a new selected-cohort audit; it does not claim to reaudit every old exploratory/blending run.

### Figures

- `figures/framework_MALA_QE.*`: full method figure (PDF/SVG/PNG).
- `figures/QE_iteration_comparison.*`: exact counts and both percentage definitions.
- `figures/QE_pristine_three_way_trajectories.*`: pristine MALA, ATOMIC and reinjection energy/estimated-accuracy curves.
- `existing_figures/QE_reinjection_1_vacancies.*`, `...2_vacancies.*`, `...4_vacancies.*`: original three-way boron vacancy trajectories, three sets per page.
- `figures/Boron_vacancy_placements.*`: nine placement maps, with removed zero-based indices and periodic/projection caveats.
- `figures/Al298_Fourier_comparison.*`, `Al933_Fourier_comparison.*`: newly styled maps from saved planes; no new FFT.
- `existing_figures/CASE/`: 12 retained cases × three existing figure types (SCF, Fourier spectra, Fourier maps), each PDF/PNG.
- `figures/CP2K_*`: code-disparity appendix figures and residual/energy trajectories.

### Detailed provenance

`sources/CASE/{case.json,mala.in,atomic.in}` preserves geometry and numerical inputs; defective cases also include `reinjection.in`. `sources/QE_manifest_retained.json` gives original field paths/hashes. `raw_logs/` contains the stdout actually rechecked. `sources/upstream_support/` copies existing small records from the previous support ZIP, including 12 import audits, converter/bridge source, actual pseudopotentials, stage records and original source audits. Historical scripts are evidence only; they are not instructions to launch a calculation or to reuse an embedded geometry unchecked.

The original numerical fields and large weights are intentionally not duplicated. Original workspace results, existing reports and remote repository files remain untouched. The new ZIP is a supplementary evidence package; it does not replace the supervisor's TeX or authorize new runs.

## 13. References for the writing agent

1. Fiedler and Cangi, **Retrained Models and Scripts for Aluminum at 298K and 933K**, RODARE (2024), [10.14278/rodare.2725](https://rodare.hzdr.de/record/2725): official pretrained aluminum source and stated retraining version/composition.
2. Fiedler and Cangi, **Boron data set for machine learning applications**, RODARE (2025), [10.14278/rodare.3746](https://rodare.hzdr.de/record/3746): official boron data/models source.
3. Cangi et al., **Materials Learning Algorithms (MALA): Scalable Machine Learning for Electronic Structure Calculations in Large-Scale Atomistic Simulations**, [arXiv:2411.19617v1](https://arxiv.org/html/2411.19617v1): implementation, published training split, training-cost context and hardware capabilities. Use the published journal bibliographic record if already present in the supervisor's BibTeX; the verified arXiv locator avoids inventing a journal DOI here.
4. Ellis et al., **Accelerating finite-temperature Kohn–Sham density functional theory with deep neural networks**, Phys. Rev. B **104**, 035120 (2021), [10.1103/PhysRevB.104.035120](https://doi.org/10.1103/PhysRevB.104.035120): original aluminum methodology.
5. **Machine learning the electronic structure of matter across temperatures**, Phys. Rev. B **108**, 125146 (2023), [10.1103/PhysRevB.108.125146](https://doi.org/10.1103/PhysRevB.108.125146): inter-snapshot shuffling / temperature-transfer context, as linked by the official model record.
6. [Official MALA training documentation](https://mala-project.github.io/mala/basic_usage/trainingmodel.html): reproducible high-level training workflow. Do not treat current docs as the exact historical execution environment of every saved checkpoint.
7. [QE 7.5 input reference](https://www.quantum-espresso.org/Doc/INPUT_PW.html) and [CP2K SCF input reference](https://manual.cp2k.org/trunk/CP2K_INPUT/FORCE_EVAL/DFT/SCF.html): definitions of initialization/mixing/convergence keywords; current docs do not replace frozen-run provenance.
8. Polfus et al., **Vacancy diffusion in palladium hydrides**, PCCP 23, 13680–13686 (2021), [10.1039/D1CP01960K](https://doi.org/10.1039/D1CP01960K): contextual defect-study example from the previous presentation, with the qualification in Section 6.

The quantitative experiment tables in this handoff are from saved local logs/analysis, not values copied from those publications. Bibliography entries and a concise evidence/source map are in `references.bib` and `sources/literature_evidence.json`.
