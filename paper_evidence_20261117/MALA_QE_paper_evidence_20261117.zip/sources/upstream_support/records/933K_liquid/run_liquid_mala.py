#!/usr/bin/env python3
"""Fresh density from the RODARE liquid-labeled checkpoint and explicit QE geometry.

The archive label alone does not establish liquid-only training provenance.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import pickle
import shutil
import time
from pathlib import Path

import numpy as np


MODEL_STEM = "Al_933K_liquid"


def clock() -> float:
    return time.perf_counter()


def rank_zero() -> bool:
    return os.environ.get("OMPI_COMM_WORLD_RANK", "0") == "0"


def record(path: Path, name: str, status: str, details: str) -> None:
    if not rank_zero():
        return
    with path.open("a", encoding="utf-8") as handle:
        handle.write(f"{name}\t{status}\t{details}\n")
    print(f"[{status}] {name}: {details}", flush=True)


def load_scaler(path: Path):
    with path.open("rb") as handle:
        scaler = pickle.load(handle)
    if not hasattr(scaler, "use_ddp"):
        scaler.use_ddp = False
    if not hasattr(scaler, "scale_minmax") and hasattr(scaler, "scale_normal"):
        scaler.scale_minmax = scaler.scale_normal
    return scaler


def cp2k_input(
    project: str,
    atoms,
    basis: Path,
    potential: Path,
    temperature: float,
    guess: str,
    cube_reference: str | None,
    max_scf: int,
) -> str:
    cell = np.asarray(atoms.cell.array, dtype=float)
    if not np.allclose(cell, np.diag(np.diag(cell)), atol=1.0e-8):
        raise RuntimeError("the validated CP2K input path requires an orthogonal cell")
    abc = np.diag(cell)
    coords = "\n".join(
        f"      Al {p[0]:.12f} {p[1]:.12f} {p[2]:.12f}"
        for p in np.asarray(atoms.positions, dtype=float)
    )
    external = ""
    if guess == "EXTERNAL_DENSITY":
        external = f"      EXTERNAL_DENSITY_FILE_NAME {cube_reference}\n"
    return f"""&GLOBAL
  PROJECT {project}
  RUN_TYPE ENERGY
  PRINT_LEVEL LOW
&END GLOBAL

&FORCE_EVAL
  METHOD Quickstep
  &DFT
    BASIS_SET_FILE_NAME {basis}
    POTENTIAL_FILE_NAME {potential}
    &SCF
      SCF_GUESS {guess}
{external}      EPS_SCF 1.0E-5
      MAX_SCF {max_scf}
      ADDED_MOS 64
      &MIXING
        METHOD BROYDEN_MIXING
        ALPHA 0.10
        NBUFFER 8
      &END MIXING
      &SMEAR
        METHOD FERMI_DIRAC
        ELECTRONIC_TEMPERATURE [K] {temperature:.10f}
      &END SMEAR
    &END SCF
    &POISSON
      PERIODIC XYZ
    &END POISSON
    &XC
      &XC_FUNCTIONAL PBE
      &END XC_FUNCTIONAL
    &END XC
    &MGRID
      CUTOFF 11000
      REL_CUTOFF 60
    &END MGRID
  &END DFT
  &SUBSYS
    &CELL
      ABC {abc[0]:.12f} {abc[1]:.12f} {abc[2]:.12f}
      PERIODIC XYZ
    &END CELL
    &COORD
      UNIT angstrom
{coords}
    &END COORD
    &KIND Al
      ELEMENT Al
      BASIS_SET DZVP-MOLOPT-SR-GTH
      POTENTIAL GTH-PBE
    &END KIND
  &END SUBSYS
&END FORCE_EVAL
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--qe-output", type=Path, required=True)
    parser.add_argument("--provenance-report", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--cp2k-data", type=Path, required=True)
    parser.add_argument("--cube-reference", required=True)
    args = parser.parse_args()
    if not os.environ.get("SLURM_JOB_ID") or os.uname().nodename.startswith("rosi"):
        raise RuntimeError("MALA inference requires a Slurm compute-node allocation")
    provenance = json.loads(args.provenance_report.read_text())
    # Training provenance controls the claim attached to the result. Keep the
    # official checkpoint binding even when that provenance is unresolved.
    for member, expected_hash in provenance["checkpoint_sha256"].items():
        if Path(member).name != member:
            raise RuntimeError("Provenance member must be a checkpoint filename")
        if hashlib.sha256((args.model_dir / member).read_bytes()).hexdigest() != expected_hash:
            raise RuntimeError(f"Checkpoint changed since provenance verification: {member}")
    required_members = {f"{MODEL_STEM}.{suffix}" for suffix in (
        "info.json", "params.json", "network.pth", "iscaler.pkl", "oscaler.pkl")}
    if set(provenance["checkpoint_sha256"]) != required_members:
        raise RuntimeError("Provenance report must bind all five checkpoint files")
    structure_sha256 = hashlib.sha256(args.qe_output.read_bytes()).hexdigest()
    if structure_sha256 != "d183ff40793975edf3d8ed8f8f2b537d5c1e5d7a9e2b71af6f06959f08c61c03":
        raise RuntimeError("QE geometry is not the frozen snapshot 9")
    args.run_dir.mkdir(parents=True, exist_ok=True)
    status = args.run_dir / "status.tsv"

    import torch
    from ase.units import Bohr
    from mala import Parameters
    from mala.datahandling.data_handler import DataHandler
    from mala.network.network import Network
    from mala.targets.cube_parser import read_cube
    from mala.targets.density import Density

    info_path = args.model_dir / f"{MODEL_STEM}.info.json"
    info = json.loads(info_path.read_text(encoding="utf-8"))

    params = Parameters.load_from_json(
        str(args.model_dir / f"{MODEL_STEM}.params.json"), force_no_ddp=True
    )
    if (
        isinstance(params.network.layer_activations, list)
        and len(params.network.layer_activations) == 1
    ):
        params.network.layer_activations = params.network.layer_activations[0]
    # MALA 1.2.1 applies the shared activation after the output Linear too.
    params.network.layer_activations_include_output_layer = True
    params.use_gpu = False
    params.use_lammps = True
    params.use_mpi = os.environ.get("MALA_USE_MPI", "0") == "1"

    input_scaler = load_scaler(args.model_dir / f"{MODEL_STEM}.iscaler.pkl")
    output_scaler = load_scaler(args.model_dir / f"{MODEL_STEM}.oscaler.pkl")
    data = DataHandler(
        params,
        input_data_scaler=input_scaler,
        output_data_scaler=output_scaler,
        clear_data=True,
    )
    data.target_calculator.read_additional_calculation_data(
        str(args.qe_output), data_type="espresso-out"
    )
    target = data.target_calculator
    atoms = target.atoms
    grid = [int(x) for x in target.grid_dimensions]
    n_grid = int(np.prod(grid))
    temperature = float(target.temperature)
    expected_electrons = float(target.number_of_electrons_exact)
    dataset_fermi = float(target.fermi_energy_dft)
    voxel = np.asarray(target.voxel.array, dtype=float)
    voxel_volume = abs(float(np.linalg.det(voxel)))
    if len(atoms) != 256 or not np.all(atoms.numbers == 13):
        raise RuntimeError(f"expected 256 Al atoms, got {len(atoms)}")
    if not np.all(atoms.pbc) or atoms.cell.volume <= 0:
        raise RuntimeError("invalid periodic liquid-Al structure")
    if not np.isfinite(atoms.positions).all():
        raise RuntimeError("atomic positions contain NaN/Inf")
    if grid != [200, 200, 200] or abs(expected_electrons - 768.0) > 1.0e-8:
        raise RuntimeError(f"unexpected snapshot grid or charge: {grid}, {expected_electrons}")
    if np.allclose(atoms.positions, np.asarray(info["atoms"]["positions"]), rtol=0, atol=1e-10):
        raise RuntimeError("snapshot 9 unexpectedly equals embedded checkpoint geometry")
    data.grid_dimension = grid
    data.grid_size = n_grid
    target = data.target_calculator

    input_dim = int(params.network.layer_sizes[0])
    ldos_points = int(params.targets.ldos_gridsize)
    descriptor_type = params.descriptors.descriptor_type
    twojmax = int(params.descriptors.bispectrum_twojmax)
    cutoff = float(params.descriptors.bispectrum_cutoff)
    if descriptor_type != "Bispectrum":
        raise RuntimeError(f"unexpected descriptor type: {descriptor_type}")

    record(
        status,
        "Liquid atomic structure",
        "PASS",
        f"atoms={len(atoms)}; cell_A={atoms.cell.array.tolist()}; pbc={atoms.pbc.tolist()}; "
        f"temperature_K={temperature:.12f}; source={args.qe_output}; sha256={structure_sha256}",
    )
    record(
        status,
        "RODARE liquid-labeled model configuration",
        "PASS",
        f"model={MODEL_STEM}; descriptor={descriptor_type}; twojmax={twojmax}; "
        f"cutoff_A={cutoff}; grid={grid}; input_dim={input_dim}; ldos_points={ldos_points}",
    )

    descriptor = data.descriptor_calculator
    start = clock()
    raw, local_size = descriptor.calculate_from_atoms(
        atoms,
        grid,
        working_directory=str(args.run_dir),
        keep_logs=True,
        use_fp64=True,
    )
    t_descriptor = clock() - start
    if params.use_mpi:
        from mala.common.parallelizer import get_rank

        raw = descriptor.gather_descriptors(raw)
        if get_rank() != 0:
            return 0
        params.use_mpi = False
    expected_features = input_dim + (
        3 if params.descriptors.descriptors_contain_xyz else 0
    )
    if raw.shape != tuple(grid) + (expected_features,):
        raise RuntimeError(
            f"descriptor shape {raw.shape} != {tuple(grid) + (expected_features,)}"
        )
    if not np.isfinite(raw).all():
        raise RuntimeError("descriptor contains NaN/Inf")
    lammps_log = getattr(descriptor, "_lammps_temporary_log", None)
    copied_log = args.run_dir / "lammps_snap.log"
    if lammps_log and Path(lammps_log).exists():
        shutil.copyfile(lammps_log, copied_log)
    if not copied_log.exists():
        raise RuntimeError("LAMMPS SNAP log was not preserved")
    record(
        status,
        "Fresh bispectrum descriptors",
        "PASS",
        f"backend=LAMMPS/SNAP; shape={list(raw.shape)}; local_size={local_size}; "
        f"T_descriptor={t_descriptor:.6f}s; precomputed_descriptors_used=False; log={copied_log}",
    )

    model_features = raw[..., 3:] if params.descriptors.descriptors_contain_xyz else raw
    flat = model_features.reshape(n_grid, input_dim)
    descriptor_tensor = torch.from_numpy(flat).float()
    data.input_data_scaler.transform(descriptor_tensor)
    network = Network.load_from_file(
        params, str(args.model_dir / f"{MODEL_STEM}.network.pth")
    )
    network.eval()
    network.to(params.device)
    torch.set_num_threads(max(1, int(os.environ.get("MALA_TORCH_THREADS", "8"))))
    batch_size = int(os.environ.get("MALA_INFERENCE_BATCH", "20000"))
    predicted = np.empty((n_grid, ldos_points), dtype=np.float32)
    start = clock()
    with torch.inference_mode():
        for first in range(0, n_grid, batch_size):
            last = min(first + batch_size, n_grid)
            output = network(descriptor_tensor[first:last].to(params.device)).to("cpu")
            output = data.output_data_scaler.inverse_transform(output, as_numpy=True)
            predicted[first:last] = np.asarray(output, dtype=np.float32)
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    t_inference = clock() - start
    predicted_ldos = target.restrict_data(predicted).reshape(
        tuple(grid) + (ldos_points,)
    )
    if not np.isfinite(predicted_ldos).all():
        raise RuntimeError("fresh LDOS contains NaN/Inf")
    record(
        status,
        "Fresh MALA inference",
        "PASS",
        f"LDOS_shape={list(predicted_ldos.shape)}; T_inference={t_inference:.6f}s; "
        f"device={params.device}; precomputed_ldos_used=False; network=trained .pth",
    )

    start = clock()
    target.read_from_array(predicted_ldos)
    fermi = float(
        target.get_self_consistent_fermi_energy(
            predicted_ldos,
            voxel=target.voxel,
            temperature=temperature,
            energy_integration_method="analytical",
        )
    )
    density = target.get_density(
        predicted_ldos,
        fermi_energy=fermi,
        temperature=temperature,
        conserve_dimensions=True,
        integration_method="analytical",
    )
    t_density = clock() - start
    density = np.asarray(density[..., 0], dtype=np.float64)
    if density.shape != tuple(grid) or not np.isfinite(density).all():
        raise RuntimeError(f"density shape/finite check failed: {density.shape}")
    integrated = float(density.sum() * voxel_volume)
    if abs(integrated - expected_electrons) > 1.0e-4:
        raise RuntimeError(
            f"integrated density {integrated} differs from {expected_electrons} electrons"
        )
    density_path = args.run_dir / "fresh_liquid_density.npy"
    np.save(density_path, density.reshape((n_grid, 1)))
    record(
        status,
        "LDOS to density",
        "PASS",
        f"shape={list(density.shape)}; fermi_eV={fermi:.12f}; "
        f"dataset_fermi_eV={dataset_fermi:.12f}; "
        f"electrons={integrated:.12f}; target_electrons={expected_electrons:.1f}; "
        f"T_density={t_density:.6f}s",
    )

    serializer = Density(params)
    serializer.electrons_per_atom = float(info["electrons_per_atom"])
    serializer.read_additional_calculation_data([atoms, grid], "atoms+grid")
    cube = args.run_dir / "mala_liquid_density.cube"
    start = clock()
    serializer.write_to_cube(
        str(cube),
        density_data=density[..., None] * (Bohr**3),
        atoms=atoms,
        grid_dimensions=grid,
    )
    t_cube = clock() - start
    cube_data, cube_meta = read_cube(str(cube))
    if tuple(cube_data.shape) != tuple(grid) or not np.isfinite(cube_data).all():
        raise RuntimeError(f"cube validation failed: {cube_data.shape}")
    cube_vectors = np.asarray(
        [list(cube_meta["xvec"]), list(cube_meta["yvec"]), list(cube_meta["zvec"])], dtype=float
    )
    if not np.allclose(cube_vectors, voxel / Bohr, rtol=0, atol=1.0e-6):
        raise RuntimeError("cube vectors do not match snapshot voxel vectors")
    if not np.allclose(cube_data, density * Bohr**3, rtol=5e-6, atol=1e-12):
        raise RuntimeError("cube full-sample ordering or density units differ from prediction")
    cube_electrons = float(cube_data.sum() * abs(np.linalg.det(cube_vectors)))
    if abs(cube_electrons - expected_electrons) > 0.02:
        raise RuntimeError(f"cube charge changed during serialization: {cube_electrons}")
    record(
        status,
        "CP2K cube",
        "PASS",
        f"path={cube}; shape={list(cube_data.shape)}; bytes={cube.stat().st_size}; "
        f"T_cube_write={t_cube:.6f}s; voxel_bohr={cube_vectors.tolist()}",
    )

    basis = args.cp2k_data / "BASIS_MOLOPT"
    potential = args.cp2k_data / "GTH_POTENTIALS"
    (args.run_dir / "cp2k_external_density.inp").write_text(
        cp2k_input(
            "al933_liquid_external",
            atoms,
            basis,
            potential,
            temperature,
            "EXTERNAL_DENSITY",
            args.cube_reference,
            50,
        ),
        encoding="utf-8",
    )
    (args.run_dir / "cp2k_external_probe.inp").write_text(
        cp2k_input(
            "al933_liquid_probe",
            atoms,
            basis,
            potential,
            temperature,
            "EXTERNAL_DENSITY",
            args.cube_reference,
            2,
        ),
        encoding="utf-8",
    )
    (args.run_dir / "cp2k_atomic_guess.inp").write_text(
        cp2k_input(
            "al933_liquid_atomic",
            atoms,
            basis,
            potential,
            temperature,
            "ATOMIC",
            None,
            50,
        ),
        encoding="utf-8",
    )
    metadata = {
        "model": MODEL_STEM,
        "model_info": str(info_path.resolve()),
        "structure_source": str(args.qe_output.resolve()),
        "structure_sha256": structure_sha256,
        "model_info_geometry_used": False,
        "provenance_report": str(args.provenance_report.resolve()),
        "liquid_only_training_verified": provenance.get("liquid_only_training_verified") is True,
        "provenance_status": provenance.get("status", "UNRESOLVED"),
        "checkpoint_sha256": provenance["checkpoint_sha256"],
        "atoms": len(atoms),
        "cell_angstrom": atoms.cell.array.tolist(),
        "pbc": atoms.pbc.tolist(),
        "grid": grid,
        "voxel_angstrom": voxel.tolist(),
        "temperature_K": temperature,
        "fermi_energy_eV_self_consistent": fermi,
        "fermi_energy_eV_dataset": dataset_fermi,
        "electrons_expected": expected_electrons,
        "electrons_integrated": integrated,
        "electrons_cube": cube_electrons,
        "density_units": "electrons/angstrom^3",
        "cube_density_units": "electrons/bohr^3",
        "cube_full_sample_ordering_checked": True,
        "density": str(density_path.resolve()),
        "cube": str(cube.resolve()),
        "descriptor_source": "ASE Atoms -> MALA LAMMPS/SNAP",
        "precomputed_descriptors_used": False,
        "precomputed_ldos_used": False,
        "T_descriptor": t_descriptor,
        "T_inference": t_inference,
        "T_density": t_density,
        "T_cube_write": t_cube,
    }
    (args.run_dir / "mala_metadata.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True), encoding="utf-8"
    )
    record(
        status,
        "CP2K inputs",
        "PASS",
        f"external={args.run_dir / 'cp2k_external_density.inp'}; "
        f"atomic={args.run_dir / 'cp2k_atomic_guess.inp'}; metadata={args.run_dir / 'mala_metadata.json'}",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
