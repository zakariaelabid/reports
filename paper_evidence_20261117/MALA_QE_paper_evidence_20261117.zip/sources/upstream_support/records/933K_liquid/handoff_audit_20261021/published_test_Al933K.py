import mala
import numpy as np

# First we load Parameters and network.
run = "Al_933K_XX"
parameters, network, inference_data_handler, tester = mala.Tester.load_run(run, path=...)

# Some parameters are different, and we need to ensure the LDOS parameters
# are correct. Lazy loading should be used, as there is no need to keep
# all test snapshots in RAM all the time.
parameters.data.use_lazy_loading = True
parameters.targets.pseudopotential_path = "/home/fiedle09/tools/PPs/pbesol/"
# Build a data handler and fill it with data.
inference_data_handler.clear_data()

test_data = list(range(0, 20))

# Load data.
snap_path = ...
ldos_path = ...
out_path = ...

for test_snapshot in test_data:
    inference_data_handler.add_snapshot("Al_snapshot"
                                        + str(test_snapshot)+".in.npy",
                                        snap_path,
                                        "Al_snapshot"
                                        + str(test_snapshot)+".out.npy",
                                        ldos_path,
                                        add_snapshot_as="te",
                                        calculation_output_file=out_path +
                                                                "Al_snapshot"
                                                                +str(test_snapshot)+".out",
                                        output_units="1/(Ry*Bohr^3)")


inference_data_handler.prepare_data()
tester = mala.Tester(parameters, network, inference_data_handler)
tester.observables_to_test = ["total_energy_full", "band_energy_full"]
results_array = tester.test_all_snapshots()
np.savetxt("results_"+run+".csv", results_array["total_energy_full"], delimiter=",")
np.savetxt("bresults_"+run+".csv", results_array["band_energy_full"], delimiter=",")

ldos_calculator: mala.LDOS
ldos_calculator = tester.target_calculator

for test_snapshot in [7, 17]:
    actual_ldos, predicted_ldos = tester.predict_targets(test_snapshot)
    ldos_calculator.read_from_array(actual_ldos)
    np.save("actual_density_"+run+"snapshot"+str(test_snapshot), ldos_calculator.density)
    np.save("actual_dos_"+run+"snapshot"+str(test_snapshot), ldos_calculator.density_of_states)
    ldos_calculator.read_from_array(predicted_ldos)
    np.save("predicted_density_"+run+"snapshot"+str(test_snapshot), ldos_calculator.density)
    np.save("predicted_dos_"+run+"snapshot"+str(test_snapshot), ldos_calculator.density_of_states)
