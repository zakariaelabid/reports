#!/usr/bin/env bash
# Source only inside a compute allocation. Shared dependencies remain read-only.
set -euo pipefail
qe_work_root=/data/home2/elabid32/workspace/mala_aluminium/qe_native_20261103
source /etc/profile.d/lmod.sh
module purge
for qe_core_path in /data/rosi/shared/eb/easybuild/genoa/modules/all/Core/*; do
  if [[ -d "$qe_core_path" ]]; then module use "$qe_core_path"; fi
done
module load GCC/14.3.0 OpenMPI/5.0.8 QuantumESPRESSO/7.5
export PATH="$qe_work_root/install/bin:$PATH"
export LD_LIBRARY_PATH="$qe_work_root/install/lib:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export BLIS_NUM_THREADS=1 FLEXIBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export OMPI_MCA_pml=ob1 OMPI_MCA_btl=self,sm
export QE_PRIVATE_ROOT="$qe_work_root"
