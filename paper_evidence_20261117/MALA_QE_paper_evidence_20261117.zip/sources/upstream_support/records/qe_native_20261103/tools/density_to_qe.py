"""Cube/NPY -> QE7.5 native density, retaining exact case-grid G ordering.

Requires a native charge-density.hdf5 plus its matching QE XML grid template.
The template's electronic values are completely overwritten, not fitted/used.
Only unpolarized norm-conserving semilocal cases are supported in this study.
Run array/FFT work in sbatch allocations, never on the login node.
"""
import argparse,hashlib,json,os,shutil,subprocess,xml.etree.ElementTree as ET
from decimal import Decimal
from pathlib import Path
import numpy as np
from scipy.signal import resample

BOHR_A=0.529177210903 # QE7.5 Modules/constants.f90, CODATA2018
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def xml_grid(path):
 root=ET.parse(path).getroot()
 def nodes(tag):return [e for e in root.iter() if e.tag.split('}')[-1]==tag]
 a=nodes('atomic_structure')[-1];cell=next(e for e in a if e.tag.split('}')[-1]=='cell')
 cell=np.array([[float(x) for x in e.text.split()] for e in cell])
 fft=nodes('fft_grid')[-1];shape=tuple(int(fft.attrib['nr'+str(i)]) for i in [1,2,3])
 assert cell.shape==(3,3)
 pos=next(e for e in a if e.tag.split('}')[-1]=='atomic_positions')
 positions=np.array([[float(x) for x in e.text.split()] for e in pos]);symbols=[e.attrib['name'] for e in pos]
 return cell,shape,positions,symbols
def cube(path):
 with open(path) as f:
  next(f);next(f);a=next(f).split();nat=int(a[0]);origin=np.array([float(x) for x in a[1:4]])
  assert nat>0 and np.max(abs(origin))<1e-12,'Only ordinary scalar cubes with zero origin are supported'
  shape=[];voxel=[];uncertainty=[]
  for _ in range(3):
   s=next(f).split();assert int(s[0])>0,'Cube coordinates must be in bohr';shape.append(int(s[0]));voxel.append([float(x) for x in s[1:4]])
   uncertainty.append([0.5*10.0**Decimal(x).as_tuple().exponent*int(s[0])+1e-12 for x in s[1:4]])
  atoms=[next(f).split() for _ in range(nat)]
  numbers=[int(a[0]) for a in atoms];positions=np.array([[float(x) for x in a[2:5]] for a in atoms])
  position_uncertainty=np.array([[0.5*10.0**Decimal(x).as_tuple().exponent+1e-12 for x in a[2:5]] for a in atoms])
  a=np.fromstring(f.read(),sep=' ');assert a.size==np.prod(shape)
 return a.reshape(shape),np.array(voxel)*np.array(shape)[:,None],np.array(uncertainty),numbers,positions,position_uncertainty
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for arg in ['source','template','qe-xml','output']:p.add_argument('--'+arg,required=True)
 p.add_argument('--units',required=True,choices=['e/bohr3','e/A3']);p.add_argument('--source-shape',type=int,nargs=3)
 p.add_argument('--source-cell-json',help='Required for NPY: case-specific metadata with cell_A, positions_A and numbers; never select geometry from model metadata')
 p.add_argument('--target-electrons',required=True,type=float);p.add_argument('--bridge',required=True)
 p.add_argument('--allow-negative',action='store_true');args=p.parse_args()
 assert os.environ.get('SLURM_JOB_ID'),'Density/FFT processing must run on a compute node'
 src=Path(args.source).resolve();dst=Path(args.output).resolve();template=Path(args.template).resolve()
 assert src!=dst and template!=dst and not dst.exists(),'Use a fresh output; never overwrite a source/template'
 cell,shape,qe_positions,qe_symbols=xml_grid(args.qe_xml);omega=abs(np.linalg.det(cell));target=args.target_electrons
 number_to_symbol={5:'B',13:'Al'}
 if src.suffix=='.npy':
  assert args.source_cell_json,'NPY has no geometry: provide --source-cell-json with explicit case-specific cell_A'
  source_metadata=json.loads(Path(args.source_cell_json).read_text())
  assert np.max(abs(np.array(source_metadata['cell_A'])/BOHR_A-cell))<1e-7,'NPY case metadata and QE cell mismatch'
  source_positions=np.array(source_metadata['positions_A'])/BOHR_A
  source_numbers=source_metadata['numbers'];position_uncertainty=np.full(source_positions.shape,1e-7)
  rho=np.load(src,allow_pickle=False)
  if rho.ndim!=3:
   assert args.source_shape and rho.size==np.prod(args.source_shape);rho=rho.reshape(args.source_shape)
  source_cell=None
 else:
  rho,source_cell,cell_uncertainty,source_numbers,source_positions,position_uncertainty=cube(src)
  assert args.units=='e/bohr3','Ordinary bohr-coordinate QE/CP2K cubes use e/bohr3'
 if source_cell is not None:
  assert np.all(abs(source_cell-cell)<=cell_uncertainty),'Cube and QE template cells differ beyond their exact printed-header rounding intervals'
 assert [number_to_symbol[n] for n in source_numbers]==qe_symbols,'Atom count/order/species mismatch'
 assert source_positions.shape==qe_positions.shape
 displacement=source_positions-qe_positions
 fractional=displacement@np.linalg.inv(cell);displacement-=np.rint(fractional)@cell
 assert np.all(abs(displacement)<=position_uncertainty+1e-10),'Source atoms and QE template do not describe the same snapshot/defect configuration'
 rho=np.asarray(rho,dtype=np.float64)
 if args.units=='e/A3':rho*=BOHR_A**3
 assert np.isfinite(rho).all()
 if not args.allow_negative:assert rho.min()>=-1e-10,'Negative source density; no implicit clipping is performed'
 source_shape=list(rho.shape);charge=float(rho.mean()*omega)
 assert abs(charge-target)<max(1e-5,1e-8*target),(charge,target,'Wrong charge/units/geometry; no automatic normalization')
 for axis,n in enumerate(shape):
  if rho.shape[axis]!=n:rho=resample(rho,n,axis=axis)
 dst.parent.mkdir(parents=True,exist_ok=True);work=dst.parent.parent/(dst.parent.name+'_'+dst.stem+'_conversion');work.mkdir(exist_ok=False)
 prefix=work/'template';subprocess.run([args.bridge,'dump',str(template),str(prefix)],check=True)
 meta=json.loads(prefix.with_suffix('.json').read_text());ng=meta['ngm_g']
 mill=np.fromfile(str(prefix)+'.miller.i32',dtype=np.int32).reshape(ng,3)
 reciprocal=np.array(meta['reciprocal_vectors_bohr'])
 assert np.max(abs(cell@reciprocal.T-2*np.pi*np.eye(3)))<1e-8,'Template reciprocal lattice and QE XML mismatch'
 assert np.all(np.max(abs(mill),axis=0)<np.array(shape)/2),'Unexpected Nyquist G vector: refuse ambiguous aliasing'
 idx=tuple((mill%np.array(shape)).T)
 fft=np.fft.fftn(rho)/rho.size;coeff=np.asarray(fft[idx],dtype=np.complex128)
 g0=np.flatnonzero(np.all(mill==0,axis=1));assert len(g0)==1
 assert abs(coeff[g0[0]].real*omega-target)<max(1e-5,1e-8*target)
 coeff.view(np.float64).tofile(work/'new.rhog.f64')
 shutil.copy2(template,dst)
 subprocess.run([args.bridge,'replace',str(dst),str(work/'new.rhog.f64')],check=True)
 check=work/'written';subprocess.run([args.bridge,'dump',str(dst),str(check)],check=True)
 assert np.array_equal(np.fromfile(str(check)+'.rhog.f64',dtype=np.float64),coeff.view(np.float64))
 assert sha(str(check)+'.miller.i32')==sha(str(prefix)+'.miller.i32')
 assert json.loads(check.with_suffix('.json').read_text())==meta
 reconstructed=np.zeros(shape,dtype=np.complex128);reconstructed[idx]=coeff
 if meta['gamma_only']:reconstructed[tuple((-mill%np.array(shape)).T)]=coeff.conj()
 represented=np.fft.ifftn(reconstructed)*rho.size
 assert np.max(abs(represented.imag))<1e-9
 dropped=np.linalg.norm(represented.real-rho)/np.linalg.norm(rho)
 result=dict(status='PASS',source=str(src),source_sha256=sha(src),template=str(template),template_sha256=sha(template),QE_XML_sha256=sha(args.qe_xml),source_shape=source_shape,target_shape=shape,source_units=args.units,charge_e=charge,target_electrons=target,output_charge_e=float(coeff[g0[0]].real*omega),negative_native_points=int((represented.real<0).sum()),minimum_native_density=float(represented.real.min()),QE_G_sphere_projection_relative_L2=float(dropped),nspin=1,gamma_only=meta['gamma_only'],G_vectors=ng,all_serialized_coefficients_exact=True,all_template_geometry_and_Miller_metadata_unchanged=True,charge_normalization=False,density_clipping=False,converged_reference_used_for_fitting=False,template_role='Grid/G-vector ordering only; every electronic coefficient overwritten',output=str(dst),output_sha256=sha(dst))
 result['source_atom_count_species_order_and_periodic_positions_match_QE_XML']=True
 (work/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2),flush=True)
if __name__=='__main__':main()
