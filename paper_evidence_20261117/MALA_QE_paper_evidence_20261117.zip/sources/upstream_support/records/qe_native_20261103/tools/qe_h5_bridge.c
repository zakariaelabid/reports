/* Small native-HDF5 helper, compiled on compute nodes; no QE engine changes. */
#include <hdf5.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define CHECK(x) do { if(!(x)){fprintf(stderr,"HDF5 bridge check failed: %s at %d\n",#x,__LINE__);exit(2);} }while(0)
static void vector(hid_t d,const char *name,double *v){hid_t a=H5Aopen(d,name,H5P_DEFAULT);CHECK(a>=0);hid_t t=H5Aget_type(a);CHECK(t>=0);if(H5Tget_class(t)==H5T_ARRAY){CHECK(H5Tget_array_ndims(t)==1);hsize_t dims[1];H5Tget_array_dims2(t,dims);CHECK(dims[0]==3);hid_t mem=H5Tarray_create2(H5T_NATIVE_DOUBLE,1,dims);CHECK(mem>=0);CHECK(H5Aread(a,mem,v)>=0);H5Tclose(mem);}else{CHECK(H5Aread(a,H5T_NATIVE_DOUBLE,v)>=0);}H5Tclose(t);H5Aclose(a);}
static int intattr(hid_t f,const char*n){int x;hid_t a=H5Aopen(f,n,H5P_DEFAULT);CHECK(a>=0);CHECK(H5Aread(a,H5T_NATIVE_INT,&x)>=0);H5Aclose(a);return x;}
int main(int argc,char**argv){
 CHECK(argc==4);hid_t f=H5Fopen(argv[2],strcmp(argv[1],"replace")==0?H5F_ACC_RDWR:H5F_ACC_RDONLY,H5P_DEFAULT);CHECK(f>=0);
 int n=intattr(f,"ngm_g"),spin=intattr(f,"nspin");CHECK(n>0&&spin==1);
 hid_t rho=H5Dopen2(f,"rhotot_g",H5P_DEFAULT);CHECK(rho>=0);hid_t sp=H5Dget_space(rho);hssize_t count=H5Sget_simple_extent_npoints(sp);CHECK(count==2*(hssize_t)n);H5Sclose(sp);
 double *r=malloc((size_t)2*n*sizeof(double));CHECK(r);
 if(strcmp(argv[1],"replace")==0){
  FILE*b=fopen(argv[3],"rb");CHECK(b);CHECK(fread(r,sizeof(double),(size_t)2*n,b)==(size_t)2*n);CHECK(fgetc(b)==EOF);fclose(b);
  for(size_t i=0;i<(size_t)2*n;i++)CHECK(isfinite(r[i]));
  CHECK(H5Dwrite(rho,H5T_NATIVE_DOUBLE,H5S_ALL,H5S_ALL,H5P_DEFAULT,r)>=0);
 }else{
  CHECK(strcmp(argv[1],"dump")==0);CHECK(H5Dread(rho,H5T_NATIVE_DOUBLE,H5S_ALL,H5S_ALL,H5P_DEFAULT,r)>=0);
  char path[4096];snprintf(path,sizeof(path),"%s.rhog.f64",argv[3]);FILE*b=fopen(path,"wb");CHECK(b);CHECK(fwrite(r,sizeof(double),(size_t)2*n,b)==(size_t)2*n);fclose(b);
  hid_t m=H5Dopen2(f,"MillerIndices",H5P_DEFAULT);CHECK(m>=0);hid_t ms=H5Dget_space(m);hsize_t dims[2];CHECK(H5Sget_simple_extent_ndims(ms)==2);H5Sget_simple_extent_dims(ms,dims,NULL);CHECK(dims[0]==(hsize_t)n&&dims[1]==3);H5Sclose(ms);
  int*idx=malloc((size_t)3*n*sizeof(int));CHECK(sizeof(int)==4&&idx);CHECK(H5Dread(m,H5T_NATIVE_INT,H5S_ALL,H5S_ALL,H5P_DEFAULT,idx)>=0);
  snprintf(path,sizeof(path),"%s.miller.i32",argv[3]);b=fopen(path,"wb");CHECK(b);CHECK(fwrite(idx,sizeof(int),(size_t)3*n,b)==(size_t)3*n);fclose(b);free(idx);
  hid_t a=H5Aopen(f,"gamma_only",H5P_DEFAULT);CHECK(a>=0);hid_t type=H5Aget_type(a);size_t sz=H5Tget_size(type);CHECK(sz<64);char gamma[65]={0};CHECK(H5Aread(a,type,gamma)>=0);H5Tclose(type);H5Aclose(a);
  double bg[9];vector(m,"bg1",bg);vector(m,"bg2",bg+3);vector(m,"bg3",bg+6);
  snprintf(path,sizeof(path),"%s.json",argv[3]);b=fopen(path,"w");CHECK(b);fprintf(b,"{\"ngm_g\":%d,\"nspin\":%d,\"gamma_only\":%s,\"reciprocal_vectors_bohr\":[",n,spin,strstr(gamma,"TRUE")||strstr(gamma,"true")?"true":"false");
  for(int i=0;i<3;i++)fprintf(b,"%s[%.17g,%.17g,%.17g]",i?",":"",bg[3*i],bg[3*i+1],bg[3*i+2]);fprintf(b,"]}\n");fclose(b);H5Dclose(m);
 }
 free(r);H5Dclose(rho);H5Fclose(f);return 0;
}
