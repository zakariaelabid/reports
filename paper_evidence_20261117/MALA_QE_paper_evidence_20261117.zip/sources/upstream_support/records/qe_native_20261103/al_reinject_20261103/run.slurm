#!/usr/bin/env bash
#SBATCH --job-name=QE_Al_density_reinject
#SBATCH --partition=cpu-genoa-int
#SBATCH --account=default
#SBATCH --qos=qos_default
#SBATCH --nodes=1
#SBATCH --nodelist=cge042
#SBATCH --ntasks=8
#SBATCH --cpus-per-task=1
#SBATCH --hint=nomultithread
#SBATCH --mem=40G
#SBATCH --time=03:15:00
#SBATCH --output=/data/home2/elabid32/workspace/mala_aluminium/qe_native_20261103/al_reinject_20261103/job-%j.log
set -Eeuo pipefail
source /data/home2/elabid32/workspace/mala_aluminium/qe_native_20261103/runtime.sh
module -t list 2>"$QE_PRIVATE_ROOT/al_reinject_20261103/modules-${SLURM_JOB_ID}.txt"
exec /usr/bin/python3 "$QE_PRIVATE_ROOT/al_reinject_20261103/run.py"
