"""Fresh-wavefunction density-only QE controls, Al298 then Al933.

Only native converged density is copied. The source input is changed solely
from startingpot=atomic to startingpot=file, in a fresh isolated directory.
"""
import csv,hashlib,json,os,re,shutil,subprocess,time,xml.etree.ElementTree as ET
from pathlib import Path
R=Path(__file__).resolve().parent;Q=R.parent
assert os.environ.get('SLURM_JOB_ID')
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def trajectory(text):
 rows=[];current=None
 for line in text.splitlines():
  m=re.search(r'iteration #\s*(\d+)',line)
  if m:current=dict(iteration=int(m[1]));rows.append(current)
  if current is not None:
   for key,pattern in [('energy_Ry',r'total energy\s*=\s*([-+\d.Ee]+)'),('estimated_SCF_accuracy_Ry',r'estimated scf accuracy\s*<\s*([-+\d.Ee]+)')]:
    m=re.search(pattern,line)
    if m:current[key]=float(m[1])
 return rows
def timer(text,label):
 m=re.search(r'^\s*'+label+r'\s*:\s*([\d.]+)s CPU\s+([\d.]+)s WALL',text,re.M);assert m,label
 return dict(printed_CPU_seconds=float(m[1]),wall_seconds=float(m[2]),CPU_scope='QE printed timer, not aggregate rank CPU time')
def bindings(text):return sorted(re.findall(r'Rank (\d+) bound to package\[(\d+)\]\[core:(\d+)\]',text))
def main():
 ranks=int(os.environ['SLURM_NTASKS']);assert ranks==8
 run=R/('run-'+os.environ['SLURM_JOB_ID']);run.mkdir(exist_ok=False)
 state=dict(status='PREPARING',job=os.environ['SLURM_JOB_ID'],host=os.uname().nodename,MPI_ranks=ranks,threads=1,memory_request_GiB=int(os.environ['SLURM_MEM_PER_NODE'])/1024,sequence=['Al298','Al933'],fresh_MALA_inference=False,new_density_conversion=False)
 save(run/'status.json',state);save(R/'latest_run.json',dict(job=state['job'],folder=str(run)))
 exe=Q/'install/bin/pw.x';assert sha(exe)=='5b9e3e77bd823d87b818fc932eef52bfea45049419277a4a34727726f7fcb203'
 assert hashlib.md5((Q/'pseudopotentials/Al.sr-pbesol.upf').read_bytes()).hexdigest()=='4b95ef907ba2fc50e54ad0216b4f2438'
 frozen=run/'frozen';frozen.mkdir()
 for p in [Path(__file__),R/'run.slurm',Q/'runtime.sh']:shutil.copy2(p,frozen/p.name)
 cases=[('Al298',1,Q/'al298_mala_20261103/atomic-817372'),('Al933',9,Q/'al933_mala_20261103/atomic-817432')];results={}
 try:
  for label,snapshot,source in cases:
   prior=json.loads((source/'results.json').read_text());assert prior['status']=='CONVERGED'
   old=(source/'atomic/input.in').read_text();assert old.count("startingpot='atomic'")==1
   new=old.replace("startingpot='atomic'","startingpot='file'");assert new.replace("startingpot='file'","startingpot='atomic'")==old
   folder=run/label;folder.mkdir();(folder/'input.in').write_text(new)
   source_native=source/'atomic/scratch/case.save/charge-density.hdf5';expected=json.loads((source/'comparison.json').read_text())['final_native_density_sha256']['ATOMIC'];assert sha(source_native)==expected
   dest=folder/'scratch/case.save/charge-density.hdf5';dest.parent.mkdir(parents=True);shutil.copy2(source_native,dest);assert sha(dest)==expected
   assert set(p.name for p in dest.parent.iterdir())=={'charge-density.hdf5'}
   audit=dict(status='PASS',system=label,snapshot=snapshot,source_branch='Converged matched ATOMIC QE branch',source_run=str(source),source_native_density=str(source_native),source_density_sha256=expected,source_iterations=prior['iterations'],source_final_energy_Ry=prior['final_energy_Ry'],only_input_change="startingpot='atomic' -> startingpot='file'",source_input_sha256=sha(source/'atomic/input.in'),reinjection_input_sha256=sha(folder/'input.in'),no_XML_wavefunctions_or_mixing_history_copied=True,fresh_wavefunctions='atomic+random',restart_mode='from_scratch',diago_thr_init_Ry=1e-5,cutoffs_Ry=[100,400],grid=[200,200,200],threshold_Ry=.000256)
   save(folder/'input_audit.json',audit);state.update(status='SCF_RUNNING',active_case=label);save(run/'status.json',state)
   args=[str(Path(os.environ['EBROOTOPENMPI'])/'bin/mpirun'),'-np','8','--bind-to','core','--map-by','core','--report-bindings',str(exe),'-in','input.in']
   start=time.monotonic();peak=0;maxranks=0;libs=set();log=folder/'output.out'
   with log.open('w') as f:
    p=subprocess.Popen(args,cwd=folder,stdout=f,stderr=subprocess.STDOUT)
    while p.poll() is None:
     total=0;count=0
     for path in Path('/proc').glob('[0-9]*'):
      try:
       if path.joinpath('exe').resolve()!=exe:continue
       if ('SLURM_JOB_ID='+state['job']).encode()+b'\0' not in path.joinpath('environ').read_bytes():continue
       txt=path.joinpath('status').read_text();m=re.search(r'VmRSS:\s+(\d+)',txt)
       if m:total+=int(m[1]);count+=1
       if count==1:
        for line in path.joinpath('maps').read_text().splitlines():
         if '/' in line and '.so' in line:libs.add(line.split()[-1])
      except (FileNotFoundError,PermissionError,ProcessLookupError):continue
     peak=max(peak,total);maxranks=max(maxranks,count)
     save(run/'live.json',dict(case=label,elapsed_seconds=time.monotonic()-start,sampled_sum_rank_RSS_GiB=total/1024**2,maximum_sampled_sum_rank_RSS_GiB=peak/1024**2,observed_ranks=count,trajectory=trajectory(log.read_text(errors='replace'))))
     time.sleep(2)
   wall=time.monotonic()-start;out=log.read_text();rows=trajectory(out);matches=re.findall(r'convergence has been achieved in\s+(\d+)',out);energies=re.findall(r'!\s+total energy\s*=\s*([-+\d.Ee]+)',out)
   converged=p.returncode==0 and 'JOB DONE.' in out and bool(matches)
   assert re.findall(r'Number of MPI processes:\s+(\d+)',out)==['8']
   assert out.count('The initial density is read from file')==1 and 'Cannot read rho' not in out and 'renormalised' not in out,'Density import failed or changed charge'
   result=dict(status='CONVERGED' if converged else 'NOT_CONVERGED',system=label,snapshot=snapshot,iterations=int(matches[-1]) if matches else len(rows),final_energy_Ry=float(energies[-1]) if energies else None,trajectory=rows,process_wall_seconds=wall,maximum_sampled_sum_rank_RSS_GiB=peak/1024**2,maximum_observed_QE_ranks=maxranks,loaded_libraries=sorted(libs),returncode=p.returncode,density_import_confirmed=True,source=audit)
   save(folder/'results.json',result)
   with (folder/'trajectory.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=['iteration','energy_Ry','estimated_SCF_accuracy_Ry']);w.writeheader();w.writerows(rows)
   assert converged,(label,'No genuine convergence; no restart or next case launched')
   xml=ET.parse(folder/'scratch/case.save/data-file-schema.xml').getroot();occs=[list(map(float,e.text.split())) for e in xml.iter() if e.tag.split('}')[-1]=='occupations' and e.text and len(e.text.split())>1];highest=max(a[-1] for a in occs);assert highest<1e-8
   result.update(final_estimated_error_Ry=rows[-1]['estimated_SCF_accuracy_Ry'],QE_electrons_timer=timer(out,'electrons'),QE_full_timer=timer(out,'PWSCF'),final_fermi_eV=float(re.findall(r'the Fermi energy is\s+([-\d.]+)',out)[-1]),highest_band_occupation=highest,absolute_energy_difference_from_source_Ry=abs(result['final_energy_Ry']-prior['final_energy_Ry']),identical_rank_core_bindings_to_source=bindings(out)==bindings((source/'atomic/scf.out').read_text()),loaded_library_paths_identical_to_source=set(libs)==set(prior['loaded_libraries']),fresh_wavefunctions=True,density_only_restart=True)
   save(folder/'results.json',result);results[label]=result;save(run/'summary.json',dict(status='RUNNING',job=state['job'],completed=results));print(json.dumps({k:v for k,v in result.items() if k not in ['loaded_libraries','trajectory','source']}),flush=True)
  state.update(status='COMPLETE',active_case=None);save(run/'status.json',state);save(run/'summary.json',dict(status='COMPLETE',job=state['job'],results=results));save(R/'summary.json',dict(status='COMPLETE',job=state['job'],results=results))
 except BaseException as exc:
  state.update(status='FAILED',error=repr(exc));save(run/'status.json',state);raise
if __name__=='__main__':main()
