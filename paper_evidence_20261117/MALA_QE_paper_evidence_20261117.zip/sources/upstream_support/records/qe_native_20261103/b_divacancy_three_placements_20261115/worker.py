"""Frozen-checkpoint vacancy inference. No CP2K, QE, SCF, relaxation or training."""
from common import *
import argparse
import gc
import pickle

def load_model():
    import mala,torch
    from mala.datahandling.data_handler import DataHandler
    pth=ROOT/CONFIG['model']
    params=mala.Parameters.load_from_json(str(pth)+'.params.json',force_no_ddp=True)
    assert params.network.layer_activations==['LeakyReLU']
    params.network.layer_activations='LeakyReLU'
    params.use_gpu=False;params.use_mpi=True;params.use_lammps=True
    params.running.use_mixed_precision=False;params.running.inference_data_grid=CONFIG['mesh']
    params.running.mini_batch_size=1000
    net=mala.Network.load_from_file(params,str(pth)+'.network.pth');net.eval()
    original=torch.load(str(pth)+'.network.pth',map_location='cpu',weights_only=True)
    current=net.state_dict()
    assert current.keys()==original.keys() and all(torch.equal(current[k],v) for k,v in original.items())
    assert [type(x).__name__ for x in net.layers]==['Linear','LeakyReLU']*5
    assert params.network.layer_activations_include_output_layer
    assert all(t.dtype==torch.float32 and t.device.type=='cpu' for t in net.parameters())
    def scaler(suffix):
        with open(str(pth)+suffix,'rb') as f:s=pickle.load(f)
        if not hasattr(s,'use_ddp'):s.use_ddp=False
        return s
    ins,outs=scaler('.iscaler.pkl'),scaler('.oscaler.pkl')
    data=DataHandler(params,input_data_scaler=ins,output_data_scaler=outs,clear_data=True)
    return params,net,data

def predict(case,params,net,data,reference,comm):
    import numpy as np,torch
    from ase import Atoms
    from mala.network.predictor import Predictor
    from mala.targets.dos import DOS
    import ood
    from mpi4py import MPI
    out=CODE/'cases'/case['name']
    if comm.rank==0:
        used=sum(p.stat().st_size for p in CODE.rglob('*') if p.is_file())
        assert used<CONFIG['output_budget_GiB']*1024**3
        if out.exists():
            # Preserve an incomplete attempt; completed cases are verified and skipped in main().
            failed=CODE/'failed_cases';failed.mkdir(exist_ok=True)
            out.rename(failed/(case['name']+'.'+str(int(time.time()))))
        out.mkdir(parents=True,exist_ok=False)
        save(out/'configuration.json',case)
    comm.Barrier();start=time.perf_counter();timers={}
    target=data.target_calculator
    target.invalidate_target()
    target.read_additional_calculation_data(str(ROOT/CONFIG['metadata']),'json')
    a=case['atoms'];atoms=Atoms(numbers=a['numbers'],positions=a['positions'],cell=a['cell'],pbc=a['pbc'])
    assert len(atoms)==CONFIG['original_atoms']-case['n_vac'] and case['electrons']==3*len(atoms)
    target.electrons_per_atom=3
    target.read_additional_calculation_data([atoms,CONFIG['mesh']],'atoms+grid')
    target.number_of_electrons_exact=case['electrons'];target.temperature=CONFIG['temperature_K']
    assert target.number_of_electrons_exact==3*len(atoms)
    params.running.inference_data_grid=CONFIG['mesh'];params.running.mini_batch_size=1000
    data.grid_dimension=CONFIG['mesh'];data.grid_size=CONFIG['grid_points']
    predictor=Predictor(params,net,data)
    if comm.rank==0:status(status='RUNNING',case=case['name'],stage='fresh_SNAP')
    t=time.perf_counter()
    raw,local_size=data.descriptor_calculator.calculate_from_atoms(atoms,CONFIG['mesh'],working_directory=str(out),keep_logs=True,use_fp64=True)
    counts=comm.allgather(len(raw));assert sum(counts)==CONFIG['grid_points']
    assert raw.shape==(len(raw),97) and raw.dtype==np.float64 and np.isfinite(raw).all()
    ix=raw[:,:3].astype(np.int64)
    assert np.array_equal(raw[:,:3],ix)
    assert np.max(np.abs(raw[:,3:6]-(ix/np.array(CONFIG['mesh']))@atoms.cell.array))<1e-10
    assert np.all(ix>=0) and np.all(ix<np.array(CONFIG['mesh']))
    flat=np.ravel_multi_index(ix.T,CONFIG['mesh'])
    assert len(np.unique(flat))==len(flat)
    target.local_grid=ix;target.y_planes=0
    timers['SNAP_seconds']=time.perf_counter()-t
    x=torch.from_numpy(raw[:,6:]).float().contiguous();del raw;gc.collect()
    raw_hash=hashlib.sha256(memoryview(x.numpy())).hexdigest()
    from spatial import periodic_radii
    radius=np.full(len(ix),np.inf)
    for vacancy in case['vacancy_positions_A']:
        vf=np.linalg.solve(atoms.cell.array.T,np.array(vacancy))
        radius=np.minimum(radius,periodic_radii(ix/np.array(CONFIG['mesh'])-vf,atoms.cell.array))
    # A fixed sample verifies finite-range descriptor locality against the existing pristine grid.
    locality=None
    if case['kind']=='native':
        candidates=np.flatnonzero(radius>CONFIG['descriptor_cutoff_A']+.01)[::97][:4096]
        old=np.load(Path(CONFIG['pristine_descriptors']),mmap_mode='r').reshape(-1,94)
        before=np.asarray(old[flat[candidates],3:]);now=x.numpy()[candidates]
        locality=dict(points=len(candidates),max_absolute=float(np.max(np.abs(now-before))) if len(candidates) else None,
            relative_L2=float(np.linalg.norm(now.astype(np.float64)-before)/np.linalg.norm(before)) if len(candidates) else None,
            scope='Only points beyond the union of all vacancy descriptor halos; empty support is recorded explicitly')
        del old,before,now
    t=time.perf_counter();data.input_data_scaler.transform(x)
    assert torch.isfinite(x).all().item()
    q,outside,components,zcounts=ood.assess(x.numpy(),reference)
    scaled_hash=hashlib.sha256(memoryview(x.numpy())).hexdigest()
    timers['descriptor_scaling_OOD_seconds']=time.perf_counter()-t
    groups=[np.flatnonzero(radius<1.5),np.flatnonzero((radius>=1.5)&(radius<4.67637)),np.flatnonzero(radius>6)]
    selected=np.unique(np.concatenate([np.flatnonzero(flat%7813==0)]+[g[::max(1,len(g)//128)][:128] for g in groups]))
    negatives={}
    restrict=target.restrict_data
    def observed_restriction(array):
        count=np.zeros(CONFIG['energy_points'],dtype=np.int64);total=np.zeros(CONFIG['energy_points']);minimum=float(array.min())
        for i in range(0,len(array),10000):
            block=array[i:i+10000];negative=block<0;count+=negative.sum(0)
            total+=np.where(negative,-block,0).sum(0)
        negatives.update(count=count,absolute_sum=total,minimum=minimum,raw_sample=array[selected].copy())
        return restrict(array)
    target.restrict_data=observed_restriction
    if comm.rank==0:status(status='RUNNING',case=case['name'],stage='fresh_LDOS')
    t=time.perf_counter()
    with torch.inference_mode():ldos=predictor._forward_snap_descriptors(x,len(x))
    target.restrict_data=restrict
    assert ldos.dtype==np.float64 and ldos.shape==(len(ix),CONFIG['energy_points']) and np.isfinite(ldos).all() and np.min(ldos)>=0
    ldos_hash=hashlib.sha256(memoryview(ldos)).hexdigest()
    del x;gc.collect();timers['network_seconds']=time.perf_counter()-t
    t=time.perf_counter()
    dos=target.get_density_of_states(ldos,gather_dos=True)
    dcalc=DOS.from_ldos_calculator(target)
    mu=float(dcalc.get_self_consistent_fermi_energy(dos_data=dos,temperature=CONFIG['temperature_K']))
    baseline=json.loads((ROOT/CONFIG['baseline']/'boron_metadata.json').read_text())
    mu0=baseline['fermi_energy_eV_self_consistent']
    rho=np.asarray(target.get_density(ldos,fermi_energy=mu,temperature=CONFIG['temperature_K'],integration_method='analytical')).reshape(-1)
    fixed=np.asarray(target.get_density(ldos,fermi_energy=mu0,temperature=CONFIG['temperature_K'],integration_method='analytical')).reshape(-1)
    dv=atoms.get_volume()/CONFIG['grid_points']
    charge=comm.allreduce(float(rho.sum()*dv));fixed_charge=comm.allreduce(float(fixed.sum()*dv))
    assert abs(charge-case['electrons'])<1e-6 and np.isfinite(rho).all() and np.isfinite(fixed).all()
    if comm.rank==0:
        dos_charge=float(dcalc.get_number_of_electrons(dos_data=dos,fermi_energy=mu,temperature=CONFIG['temperature_K']))
        assert abs(dos_charge-charge)<1e-6
        np.save(out/'dos.npy',dos);np.save(out/'energy_grid_eV.npy',dcalc.energy_grid)
    else:dos_charge=None
    dos_charge=comm.bcast(dos_charge,root=0)
    timers['DOS_Fermi_density_seconds']=time.perf_counter()-t
    if comm.rank==0:status(status='RUNNING',case=case['name'],stage='save_and_analyze')
    radial_edges=np.array([0.,1.5,3.,4.67637,6.,8.1,14.1])
    radial_ldos=np.zeros((len(radial_edges)-1,CONFIG['energy_points']));radial_counts=np.zeros(len(radial_edges)-1,dtype=np.int64)
    if case['n_vac']:
        for i in range(len(radial_edges)-1):
            mask=(radius>=radial_edges[i])&(radius<radial_edges[i+1]);radial_counts[i]=mask.sum()
            radial_ldos[i]=ldos[mask].sum(0,dtype=np.float64)*dv
    samples=(flat[selected],ldos[selected].copy(),negatives.pop('raw_sample'))
    del ldos;gc.collect()
    fields=comm.gather((flat,rho,fixed,q.astype(np.float32),outside),root=0)
    sample_parts=comm.gather(samples,root=0)
    localities=comm.gather(locality,root=0)
    hashes=comm.gather(dict(rank=comm.rank,raw_float32_descriptors=raw_hash,scaled_descriptors=scaled_hash,LDOS_float64=ldos_hash),root=0)
    neg_count=comm.reduce(negatives['count']);neg_sum=comm.reduce(negatives['absolute_sum']);neg_min=comm.allreduce(negatives['minimum'],op=MPI.MIN)
    comp=comm.reduce(components);zc=comm.reduce(zcounts);rl=comm.reduce(radial_ldos);rc=comm.reduce(radial_counts)
    if comm.rank==0:
        coverage=np.bincount(np.concatenate([part[0] for part in fields]),minlength=CONFIG['grid_points']);assert np.all(coverage==1)
        assembled=[np.empty(CONFIG['grid_points'],dtype=d) for d in [np.float64,np.float64,np.float32,np.uint8]]
        for part in fields:
            for dest,source in zip(assembled,part[1:]):dest[part[0]]=source
        for name,arr in zip(['density','density_fixed_pristine_mu','ood_score','ood_outside'],assembled):np.save(out/(name+'.npy'),arr.reshape(CONFIG['mesh']))
        inds=np.concatenate([p[0] for p in sample_parts]);order=np.argsort(inds)
        np.savez(out/'ldos_samples.npz',flat_indices=inds[order],restricted=np.concatenate([p[1] for p in sample_parts])[order],raw=np.concatenate([p[2] for p in sample_parts])[order])
        np.savez(out/'radial_ldos.npz',edges_A=radial_edges,integrated_LDOS=rl,point_counts=rc)
        density=assembled[0];qq=assembled[2];oo=assembled[3]
        metadata=dict(case=case['name'],status='COMPLETE',atoms=len(atoms),n_vac=case['n_vac'],target_electrons=case['electrons'],
            integrated_electrons=charge,DOS_integrated_electrons=dos_charge,charge_error=charge-case['electrons'],
            charge_check_scope='Consistency enforced by the Fermi solver, not an accuracy metric',
            fermi_eV=mu,pristine_fermi_eV=mu0,fixed_pristine_mu_electrons=fixed_charge,temperature_K=CONFIG['temperature_K'],
            density_min=float(density.min()),density_max=float(density.max()),negative_density_points=int(np.count_nonzero(density<0)),
            positivity_scope='Restricted LDOS is clipped by the frozen model convention; raw negative outputs recorded separately',
            raw_negative_LDOS_fraction=float(neg_count.sum()/(CONFIG['grid_points']*CONFIG['energy_points'])),raw_negative_LDOS_minimum=neg_min,
            raw_negative_LDOS_counts_by_energy=neg_count.tolist(),raw_negative_LDOS_absolute_sum_by_energy=neg_sum.tolist(),
            OOD_score_mean=float(qq.mean(dtype=np.float64)),OOD_score_max=float(qq.max()),
            fraction_OOD_q999=float(np.mean(qq>reference['quantiles'][-1])),fraction_any_feature_outside_training_range=float(oo.mean()),
            component_outside_counts=comp.tolist(),checkpoint_z_component_counts=zc.tolist(),
            descriptor_locality_samples=localities,rank_array_hashes=hashes,timings=timers,
            wall_seconds=time.perf_counter()-start,LDOS_retention='Full float64 LDOS generated transiently; complete per-rank hashes and spatial samples retained',
            scientific_scope='Frozen MALA vacancy prediction and diagnostics; DFT validation is a separate stage')
        metadata['configuration_sha256']=sha(out/'configuration.json')
        metadata['checkpoint_sha256']=sha(str(ROOT/CONFIG['model'])+'.network.pth')
        metadata['outputs']={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in out.iterdir() if p.suffix in ['.npy','.npz']}
        save(out/'result.json',metadata)
    comm.Barrier()
    del fields,sample_parts,rho,fixed,q,outside,ix,flat;gc.collect()

def main():
    guard()
    import torch,numpy as np
    from mpi4py import MPI
    comm=MPI.COMM_WORLD;assert comm.size==8
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['pilot','remaining','all'],required=True);args=ap.parse_args()
    if comm.rank==0:check_sources()
    comm.Barrier();params,net,data=load_model()
    # Finish dynamic-library/MPI initialization before verifying the binding handshake.
    cpus=json.loads(os.environ['VACANCY_CPUS']);cpu=cpus[comm.rank]
    for task in Path('/proc/self/task').iterdir():
        try:os.sched_setaffinity(int(task.name),{cpu})
        except ProcessLookupError:pass
    ready=Path(os.environ['VACANCY_RUNTIME'])
    save(ready/f'ready-{comm.rank}.json',dict(rank=comm.rank,pid=os.getpid(),cpu=cpu,
        start_ticks=int(Path('/proc/self/stat').read_text().split()[21]),affinity=sorted(os.sched_getaffinity(0))))
    while not (ready/'go.json').exists():time.sleep(.1)
    comm.Barrier()
    import ood,copy
    reference=ood.load()
    selected=copy.deepcopy(CONFIGS['cases'])
    if comm.rank==0:save(CODE/'prediction_configurations.json',selected)
    comm.Barrier()
    for case in selected:
        completed=False
        if comm.rank==0:
            out=CODE/'cases'/case['name']
            if (out/'result.json').exists():
                result=json.loads((out/'result.json').read_text())
                assert result['status']=='COMPLETE' and json.loads((out/'configuration.json').read_text())==case
                assert result['checkpoint_sha256']==sha(str(ROOT/CONFIG['model'])+'.network.pth')
                for name,identity in result['outputs'].items():assert sha(out/name)==identity['sha256']
                completed=True
        completed=comm.bcast(completed,root=0)
        if not completed:predict(case,params,net,data,reference,comm)
    if comm.rank==0:
        check_sources()
        status(status='COMPLETE',phase=args.phase,cases_completed=[c['name'] for c in selected])
    comm.Barrier()

if __name__=='__main__':
    try:main()
    except BaseException:
        import traceback;traceback.print_exc()
        try:
            from mpi4py import MPI
            MPI.COMM_WORLD.Abort(1)
        except Exception:raise
