#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=/data/home2/elabid32/workspace/mala_aluminium
export PATH="/data/rosi/shared/pkg/compiler/gcc/14.2.0/bin:/data/rosi/shared/pkg/mpi/openmpi/4.1.8/gcc/14.2.0/bin:/data/rosi/shared/pkg/devel/python/3.12.4/bin:/usr/bin:/bin"
export LD_LIBRARY_PATH="/data/rosi/shared/pkg/devel/python/3.12.4/lib:/data/rosi/shared/pkg/compiler/gcc/14.2.0/lib64:/data/rosi/shared/pkg/mpi/openmpi/4.1.8/gcc/14.2.0/lib:$ROOT/lammps-mala/install/lib:/data/rosi/shared/pkg/compiler/gcc/14.2.0/lib"
export PYTHONPATH="$ROOT/lammps-mala/install/lib/python3.12/site-packages"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1 FLEXIBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export CUDA_VISIBLE_DEVICES=""
PRED="$ROOT/qe_native_20261103/b_divacancy_three_placements_20261115"
/data/home2/elabid32/workspace/mala/mala_env/bin/python "$PRED/prepare.py"
exec /data/home2/elabid32/workspace/mala/mala_env/bin/python -u "$PRED/mala_controller.py" --phase all
