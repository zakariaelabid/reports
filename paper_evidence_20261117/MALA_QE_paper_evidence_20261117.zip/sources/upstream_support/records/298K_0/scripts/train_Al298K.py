import mala
from mala import printout

run = "Al_298K_XX"
# Load the parameters from the hyperparameter optimization
parameters = mala.Parameters()

# Specify the data scaling.
parameters.data.input_rescaling_type = "feature-wise-standard"
parameters.data.output_rescaling_type = "normal"

# LDOS parameters.
parameters.targets.ldos_gridsize = 250
parameters.targets.ldos_gridspacing_ev = 0.1
parameters.targets.ldos_gridoffset_ev = -10
parameters.network.layer_activations = ["LeakyReLU"]
parameters.descriptors.descriptor_type = "Bispectrum"
parameters.descriptors.use_atomic_density_energy_formula = True
parameters.descriptors.bispectrum_twojmax = 10
parameters.descriptors.bispectrum_cutoff = 4.67637
parameters.descriptors.bispectrum_switchflag = 0


# Specify the training parameters, these are not completely the same as
# for the hyperparameter optimization.
parameters.running.early_stopping_epochs = 8
parameters.running.early_stopping_threshold = 0
parameters.running.learning_rate = 0.00001
parameters.running.trainingtype = "Adam"
parameters.running.learning_rate_scheduler = "ReduceLROnPlateau"
parameters.running.learning_rate_decay = 0.1
parameters.running.learning_rate_patience = 4
parameters.running.verbosity = True
parameters.running.max_number_epochs = 10000
parameters.running.mini_batch_size = 1000
parameters.use_gpu = True
parameters.running.use_graphs = True

# Add data to the run.
data_handler = mala.DataHandler(parameters)

# Add data as per your specification.
snap_path = ...
ldos_path = ...
out_path = ...
data_handler.add_snapshot("Al_snapshot0.in.npy", snap_path,
                          "Al_snapshot0.out.npy", ldos_path,
                          add_snapshot_as="tr",
                          calculation_output_file=out_path +"Al_snapshot0.out",
                          output_units="1/(Ry*Bohr^3)")

data_handler.add_snapshot("Al_snapshot1.in.npy", snap_path,
                          "Al_snapshot1.out.npy", ldos_path,
                          add_snapshot_as="va",
                          calculation_output_file=out_path +"Al_snapshot1.out",
                          output_units="1/(Ry*Bohr^3)")

data_handler.prepare_data()

# Build and train network.
parameters.network.layer_sizes = [data_handler.input_dimension, 800,
                                  800, 800, 250,
                                  data_handler.output_dimension]
network = mala.Network(parameters)
trainer = mala.Trainer(parameters, network, data_handler)
trainer.train_network()
trainer.save_run(run,
                 additional_calculation_data=out_path +"Al_snapshot0.out")
