"""Fresh positions -> SNAP -> official forward routine -> LDOS -> Fermi -> cube.

No cached scientific input argument exists. Compatibility adapters affect only
legacy scaler attributes and singleton activation-list parsing, never assets.
"""
import argparse, gc, hashlib, importlib.metadata, json, math, os, pickle, sys, time
from pathlib import Path
from common import *

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--bundle',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--mesh',type=int,required=True);ap.add_argument('--retain',action='store_true');a=ap.parse_args()
    c=configuration(a.bundle/'code/config.json');out=a.out.resolve();n=a.mesh
    require(n>0 and n%8==0,'Mesh incompatible with eight z partitions')
    require(out.is_dir() and not (out/'mala.json').exists() and not any(out.glob('*.npy')) and not (out/'mala.cube').exists(),'Stale prediction directory')
    t0=time.perf_counter();timers={}
    import numpy as np
    import torch, mala
    from ase import Atoms
    from ase.io import read
    from ase.units import Bohr
    from mpi4py import MPI
    comm=MPI.COMM_WORLD;rank=comm.rank
    require(comm.size==8,'Missing descriptor ranks')
    torch.set_num_threads(8 if rank==0 else 1)
    # Prevent root-only ASE reads from entering MPI collectives.
    info=read_json(Path(c['root'])/c['metadata']);ai=info['atoms']
    atoms=Atoms(numbers=ai['numbers'],positions=ai['positions'],cell=ai['cell'],pbc=ai['pbc'])
    qe=read(str(Path(c['root'])/c['qe_output']),format='espresso-out',parallel=False)
    require(np.array_equal(atoms.numbers,qe.numbers) and np.array_equal(atoms.positions,qe.positions) and np.array_equal(atoms.cell.array,qe.cell.array) and np.array_equal(atoms.pbc,qe.pbc),'QE geometry differs from explicit snapshot1')
    pth=Path(c['root'])/c['model']
    model_assets=read_json(a.bundle/'assets.json')['archive_members']
    for member,h in model_assets.items():require(digest(pth.parent/member)==h,'Model asset changed')
    params=mala.Parameters.load_from_json(str(pth)+'.params.json',force_no_ddp=True)
    require(params.network.layer_activations==['LeakyReLU'],'Unrecognized activation adapter input')
    params.network.layer_activations='LeakyReLU'
    params.use_gpu=False;params.use_mpi=True;params.use_lammps=True
    params.running.use_mixed_precision=False
    net=mala.Network.load_from_file(params,str(pth)+'.network.pth');net.eval()
    checkpoint=torch.load(str(pth)+'.network.pth',map_location='cpu',weights_only=True)
    state=net.state_dict()
    require(state.keys()==checkpoint.keys() and all(state[k].shape==v.shape and torch.equal(state[k],v) for k,v in checkpoint.items()),'Loaded checkpoint tensor/key/shape mismatch')
    sequence=[type(x).__name__ for x in net.layers]
    require(sequence==['Linear','LeakyReLU']*5 and params.network.layer_activations_include_output_layer,'Wrong output activation')
    def scaler(s):
        with open(str(pth)+s,'rb') as f:x=pickle.load(f)
        if not hasattr(x,'use_ddp'):x.use_ddp=False
        return x
    from mala.datahandling.data_handler import DataHandler
    from mala.network.predictor import Predictor
    data=DataHandler(params,input_data_scaler=scaler('.iscaler.pkl'),output_data_scaler=scaler('.oscaler.pkl'),clear_data=True)
    target=data.target_calculator
    target.read_additional_calculation_data(str(Path(c['root'])/c['metadata']),'json')
    target.read_additional_calculation_data([atoms,[n]*3],'atoms+grid')
    data.grid_dimension=[n]*3;data.grid_size=n**3
    params.running.inference_data_grid=[n]*3
    params.running.mini_batch_size=1000
    require(all(t.device.type=='cpu' and t.dtype==torch.float32 for t in net.parameters()),'Model precision/device mismatch')
    require(target.temperature==info['temperature'] and target.number_of_electrons_exact==768,'Target metadata changed')
    predictor=Predictor(params,net,data)
    timers['import_model_geometry_seconds']=time.perf_counter()-t0
    start=time.perf_counter()
    raw,local_size=data.descriptor_calculator.calculate_from_atoms(atoms,[n]*3,working_directory=str(out),keep_logs=True,use_fp64=True)
    counts=comm.allgather(int(raw.shape[0]))
    require(sum(counts)==n**3 and all(x>0 for x in counts),'MPI lost/duplicated descriptor point count')
    # Check the complete distributed logical grid, including every coordinate.
    ix=raw[:,:3].astype(np.int64)
    require(np.array_equal(raw[:,:3],ix) and ((ix>=0)&(ix<n)).all(),'Malformed local grid indices')
    require(np.max(np.abs(raw[:,3:6]-ix@atoms.cell.array/n))<1e-10,'Wrong physical coordinates in local descriptor grid')
    flat=ix[:,0]*n*n+ix[:,1]*n+ix[:,2]
    require(np.unique(flat).size==flat.size,'Duplicate local points')
    bounds=comm.allgather((ix.min(axis=0).tolist(),ix.max(axis=0).tolist()))
    # Eight disjoint complete z slabs are required before MALA's gather.
    for k,(lo,hi) in enumerate(bounds):
        require(lo==[0,0,k*(n//8)] and hi==[n-1,n-1,(k+1)*(n//8)-1],f'Unexpected MPI slab {k}: {lo},{hi}')
    timers['SNAP_seconds']=time.perf_counter()-start
    start=time.perf_counter();full=data.descriptor_calculator.gather_descriptors(raw)
    del raw,ix,flat;gc.collect()
    if rank!=0:
        comm.Barrier();return
    params.use_mpi=False
    timers['gather_seconds']=time.perf_counter()-start
    require(full.shape==(n,n,n,94) and full.dtype==np.float64,'Wrong gathered descriptor shape/precision')
    descriptor_reference=None;descriptor_delta2=0.;descriptor_norm2=0.;descriptor_max=0.;descriptor_point_max=0.;descriptor_mismatches=0
    if a.retain and n==200:
        source=Path(c['dataset'])/'snap/Al_snapshot1.in.npy'
        sid=next(x for x in read_json(a.bundle/'assets.json')['sources'] if x['path']==str(source))
        unchanged(sid,True)
        descriptor_reference=np.load(source,mmap_mode='r')
        require(descriptor_reference.shape==(200,200,200,94) and descriptor_reference.dtype==np.float32,'Stored descriptor identity/shape wrong')
    for i in range(n):
        require(np.isfinite(full[i]).all(),'Nonfinite descriptor')
        yy,zz=np.indices((n,n));expect=np.stack([np.full((n,n),i),yy,zz],axis=-1)@atoms.cell.array/n
        require(np.max(np.abs(full[i,:,:,:3]-expect))<1e-10,'Complete assembled XYZ mismatch')
        if descriptor_reference is not None:
            fresh=full[i,:,:,3:].astype(np.float32);stored=np.asarray(descriptor_reference[i,:,:,3:])
            delta=fresh.astype(np.float64)-stored
            descriptor_delta2+=float(np.sum(delta**2));descriptor_norm2+=float(np.sum(stored.astype(np.float64)**2))
            descriptor_max=max(descriptor_max,float(abs(delta).max()));descriptor_mismatches+=int(np.count_nonzero(fresh!=stored))
            per_point=np.linalg.norm(delta,axis=-1)/np.maximum(np.linalg.norm(stored.astype(np.float64),axis=-1),1e-30)
            descriptor_point_max=max(descriptor_point_max,float(per_point.max()))
    if descriptor_reference is not None:
        unchanged(sid)
        require(descriptor_point_max<1e-6,'Fresh SNAP differs from stored snapshot1 at a physical point')
        save(out/'stored_descriptor_check.json',dict(points=n**3,components=91,relative_L2=(descriptor_delta2/descriptor_norm2)**.5,max_point_relative_L2=descriptor_point_max,max_abs=descriptor_max,float32_bitwise_mismatches=descriptor_mismatches,source=sid))
        del descriptor_reference
    start=time.perf_counter()
    x=torch.from_numpy(full[:,:,:,3:].reshape(-1,91)).float();del full;gc.collect()
    raw_sample=x[::max(1,n**3//2048)].clone()
    data.input_data_scaler.transform(x)
    require(torch.isfinite(x).all().item(),'Nonfinite scaled descriptor')
    array_hashes={}
    if a.retain:
        from per_mesh import array_identity
        array_hashes['scaled_descriptors']=array_identity(x.numpy())
        g=40 if n==200 else math.gcd(200,n)
        require(n%g==0 and 40%g==0,'Unsupported shared-coordinate storage mesh')
        step=n//g
        common_scaled=x.numpy().reshape(n,n,n,91)[::step,::step,::step].copy()
        np.save(out/'shared_scaled.npy',common_scaled)
        arr=x.numpy();sums=np.zeros(91);squares=np.zeros(91);minimum=np.full(91,np.inf);maximum=np.full(91,-np.inf)
        for k in range(0,len(arr),100000):
            block=arr[k:k+100000].astype(np.float64)
            sums+=block.sum(0);squares+=np.einsum('ij,ij->j',block,block);minimum=np.minimum(minimum,block.min(0));maximum=np.maximum(maximum,block.max(0))
        mean=sums/len(arr);std=np.sqrt(np.maximum(squares/len(arr)-mean**2,0))
        save(out/'descriptor_distribution.json',dict(points=len(arr),mean=mean.tolist(),std=std.tolist(),minimum=minimum.tolist(),maximum=maximum.tolist(),sample_quantiles=np.quantile(arr[::max(1,len(arr)//2048)],[.01,.5,.99],axis=0).tolist(),quantile_policy='Deterministic ~2048-point supporting sample; mean/std/min/max use complete grid'))
        del arr,block
    timers['descriptor_check_scale_save_seconds']=time.perf_counter()-start
    start=time.perf_counter()
    with torch.inference_mode():
        predicted=predictor._forward_snap_descriptors(x)
        # An independent sample-level manual scaler route is checked as well.
        scaled=(raw_sample-data.input_data_scaler.means)/data.input_data_scaler.stds
        direct=net(scaled)
        manual=direct*(data.output_data_scaler.total_max-data.output_data_scaler.total_min)+data.output_data_scaler.total_min
        inverse=data.output_data_scaler.inverse_transform(direct.clone(),as_numpy=True)
        require(np.array_equal(manual.numpy(),inverse),'Output scaler route mismatch')
    require(predicted.dtype==np.float64 and predicted.shape==(n**3,250),'Official forward dtype/shape changed')
    timers['network_seconds']=time.perf_counter()-start
    # Raw shared-point predictions retained separately before restriction for the legacy route check.
    np.save(out/'legacy_descriptors.npy',raw_sample.numpy())
    with torch.inference_mode():unrestricted=data.output_data_scaler.inverse_transform(net(scaled),as_numpy=True)
    np.save(out/'legacy_raw_ldos.npy',unrestricted)
    if a.retain:
        pieces=[];shared_flat=common_scaled.reshape(-1,91)
        with torch.inference_mode():
            for begin in range(0,len(shared_flat),1000):
                pieces.append(data.output_data_scaler.inverse_transform(net(torch.from_numpy(shared_flat[begin:begin+1000])),as_numpy=True))
        np.save(out/'shared_raw_ldos.npy',np.concatenate(pieces).reshape(g,g,g,250))
        del pieces,shared_flat,common_scaled
    del x,raw_sample,scaled;gc.collect()
    start=time.perf_counter()
    ldos=predicted.reshape(n,n,n,250)
    require(np.isfinite(ldos).all() and (ldos>=0).all(),'Invalid restricted LDOS')
    if a.retain:np.save(out/'shared_restricted_ldos.npy',ldos[::step,::step,::step])
    timers['LDOS_check_save_seconds']=time.perf_counter()-start
    start=time.perf_counter();target.read_from_array(ldos)
    dos=target.get_density_of_states(ldos)
    np.save(out/'dos.npy',dos)
    timers['DOS_seconds']=time.perf_counter()-start
    start=time.perf_counter();mu=float(target.fermi_energy)
    timers['fermi_seconds']=time.perf_counter()-start
    start=time.perf_counter()
    rho=target.get_density(ldos,fermi_energy=mu,temperature=info['temperature'],conserve_dimensions=True,integration_method='analytical')
    timers['density_seconds']=time.perf_counter()-start
    start=time.perf_counter()
    np.save(out/'legacy_restricted_ldos.npy',ldos.reshape(-1,250)[::max(1,n**3//2048)])
    np.save(out/'legacy_density.npy',rho.reshape(-1,1)[::max(1,n**3//2048)])
    ne=float(target.get_number_of_electrons(ldos,fermi_energy=mu,temperature=info['temperature']))
    require(np.isfinite(rho).all() and rho.shape==(n,n,n,1) and abs(ne-768)<7.68e-5,'Invalid density or Fermi charge')
    np.save(out/'density.npy',rho[:,:,:,0])
    # Explicit fixed-reference-mu result separates quadrature from location queries.
    if a.retain:
        fixed=target.get_density(ldos,fermi_energy=info['fermi_energy_dft'],temperature=info['temperature'],conserve_dimensions=True,integration_method='analytical')
        np.save(out/'shared_fixed_mu_density.npy',fixed[::step,::step,::step,0])
        del fixed
    timers['density_checks_save_seconds']=time.perf_counter()-start
    start=time.perf_counter()
    from numerical import write_cube, read_cube
    values=rho[:,:,:,0]*Bohr**3
    write_cube(out/'mala.cube',values,atoms.positions/Bohr,atoms.cell.array/Bohr,13,3)
    timers['cube_write_seconds']=time.perf_counter()-start
    start=time.perf_counter();written,meta=read_cube(out/'mala.cube')
    require(np.allclose(written,values,rtol=1e-14,atol=0),'Cube samples changed')
    require(abs(written.sum()*abs(np.linalg.det(atoms.cell.array/Bohr))/n**3-768)<7.68e-5,'Serialized charge invalid')
    timers['cube_verification_seconds']=time.perf_counter()-start
    if a.retain:
        start=time.perf_counter()
        from per_mesh import assess
        assessed=assess(c,a.bundle,out,params,target,ldos,rho[:,:,:,0],mu,dos)
        array_hashes['LDOS']=assessed['complete_fresh_LDOS']
        timers['reference_accuracy_seconds']=time.perf_counter()-start
    start=time.perf_counter()
    libs=sorted({l.split()[-1] for l in Path('/proc/self/maps').read_text().splitlines() if len(l.split())>=6 and l.split()[-1].startswith('/') and '.so' in l.split()[-1]})
    versions={p:importlib.metadata.version(p) for p in ['torch','numpy','scipy','ase','mpi4py','materials-learning-algorithms']}
    library_identities={p:identity(p) for p in libs}
    timers['runtime_identity_audit_seconds']=time.perf_counter()-start
    result=dict(mesh=[n]*3,geometry_source=c['qe_output'],snapshot=1,temperature_K=info['temperature'],fermi_eV=mu,electrons=ne,cell_A=atoms.cell.array.tolist(),bohr_A=Bohr,network=str(net),activation_sequence=sequence,loaded_tensor_shapes={k:list(v.shape) for k,v in state.items()},precision=dict(network='float32',assembled_ldos='float64'),complete_fresh_array_hashes=array_hashes,versions=versions,mpi=MPI.Get_library_version(),loaded_libraries=library_identities,timings=timers,cube=identity(out/'mala.cube'),caches_used=False,local_counts=counts,total_worker_seconds=time.perf_counter()-t0)
    save(out/'mala.json',result)
    comm.Barrier()

if __name__=='__main__':
    try:main()
    except BaseException:
        import traceback;traceback.print_exc()
        try:
            from mpi4py import MPI
            MPI.COMM_WORLD.Abort(1)
        except ImportError:pass
        raise
