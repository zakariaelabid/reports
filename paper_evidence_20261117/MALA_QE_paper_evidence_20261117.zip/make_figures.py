"""Draw figures exclusively from saved trajectories, metrics and Fourier arrays."""
import csv,json,os
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Circle
from matplotlib.backends.backend_pdf import PdfPages

assert os.environ.get('SLURM_JOB_ID'), 'Scientific plotting belongs on a compute node'
OUT=Path(__file__).resolve().parent
def rows(f):return list(csv.DictReader((OUT/'data'/f).open()))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,
    'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
BLUE='#1466A0';ORANGE='#CC641C';GREEN='#24846F';INK='#15283E';GRAY='#637386';PURPLE='#735CA5'
def save(fig,name):
    for ext in ['png','pdf','svg']:fig.savefig(OUT/'figures'/f'{name}.{ext}',dpi=220,bbox_inches='tight')
    plt.close(fig)

# A vector-only method figure. It represents the actual data flow, not fabricated density data.
fig,ax=plt.subplots(figsize=(18,10.2));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
ax.text(.025,.975,'Frozen MALA densities as Quantum ESPRESSO initializers',ha='left',va='top',
        size=24,weight='bold',color=INK)
ax.text(.025,.921,'One fixed geometry • one Hamiltonian per matched pair • independent SCF histories',
        ha='left',va='top',size=13,color=GRAY)
def box(x,y,w,h,title,body,color=BLUE,fill='#F0F6FA',number=None):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.009,rounding_size=0.012',
                              fc=fill,ec=color,lw=1.4,zorder=2))
    if number:
        ax.add_patch(Circle((x+.019,y+h-.026),.013,fc=color,ec='none',zorder=3))
        ax.text(x+.019,y+h-.026,number,ha='center',va='center',color='white',size=9,weight='bold',zorder=4)
    ax.text(x+w/2,y+h-(.052 if number else .028),title,ha='center',va='center',size=13,weight='bold',color=INK,zorder=4)
    ax.text(x+w/2,y+h*.42-.008,body,ha='center',va='center',size=11,color=INK,linespacing=1.6,zorder=4)
def arrow(a,b,color=BLUE,style='-',rad=0):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=16,lw=2,color=color,
        linestyle=style,connectionstyle=f'arc3,rad={rad}',zorder=1))
xs=[.025,.226,.427,.628,.829];w=.145;y=.655;h=.19
box(xs[0],y,w,h,'Structure','Positions + cell\nSpecies + charge\nPeriodic boundaries',number='1')
box(xs[1],y,w,h,'Local descriptors','SNAP bispectrum\n91 input features\nFixed 4.67637 Å cutoff',number='2')
box(xs[2],y,w,h,'Frozen MALA','Pretrained network\nSaved input/output scalers\nNo retraining',number='3')
box(xs[3],y,w,h,'Predicted LDOS',r'$D(\mathbf{r},\epsilon)$'+'\nFixed energy grid\nNonnegative-target policy',number='4')
box(xs[4],y,w,h,'Density integration',r'$\rho_M=\int f(\epsilon;\mu,T_e)D\,d\epsilon$'+'\nSolve μ for the known '+r'$N_e$'+'\nCheck charge / finite values',number='5')
for a,b in zip(xs[:-1],xs[1:]):arrow((a+w+.008,y+h/2),(b-.011,y+h/2))
box(.725,.385,.25,.155,'MALA native density','Unit / grid / Fourier conversion\nQE native reciprocal density file\nNo converged reference is used',color=BLUE)
arrow((.901,.646),(.851,.55))
box(.025,.385,.25,.155,'ATOMIC starting density','Superposed pseudopotential atomic densities\nAtomic structure and charge prior\nBonding / defects are not guaranteed',color=ORANGE,fill='#FFF5ED')
arrow((.097,.645),(.13,.55),ORANGE)
box(.37,.325,.255,.235,'Independent QE SCF','Build potential → diagonalize → occupy\nUpdate density → mix → repeat\nSame solver, geometry and threshold\nFresh orbitals and mixing history',color=INK,fill='#F5F7F9')
arrow((.283,.462),(.36,.462),ORANGE)
ax.text(.32,.484,'ATOMIC',ha='center',va='bottom',size=10,color=ORANGE)
arrow((.715,.462),(.635,.462),BLUE)
ax.text(.677,.484,'MALA',ha='center',va='bottom',size=10,color=BLUE)
box(.37,.08,.255,.155,'Converged QE density',r'$\rho_\star$'+' and finite-tolerance endpoint\nIterations + convergence trajectory\nCommon density-error reference',color=GREEN,fill='#EFF8F4')
arrow((.4975,.315),(.4975,.245),GREEN)
box(.025,.08,.25,.155,'Density-only reinjection control','Copy the same-case converged native density\nRebuild orbitals and mixing history\nFull SCF; no electronic-state restart',color=GREEN,fill='#EFF8F4')
arrow((.36,.157),(.285,.157),GREEN)
ax.plot([.15,.15,.335,.335],[.245,.285,.285,.36],color=GREEN,lw=2,ls='--',zorder=1)
arrow((.335,.36),(.36,.385),GREEN,style='--')
box(.725,.08,.25,.155,'Matched comparisons','Global + atom-/vacancy-centred errors\nNative Fourier spectra and maps\nMALA / ATOMIC / reinjection iterations',color=PURPLE,fill='#F6F2FA')
arrow((.635,.157),(.715,.157),PURPLE)
ax.text(.025,.014,'Solid arrows: production initialization and analysis. Dashed green: a diagnostic control, not an inference input. '
        'Schematic data flow; no density field is synthesized.',color=GRAY,size=10)
save(fig,'framework_MALA_QE')

R=rows('QE_iterations_and_improvements.csv')
fig,axes=plt.subplots(2,1,figsize=(15,9),layout='constrained',gridspec_kw={'height_ratios':[1.25,1]})
labels=[r['label'].replace(', ', '\n').replace(' pristine','\npristine') for r in R]
x=np.arange(len(R));width=.24
for delta,key,name,color in [(-width,'ATOMIC_steps','ATOMIC',ORANGE),(0,'MALA_steps','MALA',BLUE),
                             (width,'reinjection_steps','Own QE density reinjection',GREEN)]:
    vals=[int(r[key]) for r in R];bars=axes[0].bar(x+delta,vals,width,label=name,color=color)
    axes[0].bar_label(bars,padding=2,fontsize=9)
axes[0].set(ylabel='Genuine SCF iterations',ylim=(0,26),title='Saved QE benchmarks · exact per-case counts')
axes[0].legend(ncol=3,loc='upper left');axes[0].set_xticks(x,labels,fontsize=9);axes[0].grid(axis='y',alpha=.15)
for delta,key,name,color in [(-.18,'ATOMIC_relative_reduction_percent','Reduction relative to ATOMIC',BLUE),
                            (.18,'reinjection_referenced_reduction_percent','Reinjection-referenced reduction',PURPLE)]:
    vals=[float(r[key]) for r in R];bars=axes[1].bar(x+delta,vals,.34,label=name,color=color)
    axes[1].bar_label(bars,labels=[f'{v:.1f}' for v in vals],padding=2,fontsize=9)
axes[1].set(ylabel='Iteration reduction (%)',ylim=(0,46));axes[1].set_xticks(x,labels,fontsize=9)
axes[1].legend(ncol=2,loc='upper right');axes[1].grid(axis='y',alpha=.15)
for a in axes:
    for boundary in [2.5,5.5,8.5]:a.axvline(boundary,color='#D6DCE3',lw=1)
fig.suptitle('Pristine systems and boron vacancies · no wall-time speedup claim',fontsize=16,weight='bold')
save(fig,'QE_iteration_comparison')

trajectories=rows('scf_trajectories.csv')
fig,axes=plt.subplots(2,3,figsize=(15,8),layout='constrained')
for i,system in enumerate(['Al298','Al933','B298']):
    meta=next(r for r in R if r['case']==system);ref=float(meta['ATOMIC_final_energy_Ry'])
    control=json.loads((OUT/'sources'/f'{system}_reinjection_results.json').read_text())
    for b,color in [('ATOMIC',ORANGE),('MALA',BLUE),('REINJECTION',GREEN)]:
        pts=control['trajectory'] if b=='REINJECTION' else [r for r in trajectories if r['case']==system and r['initialization']==b]
        xx=[int(r['iteration']) for r in pts]
        yy=[float(r['estimated_SCF_accuracy_Ry'] if b=='REINJECTION' else r['estimated_error_Ry']) for r in pts]
        axes[0,i].semilogy(xx,yy,'o-',ms=3,color=color,label=f'{b}: {len(pts)}')
        ep=[(int(r['iteration']),abs(float(r['energy_Ry'])-ref)*13.605693122994017*1000/int(meta['atoms'])) for r in pts]
        ep=[p for p in ep if p[1]>0]
        if ep:axes[1,i].semilogy(*zip(*ep),'o-',ms=3,color=color)
    axes[0,i].axhline(float(meta['conv_thr_Ry_per_cell']),ls=':',color=INK)
    axes[0,i].set(title=system+' · '+meta['cutoffs_Ry']+' Ry',ylabel='QE estimated SCF accuracy (Ry/cell)')
    axes[0,i].legend(fontsize=9)
    axes[1,i].set(ylabel='|E − original ATOMIC endpoint| (meV/atom)',xlabel='SCF iteration')
    for a in axes[:,i]:a.grid(alpha=.15)
fig.suptitle('Pristine QE · MALA, ATOMIC and native-density reinjection',weight='bold',fontsize=16)
save(fig,'QE_pristine_three_way_trajectories')

parent=json.loads((OUT/'sources/B298/case.json').read_text())
cell=np.asarray(parent['cell_A']);positions=np.asarray(parent['positions_A'])
frac=(positions@np.linalg.inv(cell))%1
fig,axes=plt.subplots(3,3,figsize=(11,10.5),layout='constrained')
for ax,r in zip(axes.ravel(),[r for r in R if int(r['vacancies'])>0]):
    ids=json.loads(r['removed_indices_zero_based']);kept=np.ones(len(frac),dtype=bool);kept[ids]=False
    sc=ax.scatter(frac[kept,0],frac[kept,1],s=15,c=frac[kept,2],cmap='Blues',vmin=0,vmax=1,alpha=.65,edgecolors='none')
    ax.scatter(frac[ids,0],frac[ids,1],s=115,c=ORANGE,marker='x',lw=2)
    for j in ids:ax.annotate(str(j),(frac[j,0],frac[j,1]),xytext=(5,4),textcoords='offset points',fontsize=8,color=ORANGE)
    ax.set(xlim=(0,1),ylim=(0,1),aspect='equal',xlabel='Fractional a coordinate',ylabel='Fractional b coordinate',
           title=r['label'].replace('B298, ',''));ax.grid(alpha=.12)
fig.colorbar(sc,ax=axes.ravel().tolist(),label='Fractional c coordinate of retained atoms',shrink=.8)
fig.suptitle('Boron vacancy placements · periodic fractional-coordinate view',weight='bold',fontsize=15)
fig.text(.02,-.018,'Orange crosses: removed parent atoms, labelled by zero-based index. '
         'Faces are periodic, not physical surfaces. Projection can overlap atoms at different c.',fontsize=9,color=GRAY)
save(fig,'Boron_vacancy_placements')

C=rows('CP2K_iterations_and_improvements.csv');selected=[r for r in C if r['case'] in ['Al298_GTH800','Al933_GTH800','B298_GTH800','Al298_UPF800']]
fig,ax=plt.subplots(figsize=(12,5.6),layout='constrained');x=np.arange(len(selected))
for delta,key,name,col in [(-.27,'ATOMIC_steps','ATOMIC',ORANGE),(-.09,'MALA_steps','MALA',BLUE),
                          (.09,'own_CP2K_reinjection_steps','Own CP2K density',GREEN),(.27,'QE_reference_steps','QE-reference density',PURPLE)]:
    vals=[float(r[key]) if r[key] not in ['', 'None'] else np.nan for r in selected]
    bars=ax.bar(x+delta,vals,.17,color=col,label=name);ax.bar_label(bars,labels=[str(int(v)) if np.isfinite(v) else '' for v in vals],padding=2)
ax.set_xticks(x,['Al298\nGTH / PBE','Al933\nGTH / PBE','B298\nGTH / PBE','Al298\nUPF / PBEsol'])
ax.text(2,3,'MALA / own-density control\nunavailable at 800 Ry',ha='center',fontsize=9,color=GRAY,
        bbox=dict(facecolor='white',edgecolor='none',alpha=.94,pad=3))
ax.set(ylabel='CP2K SCF iterations',ylim=(0,23),title='CP2K appendix · 800 Ry · EPS_SCF = 10⁻⁵')
ax.legend(ncol=2,loc='upper right',fontsize=10);ax.grid(axis='y',alpha=.15)
fig.text(.015,-.03,'QE-reference densities come from original QE reference LDOS, not a matched native QE electronic-state restart. '
         'Cutoffs are code-specific.',fontsize=9,color=GRAY)
save(fig,'CP2K_800Ry_comparison')

curves=rows('CP2K_trajectories.csv')
for system_cases,name in [(['Al298_GTH800','Al933_GTH800','B298_GTH800','Al298_UPF800'],'CP2K_pristine_trajectories'),
    (['B298_vac02','B298_vac03','B298_vac06','B298_mvac04','B298_v4_c1','B298_v4_c2'],'CP2K_vacancy_trajectories')]:
    fig,axes=plt.subplots(2,len(system_cases),figsize=(4*len(system_cases),8),layout='constrained',squeeze=False)
    for i,case in enumerate(system_cases):
        ref=float(next(r for r in curves if r['case']==case and r['branch']=='ATOMIC' and
            int(r['iteration'])==max(int(p['iteration']) for p in curves if p['case']==case and p['branch']=='ATOMIC'))['energy_Ha'])
        for branch,color in [('ATOMIC',ORANGE),('MALA',BLUE),('CP2K_reinjected',GREEN),('QE_reference',PURPLE)]:
            pts=[r for r in curves if r['case']==case and r['branch']==branch]
            if not pts:continue
            xx=[int(r['iteration']) for r in pts];yy=[float(r['residual']) for r in pts]
            axes[0,i].semilogy(xx,yy,'o-',ms=3,color=color,label=f'{branch.replace("_"," ")}: {len(pts)}')
            ep=[(int(r['iteration']),abs(float(r['energy_Ha'])-ref)*27.211386245988*1000/(256 if case.startswith('Al') else (144-int(next(r['vacancies'] for r in R if r['case']==case)) if case!='B298_GTH800' else 144))) for r in pts]
            ep=[(a,b) for a,b in ep if b>0]
            if ep:axes[1,i].semilogy(*zip(*ep),'o-',ms=3,color=color)
        thr=1e-7 if 'vacancy' in name else 1e-5
        axes[0,i].axhline(thr,color=INK,ls=':',lw=1);axes[0,i].set(title=case.replace('_',' '),ylabel='Printed CP2K SCF residual')
        if thr==1e-7:axes[0,i].axhline(1e-5,color=GRAY,ls='--',lw=1)
        axes[0,i].legend(fontsize=8)
        axes[1,i].set(ylabel='|E − ATOMIC endpoint| (meV/atom)',xlabel='SCF iteration')
        for a in axes[:,i]:a.grid(alpha=.15)
    save(fig,name)

# Reuse the native Fourier analysis; loading these saved planes performs no new FFT.
from matplotlib.colors import LogNorm
for case in ['Al298','Al933']:
    d=np.load(OUT/'data'/case/'fourier_plane.npz')
    gx=d['Gx_Ainv'];gy=d['Gy_Ainv'];planes=[d[str(i)] for i in [0,1,2,3,4,5]]
    positive=np.concatenate([p[np.isfinite(p)&(p>0)].ravel() for p in planes])
    vmin=max(np.percentile(positive,5),1e-14);vmax=np.max(positive)
    fig,axes=plt.subplots(2,3,figsize=(14,8),layout='constrained')
    titles=['Initial MALA − converged ATOMIC','Initial ATOMIC − converged ATOMIC','Initial MALA − initial ATOMIC',
            'First MALA response − converged ATOMIC','First ATOMIC response − converged ATOMIC','First MALA response − first ATOMIC response']
    for a,p,title in zip(axes.ravel(),planes,titles):
        image=a.pcolormesh(gx,gy,np.ma.masked_where(~np.isfinite(p)|(p<=0),p),shading='auto',cmap='magma',norm=LogNorm(vmin=vmin,vmax=vmax))
        a.set(title=title,xlabel=r'$G_x$ (Å$^{-1}$)',ylabel=r'$G_y$ (Å$^{-1}$)',aspect='equal');a.set_title(title,fontsize=10)
    fig.colorbar(image,ax=axes.ravel().tolist(),label='Saved |Δρ(G)| (e / Å³)',shrink=.85)
    fig.suptitle(case+' · native Fourier density differences · '+r'$h_3=0$'+' · DC excluded',weight='bold',fontsize=15)
    save(fig,case+'_Fourier_comparison')

(OUT/'plotting_completion.json').write_text(json.dumps(dict(status='COMPLETE',job=os.environ['SLURM_JOB_ID'],
    host=os.uname().nodename,new_FFTs=0,new_SCF=0,new_inference=0,figures=len(list((OUT/'figures').glob('*.pdf')))),indent=2)+'\n')
