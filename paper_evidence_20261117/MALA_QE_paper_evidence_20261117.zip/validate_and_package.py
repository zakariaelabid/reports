"""Validate saved text/arrays' metadata and build a portable evidence ZIP; no physics work."""
import csv,hashlib,json,re,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent
def rows(f):return list(csv.DictReader((P/'data'/f).open()))
R=rows('QE_iterations_and_improvements.csv');E=rows('density_errors_with_MSE.csv')
assert len(R)==12 and len(E)==450 and not any(r['case']=='B298_mvac02' for r in R+E)
assert len(rows('fourier_metrics.csv'))==72
assert len(rows('charge_and_positivity.csv'))==72
assert len(rows('QE_spatial_density_errors.csv'))==240
assert sorted(int(r['reinjection_steps']) for r in R if int(r['vacancies'])==1)==[2,3,3]
assert [int(r['reinjection_steps']) for r in R if int(r['vacancies'])==2]==[3,3,3]
assert [int(r['reinjection_steps']) for r in R if int(r['vacancies'])==4]==[2,2,2]
for r in R:
    a,m,c=map(int,[r['ATOMIC_steps'],r['MALA_steps'],r['reinjection_steps']])
    assert abs(float(r['reinjection_referenced_reduction_percent'])-100*(a-m)/(a-c))<1e-12
    assert int(r['electrons'])==3*int(r['atoms'])
    assert r['cutoffs_Ry']==('100/400' if r['case'].startswith('Al') else '80/320')

# Numeric curve values are also rechecked against stdout, not just the final counts.
def qe_parse(path):
    h=[];p=None
    for line in Path(path).read_text(errors='replace').splitlines():
        m=re.search(r'iteration #\s*(\d+)',line)
        if m:p=dict(iteration=int(m[1]));h.append(p)
        if p is not None:
            for key,pat in [('energy_Ry',r'total energy\s*=\s*([-+\d.Ee]+)'),('estimated_error_Ry',r'estimated scf accuracy\s*<\s*([-+\d.Ee]+)')]:
                m=re.search(pat,line)
                if m:p[key]=float(m[1])
    return h
def cmp(x,y):
    assert len(x)==len(y)
    for a,b in zip(x,y):
        assert int(a['iteration'])==int(b['iteration'])
        assert abs(float(a['energy_Ry'])-float(b['energy_Ry']))<1e-10
        v=b.get('estimated_error_Ry',b.get('estimated_SCF_accuracy_Ry'))
        assert abs(float(a['estimated_error_Ry'])-float(v))<1e-12
traj=rows('scf_trajectories.csv')
for r in R:
    for b,key in [('MALA','source_mala'),('ATOMIC','source_atomic')]:
        compare=[p for p in traj if p['case']==r['case'] and p['initialization']==b]
        cmp(qe_parse(Path(r[key])/'scf.out'),compare)
for system in ['Al298','Al933','B298']:
    d=json.loads((P/'sources'/f'{system}_reinjection_results.json').read_text())
    candidates=[p for p in (P/'raw_logs').rglob('output.out') if system in p.parts and 'reinject' in str(p)]
    assert len(candidates)==1,(system,candidates);cmp(qe_parse(candidates[0]),d['trajectory'])
vd=json.loads((P/'sources/vacancy_reinjection_summary.json').read_text())
for r in vd['cases']:
    candidates=list((P/'raw_logs/qe_native_20261103/b_vacancy_reinject_20261117/run-856943'/r['case']).glob('output.out'))
    assert len(candidates)==1;cmp(qe_parse(candidates[0]),r['trajectory'])

# Supply paired error/winner tables so the writing agent can bold matched values consistently.
pairs=[]
for case in [r['case'] for r in R]:
    for stage in ['initial','first']:
        regions=[r['region'] for r in E if r['case']==case and r['stage']==stage+'_MALA']
        for region in regions:
            m=next(r for r in E if r['case']==case and r['stage']==stage+'_MALA' and r['region']==region)
            a=next(r for r in E if r['case']==case and r['stage']==stage+'_ATOMIC' and r['region']==region)
            p=dict(case=case,label=m['label'],stage=stage,region=region,reference='same-case final ATOMIC Gamma QE valence density')
            for key in ['MAE_e_A3','MSE_e2_A6','RMSE_e_A3','relative_L1','relative_L2']:
                x=float(m[key]);y=float(a[key]);p['MALA_'+key]=x;p['ATOMIC_'+key]=y
                p['smaller_'+key]='tie' if x==y else ('MALA' if x<y else 'ATOMIC')
                p['ATOMIC_relative_reduction_percent_'+key]=100*(y-x)/y if y else ''
            pairs.append(p)
with (P/'data/QE_paired_density_errors_and_winners.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
figs=list((P/'figures').glob('*.pdf'));assert len(figs)==9
for p in figs:
    assert p.read_bytes().startswith(b'%PDF-')
    assert p.with_suffix('.png').exists() and p.with_suffix('.svg').exists()
plot=json.loads((P/'plotting_completion.json').read_text());assert plot['status']=='COMPLETE'
validation=json.loads((P/'validation.json').read_text())
validation.update(status='COMPLETE',QE_curve_values_rechecked_against_stdout=36,
    paired_density_error_rows=len(pairs),new_figures=9,existing_case_figure_sets=12,
    manuscript_edits=0,scientific_jobs_launched=0,
    figure_rendering_jobs=[dict(job=856986,cores=1,memory_GiB=2,elapsed_seconds=22),dict(job=856990,cores=1,memory_GiB=2,elapsed_seconds=27)],
    visual_review='All nine new figures inspected; existing per-case figures reused from saved audited report',
    intentionally_unavailable=['verified liquid-only Al933 training composition','matched pristine B800 CP2K MALA','full historical shuffled-data ancestry','uniform fresh runtime and repeated timing benchmark','complete tighter-state and eigenstate-resolved first-warning checks'])
(P/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
files=sorted(p for p in P.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.zip' and p.name!='SHA256SUMS.txt')
checksums=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(P))+'\n' for p in files)
(P/'SHA256SUMS.txt').write_text(checksums)
zpath=P/'MALA_QE_paper_evidence_20261117.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[P/'SHA256SUMS.txt']:z.write(p,str(p.relative_to(P)))
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    assert 'CHATGPT_PRO_HANDOFF.md' in z.namelist()
print(json.dumps(dict(zip=str(zpath),MiB=zpath.stat().st_size/1024**2,files=len(files)+1,validation=validation),indent=2))
