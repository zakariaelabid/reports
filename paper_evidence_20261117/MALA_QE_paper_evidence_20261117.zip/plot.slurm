#!/bin/bash
#SBATCH --job-name=MALA_paper_figures
#SBATCH --partition=cpu-genoa-int
#SBATCH --account=default
#SBATCH --qos=qos_default
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --hint=nomultithread
#SBATCH --mem=2G
#SBATCH --time=00:05:00
#SBATCH --output=/data/home2/elabid32/workspace/mala_aluminium/reports/paper_evidence_20261117/plot-%j.log
set -Eeuo pipefail
source /data/home2/elabid32/workspace/mala_aluminium/qe_native_20261103/runtime.sh
export LD_LIBRARY_PATH="/data/rosi/shared/pkg/devel/python/3.12.4/lib:$LD_LIBRARY_PATH"
exec /data/home2/elabid32/workspace/mala/mala_env/bin/python /data/home2/elabid32/workspace/mala_aluminium/reports/paper_evidence_20261117/make_figures.py
