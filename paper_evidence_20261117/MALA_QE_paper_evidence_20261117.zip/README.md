# MALA–QE manuscript evidence supplement — 17 November 2026

Upload **`MALA_QE_paper_evidence_20261117.zip`** and the supervisor's TeX to ChatGPT Web Pro.
Start with **[CHATGPT_PRO_HANDOFF.md](CHATGPT_PRO_HANDOFF.md)** inside the ZIP.

The package contains exact iteration/improvement tables, density-error tables,
checkpoint/configuration provenance, a CP2K appendix, saved SCF/Fourier figures,
and the full framework figure in PDF, editable SVG and PNG. It excludes the old
`B298_mvac02` from the retained numerical cohort.

Important corrections:

- Al933's 4000-wide network is in the unchanged official archive and actual tensor audit.
- Its liquid-only training composition remains unresolved.
- Exact vacancy reinjection counts are 2/3/3 (one vacancy), 3/3/3 (two), 2/2/2 (four).
- Iteration savings are the current endpoint; future GPU/system scaling is not a measured runtime guarantee.
- Native QE reinjection and QE-reference-density transfer into CP2K are distinct controls.

No manuscript edits, new SCF, inference, density calculations or FFTs were made.
Only small saved-data figure-rendering jobs used compute nodes.

Reproducibility scripts:

1. `compile_evidence.py`: saved text/metadata and log-count audits; original server paths required.
2. `make_figures.py` with `plot.slurm`: plotting on a compute node, from the packaged numeric caches/tables.
3. `write_handoff.py`: generates the detailed Markdown/tables from the packaged metadata; original support ZIP required for source copying.
4. `validate_and_package.py`: trajectory/metric/figure checks, checksums and ZIP integrity.

The scripts preserve original data. Do not execute historical scientific scripts
inside `sources/upstream_support/`; they are provenance records only.
