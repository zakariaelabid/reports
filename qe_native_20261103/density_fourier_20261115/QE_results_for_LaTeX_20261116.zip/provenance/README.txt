QE density/Fourier study, 2026-11-15

Scope: pristine Al298 snapshot 1, pristine Al933 snapshot 9, pristine B298
snapshot 6, and all ten unique completed Gamma boron vacancy cases.
Vacancies: vac02/vac03/vac06 (one); mvac02/dv2_c1/dv2_c2/dv2_c3 (two);
mvac04/v4_c1/v4_c2 (four). mvac04 is counted once. No Al vacancies or CP2K.

Main deliverables after analysis/completion.json reports COMPLETE:
  analysis/report.html                 linked tables and all case figures
  analysis/density_fourier_report.pdf   combined method/tables/figures
  analysis/initial_error_near_far.csv   compact initial near/far tables
  analysis/density_errors.csv          MAE, RMSE, relative L1/L2, region volumes
  analysis/fourier_metrics.csv         Parseval density and Hartree errors
  analysis/charge_and_positivity.csv    all six density stages per case
  analysis/case_summary.csv            parameters, counts and timing scopes
  analysis/scf_trajectories.csv         original complete production trajectories
  analysis/density_sources.json        exact field/XML paths and SHA256 hashes
  analysis/saved_audit_regression.json  comparison with the prior native B audit
  analysis/CASE/*.png,*.pdf,*.npz       case figures and compact numerical spectra

Initial and final fields are reused unchanged. The common reference for each
case is its converged ATOMIC-initialized QE valence density. Actual imported
MALA native coefficients are used, not rescaled/fitted raw network arrays.
No NLCC core charge, analysis renormalization, clipping or fitted shifts.
QE's existing atomic-superposition charge normalization is retained.

First-response fields were not saved in the original runs. Isolated bounded
one-outer-iteration diagnostic replays use the original executable, cell,
positions, pseudopotential, cutoff, grid, k points, smearing, solver, beta,
history, threshold, ranks and orbital initialization. Changes are only:
  electron_maxstep=100 -> 1; scf_must_converge=.false.; disk_io=low -> nowf.
The false convergence flag selects QE's unmixed rho output save path, rather
than the mixed rhoin. The forced printed 'converged in 1' is NOT convergence.
These runs do not replace the original production SCF counts or energies.
Each replay is checked against its original first estimated SCF error.
No source modifications or new compilation. Native inner accuracy retries,
if any, are retained and counted. Diagnostic energies are excluded because
the forced save path evaluates the endpoint functional differently.

Source evidence is pinned in manifest.json: QE7.5 electrons.f90 lines856-1010,
mix_rho.f90 and punch.f90. All original inputs and saved densities are pinned
by hashes. Each isolated diagnostic input has its exact input.diff.
The normal atomic-guess normalization initially triggered an overbroad
validator. Completed fields were retained/adopted, not rerun. Failed checker
logs/statuses are preserved. This was a validation error, not SCF divergence.

Spatial partitions, in Angstrom:
  nearest surviving nucleus <=0.75; 0.75-1.5; >1.5 (interstitial).
  separately, nearest vacancy site <=1.5; 1.5-3; >3 for defective B.
  Union/minimum distances prevent double counting overlapping spheres.
  Full periodic skew-cell geometry is used and checked against ASE MIC.
Radii are descriptive analysis choices, not pseudopotential core radii.
Empty regions are unavailable, not zero error.

Fourier: native QE G coefficients and conjugate-pair weights, real-grid
Parseval cross-check, physical Cartesian reciprocal coordinates. Spectra are
shell sums, not mode averages. 2D maps are the h3=0 reciprocal plane, zoomed to
|G|<=6 inverse Angstrom; they are not 3D projections. All six maps of a case
share one log color scale. DC is kept in charge/real-space tables but excluded
from Fourier/Hartree plots. Hartree RMS is the 4*pi/G^2-weighted zero-mean
potential error in eV, not SCF estimated error or total-energy error.

All cases are Gamma diagnostics. Original training-reference meshes were
Al8x8x8/B4x4x4. Pristine B used conv_thr=1.44e-4 Ry/cell; B vacancies1e-6.
Al used2.56e-4. Cross-vacancy-count iteration differences therefore include
the pristine/defective stopping-threshold difference. Within-pair settings
remain matched. CP2K EPS_SCF and VASP EDIFF are not equated to QE conv_thr.
Al933 official liquid-checkpoint training provenance remains unresolved.

Resources: retained previous Al8MPI/40GiB and B4MPI/4GiB, one thread/rank,
physical-core binding and single-thread BLAS; cpu-genoa-int/default.
Numerical analysis uses one core/4GiB with no inference/full SCF reruns.
All scientific work uses Slurm compute nodes. inspect_progress.py only reads
metadata/logs and is safe for the login node.

Original performance timings are separate SCF/process/template/conversion
scopes. Cached totals exclude prior network inference; new diagnostic and
analysis costs are also excluded. This report is reference-based diagnosis,
not a validated inference-time predictor of iterations or a speedup ceiling.

Completed: 13 cases, 492 spatial metric rows, 78 stage checks, 39 figures,
43 PDF pages. Every first SCF error and inner-warning count matches the
original run. Eighteen of 26 first responses retain original Davidson
warnings for 1-3 unconverged eigenvalues; those are not assumed unoccupied.
These are finite-tolerance benchmark responses, not exact inner solutions.
All density fields are finite/non-negative; charge errors below1e-10 e.
Visual and artifact integrity review: analysis/visual_review.json and
analysis/integrity_audit.json. No full SCF or MALA inference was repeated.
