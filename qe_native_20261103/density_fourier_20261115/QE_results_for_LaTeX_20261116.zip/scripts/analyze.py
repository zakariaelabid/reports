"""Native QE density, spatial-region and Fourier diagnostics; compute nodes only.

No inference or production SCF. No density fitting, normalization, clipping,
reference-assisted shifts or G=0 removal from real-space error metrics.
"""
import csv,gc,hashlib,html,itertools,json,math,os,re,resource,subprocess,sys,tempfile,time
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
from scipy.spatial import cKDTree
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.backends.backend_pdf import PdfPages

assert os.environ.get('SLURM_JOB_ID'),'Compute allocation required'
S=Path(__file__).resolve().parent;Q=S.parent
BOHR=.529177210903;HA_EV=27.211386245988;RY_EV=HA_EV/2
plt.rcParams.update({'font.size':10,'axes.titlesize':11,'axes.labelsize':10,
    'figure.facecolor':'white','axes.spines.top':False,'axes.spines.right':False,
    'savefig.dpi':180,'pdf.fonttype':42,'font.family':'DejaVu Sans'})
COL={'MALA':'#1864ab','ATOMIC':'#d94801','pair':'#6741a5'}
manifest=json.loads((S/'manifest.json').read_text());OUT=S/'analysis';OUT.mkdir(exist_ok=True)
PILOT=os.environ.get('QE_DENSITY_PILOT')
METRICS=[];CHARGE=[];FOURIER=[];TRAJECTORY=[];SUMMARY=[];PROVENANCE=[];PLOTS=[]
PDF=PdfPages(OUT/('pilot_tables_'+PILOT+'.pdf' if PILOT else 'tables_and_method.pdf'))

def save_json(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def status(**kw):save_json(S/'analysis_status.json',dict(job=os.environ['SLURM_JOB_ID'],**kw))
def csv_write(name,rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with (OUT/name).open('w') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def xml_read(p):
    root=ET.parse(p).getroot()
    def nodes(tag):return [e for e in root.iter() if e.tag.split('}')[-1]==tag]
    st=nodes('atomic_structure')[-1];children={e.tag.split('}')[-1]:e for e in st}
    cell=np.array([[float(v) for v in e.text.split()] for e in children['cell']])*BOHR
    pos=np.array([[float(v) for v in e.text.split()] for e in children['atomic_positions']])*BOHR
    f=nodes('fft_grid')[-1];shape=tuple(int(f.attrib['nr'+str(i)]) for i in [1,2,3])
    return dict(cell=cell,positions=pos,shape=shape,nelec=float(nodes('nelec')[-1].text),
        symbols=[e.attrib['name'] for e in children['atomic_positions']])
def dump(p,tmp):
    subprocess.run([str(Q/'tools/qe_h5_bridge'),'dump',str(p),str(tmp)],check=True,stdout=subprocess.DEVNULL)
    meta=json.loads(tmp.with_suffix('.json').read_text())
    mill=np.fromfile(str(tmp)+'.miller.i32',dtype=np.int32).reshape(-1,3)
    coef=np.fromfile(str(tmp)+'.rhog.f64',dtype=np.float64).view(np.complex128)
    assert len(coef)==meta['ngm_g'] and meta['gamma_only'] and meta['nspin']==1
    return meta,mill,coef.copy()
def real_grid(c,mill,shape):
    a=np.zeros(shape,dtype=np.complex128)
    a[tuple((mill%shape).T)]=c;a[tuple((-mill%shape).T)]=c.conj()
    a=np.fft.ifftn(a)*np.prod(shape)
    assert np.max(np.abs(a.imag))<1e-10
    return a.real.copy()/BOHR**3
def norms(c,w):return float(np.dot(w,np.abs(c)**2))
def regions(geom,removed):
    cell=geom['cell'];shape=geom['shape'];inv=np.linalg.inv(cell)
    positions=(geom['positions']@inv%1)@cell
    shifts=np.array(list(itertools.product([-1,0,1],repeat=3)))@cell
    tree=cKDTree((positions[None,:,:]+shifts[:,None,:]).reshape(-1,3))
    n=int(np.prod(shape));dist=np.empty(n);vdist=np.full(n,np.inf)
    vtree=None
    if len(removed):
        vp=(np.array(removed)@inv%1)@cell
        vtree=cKDTree((vp[None,:,:]+shifts[:,None,:]).reshape(-1,3))
    for start in range(0,n,65536):
        indices=np.arange(start,min(n,start+65536));frac=np.column_stack(np.unravel_index(indices,shape))/np.array(shape)
        points=frac@cell;dist[start:start+len(points)]=tree.query(points,workers=1)[0]
        if vtree:vdist[start:start+len(points)]=vtree.query(points,workers=1)[0]
    # Independent PBC check against ASE's general minimum-image algorithm.
    from ase.geometry import find_mic
    inds=np.linspace(0,n-1,17,dtype=int)
    points=(np.column_stack(np.unravel_index(inds,shape))/np.array(shape))@cell
    lengths=find_mic((points[:,None,:]-positions[None,:,:]).reshape(-1,3),cell,pbc=True)[1]
    assert np.max(np.abs(lengths.reshape(len(points),-1).min(axis=1)-dist[inds]))<1e-9
    masks=dict(global_region=np.ones(n,dtype=bool),near_nuclei_r_le_0p75A=dist<=.75,
        nuclear_shell_0p75_to_1p5A=(dist>.75)&(dist<=1.5),interstitial_r_gt_1p5A=dist>1.5)
    if vtree:masks.update(vacancy_core_union_r_le_1p5A=vdist<=1.5,
        vacancy_shell_union_1p5_to_3A=(vdist>1.5)&(vdist<=3),far_from_vacancies_r_gt_3A=vdist>3)
    assert sum(masks[k].sum() for k in ['near_nuclei_r_le_0p75A','nuclear_shell_0p75_to_1p5A','interstitial_r_gt_1p5A'])==n
    return masks
def parse_trajectory(p):
    text=Path(p).read_text();rows=[];row=None
    for line in text.splitlines():
        m=re.search(r'iteration #\s*(\d+)',line)
        if m:row=dict(iteration=int(m[1]));rows.append(row)
        if row is not None:
            for key,pattern in [('energy_Ry',r'total energy\s*=\s*([-+\d.Ee]+)'),
                ('estimated_error_Ry',r'estimated scf accuracy\s*<\s*([-+\d.Ee]+)')]:
                m=re.search(pattern,line)
                if m:row[key]=float(m[1])
    matches=re.findall(r'convergence has been achieved in\s+(\d+)',text)
    assert 'JOB DONE.' in text and matches and int(matches[-1])==len(rows)
    assert all('energy_Ry' in r and 'estimated_error_Ry' in r for r in rows)
    return rows
def param(text,key):
    m=re.search(r'\b'+re.escape(key)+r'\s*=\s*([\d.+EeDd-]+)',text,re.I);assert m,key
    return float(m[1].replace('d','e').replace('D','e'))
def fig_save(fig,case,kind):
    prefix=OUT/case/kind
    for ext in ['png','pdf']:fig.savefig(str(prefix)+'.'+ext,bbox_inches='tight')
    plt.close(fig);PLOTS.append(dict(case=case,kind=kind,path=str(prefix.relative_to(OUT))+'.png'))
def text_page(title,lines):
    fig=plt.figure(figsize=(11.7,8.3));fig.text(.07,.92,title,fontsize=21,weight='bold')
    fig.text(.07,.84,'\n\n'.join(lines),fontsize=12,va='top',linespacing=1.35,wrap=True)
    PDF.savefig(fig);plt.close(fig)
def curve(ax,x,y,**kwargs):
    good=np.isfinite(y)&(y>0);ax.plot(x[good],y[good],**kwargs)

text_page('QE density-error and SCF study',[
    '3 pristine systems: Al298 snapshot 1, Al933 snapshot 9, B298 snapshot 6.\n10 boron vacancy cases: 3 single, 4 double, 3 quadruple placements. Gamma only.',
    'Reference: each case’s saved, converged ATOMIC-initialized QE valence density.\nBoth initial guesses, their first unmixed responses, and MALA final endpoints are compared to it.',
    'First-response fields are bounded one-iteration diagnostics, NOT converged SCFs.\nThey retain finite Davidson tolerances and original inner-eigenvalue warnings.\nProduction trajectories, iteration counts and timings are reused unchanged.',
    'Native reciprocal coefficients; identical cell, G list, grid and zero origin.\nNo normalization, clipping, fitted translations or inclusion of NLCC core charge.',
    'Tables: near surviving nuclei (≤0.75 Å), shell (0.75–1.5 Å), interstitial (>1.5 Å).\nB vacancies also have vacancy-centered core, shell and far-field tables.',
    'See report.html and CSV files for all numerical tables, scope qualifications and sources.'])

for i,row in enumerate(manifest['cases']):
    name=row['id']
    if PILOT and not (name==PILOT or (PILOT=='B_ALL' and row['system']=='B298')):continue
    status(status='RUNNING',case=name,completed=i,total=13);(OUT/name).mkdir(exist_ok=True)
    cached=OUT/name/'computed_case.json'
    if cached.exists():
        data=json.loads(cached.read_text())
        for source in data['provenance']:assert sha(source['path'])==source['sha256']
        METRICS.extend(data['metrics']);CHARGE.extend(data['charge']);FOURIER.extend(data['fourier'])
        TRAJECTORY.extend(data['trajectory']);SUMMARY.append(data['summary']);PROVENANCE.extend(data['provenance']);PLOTS.extend(data['plots'])
        print(name+': reusing completed case analysis without FFT/plot repetition',flush=True);continue
    offsets=[len(a) for a in [METRICS,CHARGE,FOURIER,TRAJECTORY,PROVENANCE,PLOTS]]
    cfg=json.loads(Path(row['case_json']).read_text());comp=json.loads(Path(row['comparison']).read_text())
    for source,expected in row['hashes'].items():assert sha(source)==expected,(name,source)
    xml=Path(row['atomic'])/'scratch/case.save/data-file-schema.xml';geom=xml_read(xml)
    shape=geom['shape'];cell=geom['cell'];volume=abs(np.linalg.det(cell));volbohr=volume/BOHR**3
    assert len(geom['positions'])==row['atoms'] and abs(geom['nelec']-row['electrons'])<1e-8
    assert np.max(abs(cell-np.array(cfg['cell_A'])))<2e-8
    assert np.max(abs(geom['positions']-np.array(cfg['positions_A'])))<2e-8
    # Verify all fields' geometry from the matching XML (initial MALA uses its template).
    geometry_sources={'initial_MALA':Path(row['folder'])/'template/scratch/case.save/data-file-schema.xml',
        'initial_ATOMIC':Path(row['folder'])/'template/scratch/case.save/data-file-schema.xml'}
    for label,key in [('MALA','mala'),('ATOMIC','atomic')]:
        geometry_sources['final_'+label]=Path(row[key])/'scratch/case.save/data-file-schema.xml'
        geometry_sources['first_'+label]=S/'first_response'/name/label/'scratch/case.save/data-file-schema.xml'
    for key,p in geometry_sources.items():
        g=xml_read(p);assert g['shape']==shape and g['symbols']==geom['symbols']
        assert np.max(abs(g['cell']-cell))<1e-9 and np.max(abs(g['positions']-geom['positions']))<1e-9
        assert abs(g['nelec']-row['electrons'])<1e-8
    values={};meta=None;mill=None
    with tempfile.TemporaryDirectory(prefix='qe_density_analysis_',dir=os.environ.get('TMPDIR','/tmp')) as tmp:
        for key,p in row['fields'].items():
            p=Path(p);actualsha=sha(p)
            if str(p) in row['hashes']:assert actualsha==row['hashes'][str(p)]
            m,idx,c=dump(p,Path(tmp)/key)
            if meta is None:meta=m;mill=idx
            else:assert m==meta and np.array_equal(idx,mill)
            values[key]=c
            PROVENANCE.append(dict(case=name,stage=key,path=str(p),sha256=actualsha,geometry_xml=str(geometry_sources[key]),
                geometry_xml_sha256=sha(geometry_sources[key])))
    reciprocal=np.array(meta['reciprocal_vectors_bohr']);assert np.max(abs(cell/BOHR@reciprocal.T-2*np.pi*np.eye(3)))<1e-8
    assert np.all(np.max(abs(mill),axis=0)<np.array(shape)/2)
    g0=np.flatnonzero(np.all(mill==0,axis=1));assert g0.size==1;g0=int(g0[0])
    w=np.full(len(mill),2.);w[g0]=1
    gcart=mill@reciprocal;gbohr2=np.einsum('ij,ij->i',gcart,gcart);gabs=np.sqrt(gbohr2)/BOHR
    nonzero=gbohr2>0;kernel=np.zeros(len(mill));kernel[nonzero]=4*np.pi/gbohr2[nonzero]
    ref=values['final_ATOMIC'];refreal=real_grid(ref,mill,shape).ravel();refnorm=norms(ref,w)
    removed=[]
    if row['vacancies']:
        pristine=json.loads((Q/'cases/B298/pristine/case.json').read_text())
        removed=[pristine['positions_A'][j] for j in row['removed_indices']]
        assert len(removed)==row['vacancies']
    masks=regions(geom,removed);case_metrics={};fq={}
    edges=np.linspace(0,gabs.max()+1e-9,81);centers=(edges[1:]+edges[:-1])/2
    # Finite G=0 is retained in charge and real-space metrics; spectral errors are nonzero G.
    def spectrum(c):return np.histogram(gabs[nonzero],edges,weights=(w*np.abs(c)**2)[nonzero])[0]
    for key,c in values.items():
        rho=refreal if key=='final_ATOMIC' else real_grid(c,mill,shape).ravel()
        charge=float(c[g0].real*volbohr)
        assert abs(charge-row['electrons'])<1e-5 and abs(c[g0].imag)<1e-12
        assert np.isfinite(rho).all()
        CHARGE.append(dict(case=name,stage=key,electrons=charge,target_electrons=row['electrons'],
            charge_error_e=charge-row['electrons'],minimum_density_e_A3=float(rho.min()),
            negative_grid_points=int((rho<0).sum()),negative_integrated_e=float(-rho[rho<0].sum()*volume/rho.size),
            total_points=rho.size,grid='x'.join(map(str,shape))))
        d=rho-refreal;delta=c-ref
        assert np.isclose(np.mean(d*d),norms(delta,w)/BOHR**6,rtol=1e-9,atol=1e-20)
        for region,mask in masks.items():
            n=int(mask.sum());a=d[mask];b=refreal[mask]
            metric=dict(case=name,system=row['system'],vacancies=row['vacancies'],stage=key,region=region,
                points=n,volume_fraction=n/rho.size,MAE_e_A3=float(np.mean(abs(a))) if n else None,
                RMSE_e_A3=float(np.sqrt(np.mean(a*a))) if n else None,
                relative_L1=float(abs(a).sum()/abs(b).sum()) if n and abs(b).sum()>0 else None,
                relative_L2=float(np.linalg.norm(a)/np.linalg.norm(b)) if n and np.linalg.norm(b)>0 else None,
                signed_integrated_error_e=float(a.sum()*volume/rho.size) if n else None)
            METRICS.append(metric);case_metrics[(key,region)]=metric
        spec=spectrum(delta)/BOHR**6;hartree=spectrum(delta*kernel)*HA_EV**2
        fq[key]=dict(density_power=spec,Hartree_power=hartree)
        FOURIER.append(dict(case=name,stage=key,relative_L2=math.sqrt(norms(delta,w)/refnorm),
            density_RMSE_e_A3=math.sqrt(norms(delta,w))/BOHR**3,
            zero_mean_Hartree_error_RMS_eV=math.sqrt(norms(delta*kernel,w))*HA_EV,
            density_error_power_fraction_G_lt_1_Ainv=float((w[nonzero]*(abs(delta[nonzero])**2)*(gabs[nonzero]<1)).sum()/norms(delta,w)) if norms(delta,w)>0 else None,
            DC_density_error_e_A3=float(delta[g0].real/BOHR**3)))
        if key!='final_ATOMIC':del rho
        del d
    # Save compact, reusable numeric spectra instead of duplicated full-density arrays.
    cache=dict(G_shell_center_Ainv=centers,G_shell_edges_Ainv=edges,
        shell_mode_count=np.histogram(gabs[nonzero],edges,weights=w[nonzero])[0])
    for key,arrs in fq.items():
        for metric,a in arrs.items():cache[key+'_'+metric]=a
    np.savez_compressed(OUT/name/'fourier_shells.npz',**cache)
    # Native reciprocal-plane maps, preserving actual reciprocal geometry in skew B cells.
    plane=(mill[:,2]==0)&(gabs<=6+1e-10);pm=mill[plane]
    hmax=int(abs(pm[:,0]).max());kmax=int(abs(pm[:,1]).max())
    hh,kk=np.meshgrid(np.arange(-hmax,hmax+1),np.arange(-kmax,kmax+1),indexing='ij')
    xyz=hh[...,None]*reciprocal[0]/BOHR+kk[...,None]*reciprocal[1]/BOHR
    mapvalid=np.linalg.norm(xyz,axis=-1)<=6+1e-10
    def plane_map(c):
        a=np.full(hh.shape,np.nan,dtype=float);v=abs(c[plane])/BOHR**3
        a[pm[:,0]+hmax,pm[:,1]+kmax]=v;a[-pm[:,0]+hmax,-pm[:,1]+kmax]=v
        a[hmax,kmax]=np.nan;a[~mapvalid]=np.nan;return a
    diffs=[values['initial_MALA']-ref,values['initial_ATOMIC']-ref,values['initial_MALA']-values['initial_ATOMIC'],
        values['first_MALA']-ref,values['first_ATOMIC']-ref,values['first_MALA']-values['first_ATOMIC']]
    maps=[plane_map(d) for d in diffs];vmax=max(float(np.nanmax(a)) for a in maps);vmin=max(vmax*1e-6,1e-11)
    fig,axes=plt.subplots(2,3,figsize=(14,8),layout='constrained')
    titles=['Initial MALA − converged ATOMIC','Initial ATOMIC − converged ATOMIC','Initial MALA − initial ATOMIC',
        'First MALA response − converged ATOMIC','First ATOMIC response − converged ATOMIC','First MALA response − first ATOMIC response']
    for ax,a,title in zip(axes.flat,maps,titles):
        im=ax.pcolormesh(xyz[:,:,0],xyz[:,:,1],np.ma.masked_invalid(np.maximum(a,vmin)),
            shading='nearest',cmap='magma',norm=LogNorm(vmin=vmin,vmax=vmax),rasterized=True)
        ax.set(title=title,xlabel=r'$G_x$ (Å$^{-1}$)',ylabel=r'$G_y$ (Å$^{-1}$)',aspect='equal',xlim=(-6,6),ylim=(-6,6))
    fig.colorbar(im,ax=axes,shrink=.85,label=r'$|\Delta\rho_G|$ (e Å$^{-3}$); shared log scale')
    fig.suptitle(name+' · reciprocal plane h₃ = 0 · |G| ≤ 6 Å⁻¹ · DC excluded from maps',fontsize=14)
    np.savez_compressed(OUT/name/'fourier_plane.npz',Gx_Ainv=xyz[:,:,0],Gy_Ainv=xyz[:,:,1],**{str(j):a for j,a in enumerate(maps)})
    fig_save(fig,name,'fourier_maps')
    fig,ax=plt.subplots(2,3,figsize=(14,8),layout='constrained')
    for label in ['MALA','ATOMIC']:
        for stage,style,alpha in [('initial','-',1.),('first','--',.8)]:
            d=fq[stage+'_'+label];kw=dict(color=COL[label],linestyle=style,alpha=alpha,label=label+' '+stage)
            curve(ax[0,0 if stage=='initial' else 1],centers,np.sqrt(d['density_power']),**kw)
            power=d['density_power'];total=power.sum()
            ax[0,2].plot(centers,np.cumsum(power)/total,**kw)
            curve(ax[1,0],centers,np.sqrt(d['Hartree_power']),**kw)
        p0=fq['initial_'+label]['density_power'];p1=fq['first_'+label]['density_power']
        good=p0>p0.sum()*1e-12
        ax[1,1].plot(centers[good],np.sqrt(p1[good]/p0[good]),color=COL[label],label=label)
    for c,l,style in [(values['initial_MALA']-values['initial_ATOMIC'],'MALA − ATOMIC, initial','-'),
        (values['first_MALA']-values['first_ATOMIC'],'MALA − ATOMIC, first','--'),
        (values['final_MALA']-values['final_ATOMIC'],'MALA − ATOMIC, final',':')]:
        curve(ax[1,2],centers,np.sqrt(spectrum(c))/BOHR**3,color=COL['pair'],linestyle=style,label=l)
    ax[0,0].set(title='Initial error against final ATOMIC',ylabel='Shell RMS contribution (e Å⁻³)',yscale='log')
    ax[0,1].set(title='First unmixed response error',ylabel='Shell RMS contribution (e Å⁻³)',yscale='log')
    ax[0,2].set(title='Cumulative density-error power',ylabel='Fraction of nonzero-G error',ylim=(0,1.02))
    ax[1,0].set(title='Long-wave Hartree weighting (G ≠ 0)',ylabel='Shell potential RMS contribution (eV)',yscale='log')
    ax[1,1].axhline(1,color='gray',linestyle=':');ax[1,1].set(title='First / initial error by shell',ylabel='RMS amplification factor',yscale='log')
    ax[1,2].set(title='Direct pair differences across stages',ylabel='Shell RMS contribution (e Å⁻³)',yscale='log')
    for a in ax.flat:a.set_xlabel(r'$|G|$ (Å$^{-1}$)');a.legend(fontsize=8);a.grid(alpha=.15)
    fig.suptitle(name+' · native QE G sphere · shell sums, not means per mode',fontsize=14)
    fig_save(fig,name,'fourier_spectra')
    # Complete saved production SCFs, not one-response diagnostics.
    histories={label:parse_trajectory(Path(row[key])/'scf.out') for label,key in [('MALA','mala'),('ATOMIC','atomic')]}
    text=(Path(row['atomic'])/'input.in').read_text();thr=param(text,'conv_thr');e0=histories['ATOMIC'][-1]['energy_Ry']
    fig,axes=plt.subplots(1,2,figsize=(12,4.4),layout='constrained')
    for label,h in histories.items():
        assert h[-1]['estimated_error_Ry']<thr
        for point in h:TRAJECTORY.append(dict(case=name,initialization=label,**point))
        expected=comp[label]['iterations'] if 'MALA' in comp else comp[label+'_iterations']
        assert len(h)==expected
        steps=np.array([r['iteration'] for r in h]);err=np.array([r['estimated_error_Ry'] for r in h])
        energies=np.array([r['energy_Ry'] for r in h]);delta=abs(energies-e0)*RY_EV*1000/row['atoms']
        axes[0].semilogy(steps,err,'o-',markersize=3,color=COL[label],label=f'{label}: {len(h)} iterations')
        curve(axes[1],steps,delta,color=COL[label],marker='o',markersize=3,label=label)
    axes[0].axhline(thr,color='black',linestyle=':',label=f'conv_thr = {thr:g} Ry/cell')
    axes[0].set(xlabel='SCF iteration',ylabel='QE estimated SCF accuracy (Ry/cell)',title='Saved production SCF trajectories')
    axes[1].set(xlabel='SCF iteration',ylabel='|E − ATOMIC endpoint| (meV/atom)',yscale='log',title='Absolute total-energy difference; zero endpoint omitted')
    for a in axes:a.grid(alpha=.15);a.legend(fontsize=9)
    fig.suptitle(name+f' · {param(text,"ecutwfc"):g}/{param(text,"ecutrho"):g} Ry · Gamma · grid '+str(shape),fontsize=13)
    fig_save(fig,name,'scf_convergence')
    def getmetric(stage,region,key):return case_metrics[(stage,region)][key]
    def getf(stage,key):return next(v[key] for v in FOURIER if v['case']==name and v['stage']==stage)
    summary=dict(case=name,system=row['system'],snapshot=row['snapshot'],vacancies=row['vacancies'],atoms=row['atoms'],electrons=row['electrons'],
        cutoffs_Ry=f'{param(text,"ecutwfc"):g}/{param(text,"ecutrho"):g}',grid='×'.join(map(str,shape)),conv_thr_Ry=thr,
        MALA_steps=len(histories['MALA']),ATOMIC_steps=len(histories['ATOMIC']),iterations_saved=len(histories['ATOMIC'])-len(histories['MALA']),
        final_energy_difference_Ry=abs(histories['MALA'][-1]['energy_Ry']-e0),
        MALA_final_energy_Ry=histories['MALA'][-1]['energy_Ry'],ATOMIC_final_energy_Ry=e0,
        final_density_relative_L2=getf('final_MALA','relative_L2'))
    for label in ['MALA','ATOMIC']:
        if 'MALA' in comp:
            summary[label+'_SCF_seconds']=comp[label]['QE_SCF_timer']['wall_seconds']
            summary[label+'_process_seconds']=comp[label]['process']['process_wall_seconds']
            summary['cached_MALA_total_seconds']=comp['cached_MALA_total_wall_seconds']
        else:
            summary[label+'_SCF_seconds']=comp[label+'_QE_SCF_wall_seconds']
            summary[label+'_process_seconds']=comp[label+'_process_wall_seconds']
            summary['cached_MALA_total_seconds']=comp['cached_MALA_total_including_template_and_conversion_seconds']
        for stage in ['initial','first']:
            sk=stage+'_'+label
            summary[sk+'_global_relative_L2']=getmetric(sk,'global_region','relative_L2')
            for region,short in [('near_nuclei_r_le_0p75A','near'),('nuclear_shell_0p75_to_1p5A','shell'),('interstitial_r_gt_1p5A','far')]:
                summary[sk+'_'+short+'_RMSE_e_A3']=getmetric(sk,region,'RMSE_e_A3')
                summary[sk+'_'+short+'_relative_L2']=getmetric(sk,region,'relative_L2')
            summary[sk+'_Hartree_RMS_eV']=getf(sk,'zero_mean_Hartree_error_RMS_eV')
        summary[label+'_density_RMSE_amplification']=getf('first_'+label,'density_RMSE_e_A3')/getf('initial_'+label,'density_RMSE_e_A3')
        summary[label+'_Hartree_RMS_amplification']=getf('first_'+label,'zero_mean_Hartree_error_RMS_eV')/getf('initial_'+label,'zero_mean_Hartree_error_RMS_eV')
    summary['cached_template_plus_conversion_seconds']=summary['cached_MALA_total_seconds']-summary['MALA_process_seconds']
    summary['new_diagnostic_cost_excluded_from_production_timings']=True
    SUMMARY.append(summary);save_json(OUT/name/'case_summary.json',summary)
    save_json(cached,dict(metrics=METRICS[offsets[0]:],charge=CHARGE[offsets[1]:],fourier=FOURIER[offsets[2]:],
        trajectory=TRAJECTORY[offsets[3]:],provenance=PROVENANCE[offsets[4]:],plots=PLOTS[offsets[5]:],summary=summary))
    print(json.dumps(dict(case=name,completed=i+1,MALA_initial_L2=summary['initial_MALA_global_relative_L2'],
        MALA_response_L2=summary['first_MALA_global_relative_L2'],ATOMIC_initial_L2=summary['initial_ATOMIC_global_relative_L2'],
        ATOMIC_response_L2=summary['first_ATOMIC_global_relative_L2'])),flush=True)
    del values,ref,refreal,mill,gcart,diffs,maps,masks;gc.collect()

if PILOT:
    PDF.close();status(status='PILOT_COMPLETE',case=PILOT,completed=len(SUMMARY),total=13)
    raise SystemExit(0)
csv_write('density_errors.csv',METRICS);csv_write('charge_and_positivity.csv',CHARGE)
csv_write('fourier_metrics.csv',FOURIER);csv_write('scf_trajectories.csv',TRAJECTORY);csv_write('case_summary.csv',SUMMARY)
save_json(OUT/'density_sources.json',PROVENANCE)
# Independent regression against the saved eight-case native-coefficient audit.
prior=json.loads((Q/'b_seed_diagnosis_20261103/results.json').read_text())
regression=[]
for p in prior['rows']:
    case='B298' if p['case']=='pristine' else 'B298_'+p['case']
    now=next(r for r in FOURIER if r['case']==case and r['stage']=='initial_'+p['initialization'])
    assert abs(now['relative_L2']-p['initial_density_relative_L2_to_final_ATOMIC'])<1e-10
    assert abs(now['zero_mean_Hartree_error_RMS_eV']-p['initial_Hartree_potential_error_RMS_eV'])<1e-8
    regression.append(dict(case=case,initialization=p['initialization'],saved_native_audit_agreement=True))
save_json(OUT/'saved_audit_regression.json',regression)
compact=[]
for r in SUMMARY:
    keys=['case','vacancies','MALA_steps','ATOMIC_steps','initial_MALA_global_relative_L2','initial_ATOMIC_global_relative_L2']
    for region in ['near','shell','far']:
        keys.extend('initial_'+label+'_'+region+'_RMSE_e_A3' for label in ['MALA','ATOMIC'])
    compact.append({k:r[k] for k in keys})
csv_write('initial_error_near_far.csv',compact)
for region in ['near','shell','far']:
    fig,ax=plt.subplots(figsize=(11.7,8.3));ax.axis('off')
    vals=[[r['case'],f"{r['initial_MALA_'+region+'_RMSE_e_A3']:.5f}",f"{r['initial_ATOMIC_'+region+'_RMSE_e_A3']:.5f}",
        f"{r['first_MALA_'+region+'_RMSE_e_A3']:.5f}",f"{r['first_ATOMIC_'+region+'_RMSE_e_A3']:.5f}"] for r in SUMMARY]
    table=ax.table(cellText=vals,colLabels=['Case','Initial MALA','Initial ATOMIC','First MALA','First ATOMIC'],loc='center',cellLoc='center')
    table.auto_set_font_size(False);table.set_fontsize(11);table.scale(1,2)
    ax.set_title(region.capitalize()+' region RMSE (e Å⁻³) vs converged ATOMIC\nSame physical region for every stage',fontsize=16,pad=20)
    PDF.savefig(fig,bbox_inches='tight');plt.close(fig)
PDF.close()
subprocess.run(['/usr/bin/pdfunite',str(OUT/'tables_and_method.pdf'),
    *[str(OUT/r['case']/(kind+'.pdf')) for r in SUMMARY for kind in ['scf_convergence','fourier_spectra','fourier_maps']],
    str(OUT/'density_fourier_report.pdf')],check=True)

def fmt(v):
    if v is None:return 'Unavailable / empty region'
    if isinstance(v,bool):return str(v)
    if isinstance(v,(int,np.integer)):return str(v)
    if isinstance(v,float):return f'{v:.6g}'
    return html.escape(str(v))
def table(rows,columns):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(label)+'</th>' for key,label in columns)+'</tr></thead><tbody>'+''.join(
        '<tr>'+''.join('<td>'+fmt(r.get(key))+'</td>' for key,label in columns)+'</tr>' for r in rows)+'</tbody></table></div>'
doc=['<!doctype html><html><head><meta charset="utf-8"><title>QE density and Fourier diagnostics</title><style>body{font:16px system-ui,sans-serif;max-width:1450px;margin:40px auto;padding:0 24px;color:#172b4d;background:#fff}h1,h2,h3{color:#16385f}p,li{line-height:1.55}.scroll{overflow-x:auto;margin:18px 0}table{border-collapse:collapse;font-size:13px;white-space:nowrap}td,th{padding:9px 12px;border-bottom:1px solid #ddd;text-align:right}th{background:#eaf0f7}td:first-child,th:first-child{text-align:left}tr:nth-child(even){background:#f7f9fb}img{width:100%;height:auto}nav a{display:inline-block;margin:6px}.note{border-left:4px solid #1864ab;padding:12px;background:#eff6fc}a{color:#145b91}details{margin:16px 0}code{font-size:14px}</style></head><body>',
    '<h1>QE density errors, Fourier response and SCF convergence</h1>',
    '<p>Three pristine systems and ten boron vacancy cases. All Gamma-point QE; no CP2K or Al-vacancy cases. The reused first four-vacancy placement is counted once.</p>',
    '<p><a href="density_fourier_report.pdf">Combined PDF: figures and regional tables</a> · <a href="case_summary.csv">Case summaries</a> · <a href="density_errors.csv">Complete spatial errors</a> · <a href="fourier_metrics.csv">Fourier metrics</a> · <a href="charge_and_positivity.csv">Charge / positivity</a> · <a href="scf_trajectories.csv">SCF trajectories</a> · <a href="density_sources.json">Density sources / hashes</a></p>',
    '<div class="note"><strong>Reference and stages.</strong> Errors use each case’s saved converged ATOMIC-initialized QE valence density as a common reference. Initial fields are the actual native QE seed densities, after the original import projection, not raw MALA arrays. First fields are unmixed output densities from the first outer SCF iteration, including any native accuracy retry. They were recovered in isolated one-iteration diagnostics; their forced printed convergence messages do not establish convergence. All reported completion counts/timings come from the original full SCFs.</div>',
    '<h2>Regions and numerical definitions</h2><p>Near nuclei: distance to nearest <em>surviving</em> nucleus ≤0.75 Å. Shell: 0.75–1.5 Å. Interstitial: &gt;1.5 Å. Minimum-image distances use the full periodic cell, including skew boron geometry. These regions partition the cell. Vacancy-centered regions use distance to the nearest removed site: core ≤1.5 Å, shell 1.5–3 Å, far &gt;3 Å. They are a separate partition and may overlap nuclear regions. The radii are analysis choices, not pseudopotential core radii.</p>',
    '<p>MAE and RMSE are pointwise electron-density errors in e Å⁻³. Relative L1 = Σ|error|/Σ|reference| and relative L2 = √(Σerror²/Σreference²), computed separately within each region. Signed regional integrals are reported but are not local electron-count targets. Density is valence electron number density; NLCC core charge is excluded. This analysis applies no renormalization, clipping or fitted shifts. QE’s stock ATOMIC construction already normalizes its atomic superposition to the target charge; this intrinsic initialization behavior is retained and checked against the original logs. All native fields share the cell, coordinates, G list, FFT grid and zero origin.</p>',
    '<p>Fourier shell powers sum conjugate-pair-weighted |Δρ<sub>G</sub>|², not the average per mode. Their sum equals the nonzero-G real-space mean-square error (Parseval). DC errors remain in charge and real-space tables but are excluded from spectral and Hartree plots. Hartree potential RMS weights density coefficients by 4π/G² in atomic units, converts to eV, and sets the potential zero at G=0; it is not an SCF residual or total-energy error. Two-dimensional maps show |Δρ<sub>G</sub>| in the h₃=0 plane, |G|≤6 Å⁻¹, using Cartesian reciprocal coordinates and one shared log color scale per case. They are slices, not projections or the full 3D spectrum. Near/far regions refer to real-space distances; they must not be identified with high/low reciprocal radii.</p>',
    '<h2>Initial near/far density-error tables</h2><p>RMSE in e Å⁻³; M = MALA, A = ATOMIC. Full MAE, relative L1/L2, region fractions and all stages are in the linked CSV and per-case tables.</p>',
    table(compact,[('case','Case'),('initial_MALA_global_relative_L2','Global rel.L2 M'),('initial_ATOMIC_global_relative_L2','Global rel.L2 A')]+[(f'initial_{l}_{r}_RMSE_e_A3',f'{r} RMSE {l[0]}') for r in ['near','shell','far'] for l in ['MALA','ATOMIC']]),
    '<h2>Global density response (relative L2, fractions)</h2>',
    table(SUMMARY,[('case','Case'),('initial_MALA_global_relative_L2','Initial MALA'),('first_MALA_global_relative_L2','First MALA'),('initial_ATOMIC_global_relative_L2','Initial ATOMIC'),('first_ATOMIC_global_relative_L2','First ATOMIC'),('MALA_density_RMSE_amplification','M first/initial'),('ATOMIC_density_RMSE_amplification','A first/initial')]),
    '<h2>SCF counts and first-response comparison</h2>',
    table(SUMMARY,[('case','Case'),('MALA_steps','MALA steps'),('ATOMIC_steps','ATOMIC steps'),('conv_thr_Ry','conv_thr Ry/cell'),('initial_MALA_Hartree_RMS_eV','Initial Hartree M eV'),('first_MALA_Hartree_RMS_eV','First Hartree M eV'),('initial_ATOMIC_Hartree_RMS_eV','Initial Hartree A eV'),('first_ATOMIC_Hartree_RMS_eV','First Hartree A eV')]),
    '<p>Pristine stopping thresholds differ from vacancies: Al 2.56×10⁻⁴ Ry/cell, pristine B 1.44×10⁻⁴, B vacancies 10⁻⁶. Comparisons of MALA vs ATOMIC are matched within each pair. Counts across vacancy concentration also reflect this threshold change. QE conv_thr is an estimated self-consistency energy error, not CP2K EPS_SCF or VASP EDIFF.</p>',
    '<h2>Settings and timing scopes</h2>',
    table(SUMMARY,[(k,l) for k,l in [('case','Case'),('snapshot','Snapshot'),('vacancies','Vacancies'),('atoms','Atoms'),('electrons','Electrons'),('cutoffs_Ry','ecutwfc/ecutrho Ry'),('grid','FFT grid'),('MALA_SCF_seconds','M SCF s'),('ATOMIC_SCF_seconds','A SCF s'),('MALA_process_seconds','M process s'),('ATOMIC_process_seconds','A process s'),('cached_template_plus_conversion_seconds','Seed prep s'),('cached_MALA_total_seconds','Cached M total s'),('final_energy_difference_Ry','|ΔE final| Ry'),('final_density_relative_L2','Final M/A rel.L2')]]),
    '<p>Al: original Al.sr-pbesol.upf, PBEsol, 100/400 Ry, 576 bands, FD degauss 0.0019 Ry (298 K) / 0.0059 Ry (933 K), 8 MPI ×1 thread. B: original B_ncrs_v041_pbe.upf, PBE, 80/320 Ry, 280 bands, FD degauss 0.0018874 Ry, 4 MPI ×1 thread. All: Gamma, fixed geometry, plain modified-Broyden mixing beta=0.1/history=8, David initial threshold=10⁻⁵ Ry, fresh atomic+random orbitals, no wavefunction restart. Pseudopotential/executable hashes and input diffs are in ../manifest.json and ../first_response/.</p>',
    '<p>SCF wall, process wall and seed-template/conversion overhead are separate. Cached MALA totals exclude the previously performed network inference; new divacancy inference workers took roughly 69–71 s each plus shared startup. New diagnostic/analysis cost is excluded from original performance claims. Single timing observations are not timing distributions.</p>',
    '<h2>Interpretation limits</h2><p>These are Gamma diagnostics, whereas original QE training-reference k meshes were dense (Al 8³, B 4³). They do not establish dense-mesh performance. A smaller unweighted density L2 error does not guarantee fewer SCF iterations: long-wave electrostatic errors, response and mixing history also matter. The first-response fields are raw outputs before mixing; the production solver damps/mixes those outputs, so their errors are not the errors of the next mixed input. Fourier errors here require the converged reference and are diagnostic, not an inference-time predictor. Finite SCF tolerances permit slightly different endpoints; final density and energy differences are tabulated. Al933 official-checkpoint liquid-only training provenance remains unresolved. Only one frozen checkpoint per system is used; no checkpoint ensemble or blending is included.</p>',
    '<p>Native QE source evidence for first-response extraction: <code>PW/src/electrons.f90</code> lines 856–1010 mixes into rhoin while retaining output rho; scf_must_converge=false at electron_maxstep=1 selects the raw-output save path. <code>PW/src/punch.f90</code> writes rho. <code>disk_io=nowf</code> saves density/XML without wavefunctions. Executable/source unchanged. Each replay’s first printed SCF error is checked against its original production trajectory. The forced output path evaluates its final energy differently from an ordinary mixed first step; diagnostic energies are therefore excluded. All energy curves here use the original production logs. Replays reproduce the starting setup and first error; the missing original first-output arrays prevent a bitwise comparison to that original stage.</p>',
    '<p><strong>Inner diagonalization qualification:</strong> the first responses use the original finite Davidson tolerance and iteration limit. Eighteen of the 26 responses retain warnings for 1–3 unconverged eigenvalues, matching the original first iterations. The logs do not identify those states sufficiently to dismiss them as unoccupied. Thus these are responses under the actual benchmark settings, not fully converged inner eigensolutions; their errors cannot be attributed solely to exact physical density response. Full first-error/warning checks: <a href="first_response_checks.csv">CSV</a> / <a href="first_response_checks.json">JSON</a>.</p>',
    '<nav>'+''.join(f'<a href="#{r["case"]}">{r["case"]}</a>' for r in SUMMARY)+'</nav>']
for row in SUMMARY:
    name=row['case'];doc.append(f'<h2 id="{name}">{name}</h2>')
    source=next(r for r in manifest['cases'] if r['id']==name)
    if source['vacancies']:doc.append('<p>Removed original atom indices (zero-based): '+html.escape(str(source['removed_indices']))+'.</p>')
    doc.append(table([m for m in METRICS if m['case']==name and m['stage']!='final_ATOMIC'],[
        ('stage','Stage'),('region','Region'),('volume_fraction','Volume fraction'),('MAE_e_A3','MAE e/Å³'),('RMSE_e_A3','RMSE e/Å³'),('relative_L1','Relative L1'),('relative_L2','Relative L2')]))
    for kind in ['scf_convergence','fourier_spectra','fourier_maps']:
        doc.append(f'<p><a href="{name}/{kind}.pdf">{kind}: vector PDF</a></p><img loading="lazy" src="{name}/{kind}.png" alt="{name} {kind}">')
doc.append('</body></html>');(OUT/'report.html').write_text('\n'.join(doc))
save_json(OUT/'completion.json',dict(status='COMPLETE',job=os.environ['SLURM_JOB_ID'],cases=len(SUMMARY),
    spatial_metric_rows=len(METRICS),density_stage_checks=len(CHARGE),plots=len(PLOTS),
    all_counts_checked_against_original_logs=True,all_first_responses_reproduced_original_first_residual=True,
    cell_coordinates_grid_G_order_origin_units_and_electrons_checked=True,normalization=False,clipping=False,
    main_analysis_process_peak_RSS_GiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,
    summary=SUMMARY,plots_manifest=PLOTS))
status(status='COMPLETE',completed=13,total=13)
subprocess.run([sys.executable,str(S/'first_step_audit.py')],check=True)
subprocess.run([sys.executable,str(S/'visual_audit.py')],check=True)
