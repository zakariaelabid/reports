"""Metadata-only inventory and isolated one-response diagnostic inputs."""
import difflib, hashlib, json, re
from pathlib import Path

S=Path(__file__).resolve().parent; Q=S.parent
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
rows=[]
for system,job,ajob in [('Al298','817328','817372'),('Al933','817432','817432'),('B298','820078','820078')]:
    parent=Q/(system.lower()+'_mala_20261103')
    # B298 folder and Al folder names are deliberately identical to historical names.
    if system=='B298':parent=Q/'b298_mala_20261103'
    rows.append(dict(id=system,system=system,name='pristine',folder=str(parent/('run-'+job)),
        mala=str(parent/('run-'+job)/'mala'),atomic=str(parent/('atomic-'+ajob)/'atomic'),
        case_json=str(Q/'cases'/system/'pristine/case.json'),comparison=str(parent/'matched_comparison.json')))
for campaign,job,names in [('b_single_vacancy_20261103','820667',['vac02','vac03','vac06']),
    ('b_multi_vacancy_2_4_20261103','820728',['mvac02','mvac04','v4_c1','v4_c2']),
    ('b_divacancy_three_placements_20261115','849773',['dv2_c1','dv2_c2','dv2_c3'])]:
    for name in names:
        p=Q/campaign/('run-'+job)/name
        case=Q/'cases/B298'/name/'case.json'
        if name.startswith('dv2_'):case=Q/campaign/'input_templates'/name/'case.json'
        rows.append(dict(id='B298_'+name,system='B298',name=name,folder=str(p),mala=str(p/'mala'),atomic=str(p/'atomic'),
            case_json=str(case),comparison=str(p/'comparison.json')))
for row in rows:
    folder=Path(row['folder']); cfg=json.loads(Path(row['case_json']).read_text())
    row.update(snapshot=cfg.get('snapshot',6),vacancies=cfg.get('n_vac',2 if row['name'].startswith('dv2') else 0),
        atoms=cfg.get('natoms',len(cfg.get('positions_A',[]))),electrons=cfg.get('electrons'),
        removed_indices=cfg.get('removed_indices_zero_based',[]))
    row['fields']={
        'initial_MALA':str(folder/'initial_MALA_charge-density.hdf5'),
        'initial_ATOMIC':str(folder/'template/scratch/case.save/charge-density.hdf5'),
        'final_MALA':str(Path(row['mala'])/'scratch/case.save/charge-density.hdf5'),
        'final_ATOMIC':str(Path(row['atomic'])/'scratch/case.save/charge-density.hdf5')}
    row['hashes']={p:sha(p) for p in [*row['fields'].values(),row['case_json'],row['comparison']]}
    for label,key in [('MALA','mala'),('ATOMIC','atomic')]:
        original=Path(row[key])/'input.in'; text=original.read_text(); row['hashes'][str(original)]=sha(original)
        new,n=re.subn(r'electron_maxstep\s*=\s*100',"electron_maxstep=1,scf_must_converge=.false.",text,flags=re.I);assert n==1
        new,n=re.subn(r"disk_io\s*=\s*'low'","disk_io='nowf'",new,flags=re.I);assert n==1
        p=S/'first_response'/row['id']/label;p.mkdir(parents=True,exist_ok=False)
        (p/'input.in').write_text(new)
        (p/'input.diff').write_text(''.join(difflib.unified_diff(text.splitlines(True),new.splitlines(True),fromfile=str(original),tofile='diagnostic/input.in')))
        row['fields']['first_'+label]=str(p/'scratch/case.save/charge-density.hdf5')
        if label=='MALA':
            # The runner copies this file on the compute node, not orbitals/XML/history.
            (p/'seed_source.txt').write_text(row['fields']['initial_MALA']+'\n')
    # Verify a matched Hamiltonian and solver in the original pair.
    a=(Path(row['mala'])/'input.in').read_text(); b=(Path(row['atomic'])/'input.in').read_text()
    assert a.replace("startingpot='file'","startingpot='atomic'")==b,row['id']
assert len(rows)==13 and len({r['id'] for r in rows})==13
sources=[Q/'install/bin/pw.x',Q/'source/PW/src/electrons.f90',Q/'source/PW/src/punch.f90',
    Q/'source/PW/src/mix_rho.f90',Q/'pseudopotentials/Al.sr-pbesol.upf',Q/'pseudopotentials/B_ncrs_v041_pbe.upf']
manifest=dict(cases=rows,software_hashes={str(p):sha(p) for p in sources},
    stage_definition='first_* is the unmixed output rho of the first outer SCF iteration (including QE automatic inner diagonalization accuracy retry if any).',
    forced_stop='electron_maxstep=1,scf_must_converge=false forces the final branch to serialize raw rho, not mixed rhoin. Its printed convergence message is NOT a converged calculation.',
    source_evidence='QE7.5 electrons.f90:856-968 mixes into rhoin, leaves rho unchanged; line880 overrides conv_elec at last allowed iteration; lines980-1010 then retain raw rho. punch.f90 writes rho. No executable/source modifications.',
    changes=['one-iteration stopping/output control only','disk_io low -> nowf to avoid saving wavefunctions'],
    density_definition='positive electron-number valence density, excluding NLCC core; no normalization/clipping/fitting',
    scope='3 pristine Gamma cases plus 10 unique B vacancy Gamma cases. Excludes CP2K, Al vacancies, full-mesh tests and blending.')
(S/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps([dict(id=r['id'],atoms=r['atoms'],electrons=r['electrons'],vacancies=r['vacancies']) for r in rows],indent=2))
