"""Package saved reports/data/figures only; no scientific computations."""
import csv,hashlib,io,json,zipfile
from pathlib import Path
from html.parser import HTMLParser

S=Path(__file__).resolve().parent;A=S/'analysis'
manifest=json.loads((S/'manifest.json').read_text())
rows=list(csv.DictReader((A/'case_summary.csv').open()))
assert len(rows)==13 and json.loads((A/'integrity_audit.json').read_text())['status']=='PASS'
dest=S/'QE_results_for_LaTeX_20261116.zip'
assert not dest.exists(),'Preserve existing share packages'
members={}
def add(src,target):
    src=Path(src);assert src.is_file(),src
    assert target not in members,target
    members[target]=src.read_bytes()
for name in ['report.html','density_fourier_report.pdf','case_summary.csv','initial_error_near_far.csv',
    'density_errors.csv','fourier_metrics.csv','charge_and_positivity.csv','scf_trajectories.csv',
    'density_sources.json','completion.json','integrity_audit.json','visual_review.json',
    'saved_audit_regression.json','first_response_checks.csv','first_response_checks.json']:
    add(A/name,'analysis/'+name)
for case in manifest['cases']:
    name=case['id'];add(case['case_json'],'configurations/'+name+'.json')
    for filename in ['case_summary.json','computed_case.json','fourier_shells.npz','fourier_plane.npz']:
        add(A/name/filename,'analysis/'+name+'/'+filename)
    for kind in ['scf_convergence','fourier_spectra','fourier_maps']:
        for ext in ['png','pdf']:add(A/name/(kind+'.'+ext),'analysis/'+name+'/'+kind+'.'+ext)
    for label,key in [('MALA','mala'),('ATOMIC','atomic')]:
        for filename in ['input.in','scf.out']:
            add(Path(case[key])/filename,'qe_inputs_and_logs/'+name+'/'+label+'/'+filename)
        for filename in ['input.in','input.diff','diagnostic.json']:
            add(S/'first_response'/name/label/filename,'first_response_diagnostics/'+name+'/'+label+'/'+filename)
for name in ['manifest.json','README.txt','submitted_jobs.json','first_response_diagonalization_warnings.json']:
    add(S/name,'provenance/'+name)
for name in ['analyze.py','visual_audit.py','first_step_audit.py','first_response.py','prepare.py','package_for_latex.py']:
    add(S/name,'scripts/'+name)

cols=['case','snapshot','vacancies','removed_indices_zero_based','atoms','electrons','cutoffs_Ry','grid','conv_thr_Ry',
    'MALA_steps','ATOMIC_steps','iterations_saved','MALA_final_energy_Ry','ATOMIC_final_energy_Ry',
    'final_energy_difference_Ry','MALA_SCF_seconds','ATOMIC_SCF_seconds','MALA_process_seconds',
    'ATOMIC_process_seconds','cached_template_plus_conversion_seconds','cached_MALA_total_seconds']
merged=[]
for r in rows:
    case=next(c for c in manifest['cases'] if c['id']==r['case'])
    merged.append({**r,'removed_indices_zero_based':' '.join(map(str,case['removed_indices'] or []))})
buf=io.StringIO();writer=csv.DictWriter(buf,fieldnames=cols,extrasaction='ignore');writer.writeheader();writer.writerows(merged)
members['EXPERIMENTS.csv']=buf.getvalue().encode()
lines=['CURRENT QE COHORT: 13 MATCHED CASES','',
    'Steps and absolute final energies below come from original fully converged production logs.',
    'First-response diagnostic stops are NOT convergence results.',
    'All k-point sampling here is Gamma; snapshots: Al298=1, Al933=9, B298=6.',
    'Energies: QE total energy in Ry/cell; times: wall seconds. All atom indices are zero-based.','',
    'case | vacancies | removed indices | MALA/ATOMIC steps | MALA final E (Ry) | ATOMIC final E (Ry) | MALA/ATOMIC SCF wall (s)']
for r in merged:
    lines.append(f"{r['case']} | {r['vacancies']} | {r['removed_indices_zero_based'] or 'none'} | "
        f"{r['MALA_steps']}/{r['ATOMIC_steps']} | {r['MALA_final_energy_Ry']} | {r['ATOMIC_final_energy_Ry']} | "
        f"{r['MALA_SCF_seconds']}/{r['ATOMIC_SCF_seconds']}")
lines+=['','Detailed input settings, smearing, positions, cells and pseudopotentials: qe_inputs_and_logs/ and configurations/.',
    'Al: 100/400 Ry, PBEsol, Al.sr-pbesol.upf, 8 MPI x 1 thread; FD degauss .0019/.0059 Ry.',
    'B: 80/320 Ry, PBE, B_ncrs_v041_pbe.upf, 4 MPI x 1 thread; FD degauss .0018874 Ry.',
    'All pairs: plain modified Broyden beta=.1/history=8, David initial threshold=1e-5 Ry.',
    'Pristine thresholds: Al2.56e-4 Ry/cell, B1.44e-4; B vacancy threshold1e-6. Do not equate thresholds across codes.',
    'Near/far error definitions and all qualifications are in analysis/report.html and README.txt.']
members['EXPERIMENTS.txt']=('\n'.join(lines)+'\n').encode()
readme='''QE RESULTS FOR LATEX — 2026-11-16

Scope: CURRENT 13-case QE Gamma cohort only: pristine Al298, Al933, B298;
three B single vacancies, four B divacancy placements, three B four-vacancy
placements. This package is not the archive of all historical CP2K/QE tests.
The reused mvac04 configuration is counted once. No Al vacancies are included.

START HERE
  EXPERIMENTS.txt: human-readable counts, absolute final energies and SCF times.
  EXPERIMENTS.csv: compact table including settings and removed atom indices.
  analysis/report.html: full report with linked figures/tables (open after unzip).
  analysis/density_fourier_report.pdf: 43 pages of method, regional tables/figures.
  analysis/case_summary.csv: detailed settings, counts, energies, timing scopes.
  analysis/scf_trajectories.csv: full original per-iteration energies/residuals.
  configurations/CASE.json: exact cell, atom coordinates, snapshot, vacancy indices.
  qe_inputs_and_logs/: exact original MALA/ATOMIC production inputs and logs.
  analysis/CASE/: PNG previews and vector PDF figures for LaTeX includegraphics.
  analysis/density_errors.csv: MAE/RMSE/relative L1/L2 in all spatial regions.
  scripts/: saved analysis and diagnostic reproduction code.

IMPORTANT FOR THE LATEX MANUSCRIPT
* Reuse the original production step counts, NOT the forced one-step diagnostic
  'converged' messages. The first-response fields are intentionally bounded,
  unmixed outputs, not converged SCFs or the next mixed input density.
* Eighteen of26 first-response calculations retain original Davidson warnings
  for1-3 unconverged eigenvalues. First errors and warning counts reproduce the
  original runs. Do not present the first response as an exact inner solution.
* Common density reference: each case's converged ATOMIC-initialized QE density.
  Densities are valence electron-number density, not NLCC core density.
* Density units: e/Angstrom^3. Near surviving nuclei <=0.75Angstrom; shell0.75-1.5;
  interstitial>1.5. Vacancy-centered core/shell/far are separate regions.
* Fourier maps: h3=0 reciprocal-plane slices, |G|<=6 inverse Angstrom; spectra
  cover the native G sphere. Hartree RMS in eV is not an SCF energy residual.
* QE energy units are Ry/cell; energy curves show meV/atom relative to the
  ATOMIC endpoint. Retain finite-tolerance endpoint differences.
* SCF time, process wall and cached template/conversion overhead are separate.
  Cached totals exclude previous MALA inference. No end-to-end speedup is
  implied by iteration reduction alone.
* Retain actual cutoff and convergence labels. QE conv_thr is not CP2K EPS_SCF
  or VASP EDIFF. Original training-reference k meshes were denser than Gamma.
* Al933 official-checkpoint liquid-only training provenance remains unresolved.
* Never treat improved initial density L2 as proof of guaranteed SCF speedup.

No new science was run to create this package. Large native density arrays,
wavefunctions, model weights and pseudopotential binaries are excluded.
Their server paths/hashes remain in provenance/manifest.json and
analysis/density_sources.json. Check inputs before any future execution;
included server paths are provenance, not portable executable configuration.

Suggested instruction to GPT:
Use EXPERIMENTS.csv/txt and analysis/case_summary.csv for numerical tables,
qe_inputs_and_logs for verification, configurations for geometry, and the
individual vector PDFs for LaTeX figures. Preserve all numerical settings,
timing scopes and scientific qualifications. Do not invent unavailable data.
'''
members['README.txt']=readme.encode()
class Links(HTMLParser):
    def __init__(self):super().__init__();self.paths=[]
    def handle_starttag(self,tag,attrs):
        self.paths.extend(v for k,v in attrs if k in ['href','src'] and v and not v.startswith('#'))
p=Links();p.feed(members['analysis/report.html'].decode())
assert all('analysis/'+v in members for v in p.paths),[v for v in p.paths if 'analysis/'+v not in members]
checks={k:hashlib.sha256(v).hexdigest() for k,v in members.items()}
members['SHA256.json']=(json.dumps(checks,indent=2)+'\n').encode()
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_STORED) as z:
    for name,data in members.items():z.writestr(name,data)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(members)
    for name,expected in checks.items():assert hashlib.sha256(z.read(name)).hexdigest()==expected
print(json.dumps(dict(path=str(dest),size_MiB=round(dest.stat().st_size/1024**2,2),
    files=len(members),cases=13,figures_PNG=39,figures_PDF=39,all_HTML_links_portable=True,archive_integrity='PASS')))
