"""Report integrity and contact sheets; compute allocation required."""
import hashlib,json,os,re,subprocess
from html.parser import HTMLParser
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageOps
assert os.environ.get('SLURM_JOB_ID')
S=Path(__file__).resolve().parent;A=S/'analysis'
complete=json.loads((A/'completion.json').read_text());cases=[r['case'] for r in complete['summary']]
assert len(cases)==13 and complete['plots']==39 and complete['density_stage_checks']==78
info=subprocess.check_output(['/usr/bin/pdfinfo',str(A/'density_fourier_report.pdf')],text=True)
pages=int(re.search(r'Pages:\s+(\d+)',info)[1]);assert pages==43
class Links(HTMLParser):
    def __init__(self):super().__init__();self.paths=[]
    def handle_starttag(self,tag,attrs):
        for k,v in attrs:
            if k in ['href','src'] and v and not v.startswith('#'):self.paths.append(v)
p=Links();p.feed((A/'report.html').read_text())
assert all((A/x).exists() for x in p.paths),[x for x in p.paths if not(A/x).exists()]
contacts=[];sizes={}
font=ImageFont.truetype('/usr/share/fonts/dejavu-sans-fonts/DejaVuSans.ttf',22) if Path('/usr/share/fonts/dejavu-sans-fonts/DejaVuSans.ttf').exists() else ImageFont.load_default()
for kind in ['fourier_maps','fourier_spectra','scf_convergence']:
    for chunk in range(0,len(cases),4):
        tiles=[]
        for name in cases[chunk:chunk+4]:
            src=A/name/(kind+'.png');im=Image.open(src);im.verify();im=Image.open(src).convert('RGB')
            assert im.width>=1800 and im.height>=700
            sizes[str(src.relative_to(A))]=[im.width,im.height]
            tile=Image.new('RGB',(1150,740),'white');draw=ImageDraw.Draw(tile)
            draw.text((12,8),name+' / '+kind,fill='black',font=font)
            im=ImageOps.contain(im,(1130,690));tile.paste(im,((1150-im.width)//2,44));tiles.append(tile)
        sheet=Image.new('RGB',(2300,1480),'#d6dde5')
        for j,tile in enumerate(tiles):sheet.paste(tile,((j%2)*1150,(j//2)*740))
        dest=A/f'contact_{kind}_{chunk//4+1:02d}.png';sheet.save(dest);contacts.append(str(dest))
scripts={}
for p in S.glob('*.py'):scripts[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
(A/'integrity_audit.json').write_text(json.dumps(dict(status='PASS',job=os.environ['SLURM_JOB_ID'],
    cases=13,figures=39,PDF_pages=pages,all_report_links_exist=True,PNG_sizes=sizes,
    contact_sheets=contacts,script_sha256=scripts,visual_review='Contact sheets generated; human/assistant inspection recorded separately.'),indent=2)+'\n')
print(json.dumps(dict(integrity='PASS',PDF_pages=pages,figures=39,contact_sheets=len(contacts))))
