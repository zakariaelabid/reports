"""Read-only log validation plus tabulation; no density numerical operations."""
import csv,json,re
from pathlib import Path
S=Path(__file__).resolve().parent
rows=[]
for case in json.loads((S/'manifest.json').read_text())['cases']:
    for label,key in [('MALA','mala'),('ATOMIC','atomic')]:
        p=S/'first_response'/case['id']/label
        diagnostic=json.loads((p/'diagnostic.json').read_text())
        new=(p/'scf.out').read_text();original=(Path(case[key])/'scf.out').read_text()
        first=original[original.index('iteration #'):]
        first=re.split(r'iteration #\s*2\b',first)[0]
        pattern=r'c_bands:\s+(\d+) eigenvalues not converged'
        warnings=[int(n) for n in re.findall(pattern,new)]
        original_warnings=[int(n) for n in re.findall(pattern,first)]
        assert warnings==original_warnings,(case['id'],label,warnings,original_warnings)
        assert diagnostic['first_residual_reproduced']
        rows.append(dict(case=case['id'],initialization=label,
            first_error_Ry=diagnostic['first_estimated_error_Ry'],
            original_first_error_Ry=diagnostic['original_first_estimated_error_Ry'],
            original_first_error_reproduced=True,
            unconverged_inner_eigenvalue_warnings=' '.join(map(str,warnings)) or 'none',
            original_inner_warnings_reproduced=True,
            diagnostic_only_not_converged=True))
with (S/'analysis/first_response_checks.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary=dict(status='PASS',responses=len(rows),responses_with_inner_warnings=sum(r['unconverged_inner_eigenvalue_warnings']!='none' for r in rows),
    all_first_errors_and_inner_warning_counts_reproduce_original=True,rows=rows)
(S/'analysis/first_response_checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='rows'}))
