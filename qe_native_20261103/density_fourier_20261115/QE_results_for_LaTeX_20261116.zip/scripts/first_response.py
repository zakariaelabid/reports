"""Bounded diagnostic replays, not production converged SCFs. Compute only."""
import hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
S=Path(__file__).resolve().parent;Q=S.parent
assert os.environ.get('SLURM_JOB_ID')
group=sys.argv[1];ranks=8 if group=='Al' else 4
assert int(os.environ['SLURM_NTASKS'])==ranks
manifest=json.loads((S/'manifest.json').read_text()); out=S/('status_'+group+'.json')
def save(p,d):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(d,indent=2)+'\n');t.replace(p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def errors(text):return [float(v) for v in re.findall(r'estimated scf accuracy\s*<\s*([-+\d.Ee]+)',text)]
exe=Q/'install/bin/pw.x';assert sha(exe)==manifest['software_hashes'][str(exe)]
state=dict(status='RUNNING',job=os.environ['SLURM_JOB_ID'],group=group,completed=[])
if out.exists():
    previous=json.loads(out.read_text())
    assert previous['status']!='RUNNING','Do not overlap group workers'
    save(S/('status_'+group+'_attempt_'+previous['job']+'.json'),previous)
save(out,state)
try:
    for row in manifest['cases']:
        if row['system'].startswith('Al')!=(group=='Al'):continue
        for label,key in [('MALA','mala'),('ATOMIC','atomic')]:
            p=S/'first_response'/row['id']/label
            state.update(case=row['id'],initialization=label,started=time.time());save(out,state)
            reused=(p/'scf.out').exists()
            if (p/'diagnostic.json').exists():
                previous=json.loads((p/'diagnostic.json').read_text())
                assert previous['first_residual_reproduced'] and sha(row['fields']['first_'+label])==previous['output_density_sha256']
                state['completed'].append(row['id']+'/'+label);save(out,state);continue
            if label=='MALA' and not reused:
                src=Path(row['fields']['initial_MALA']);assert sha(src)==row['hashes'][str(src)]
                dst=p/'scratch/case.save';dst.mkdir(parents=True,exist_ok=False);shutil.copy2(src,dst/'charge-density.hdf5')
            launch=[str(Path(os.environ['EBROOTOPENMPI'])/'bin/mpirun'),'-np',str(ranks),'--bind-to','core',
                '--map-by','core','--report-bindings',str(exe),'-in','input.in']
            start=time.monotonic();peak=0
            if not reused:
              save(p/'launch.json',dict(job=os.environ['SLURM_JOB_ID'],MPI_ranks=ranks,
                   executable_sha256=sha(exe),input_sha256=sha(p/'input.in'),launch=launch))
              with (p/'scf.out').open('w') as f:
                proc=subprocess.Popen(launch,cwd=p,stdout=f,stderr=subprocess.STDOUT)
                while proc.poll() is None:
                    rss=0
                    for d in Path('/proc').glob('[0-9]*'):
                        try:
                            if d.joinpath('exe').resolve()!=exe:continue
                            if ('SLURM_JOB_ID='+os.environ['SLURM_JOB_ID']).encode()+b'\0' not in d.joinpath('environ').read_bytes():continue
                            m=re.search(r'VmRSS:\s+(\d+)',d.joinpath('status').read_text())
                            if m:rss+=int(m[1])
                        except (OSError,PermissionError):pass
                    peak=max(peak,rss)
                    state.update(elapsed_seconds=time.monotonic()-start,peak_RSS_GiB=peak/1024**2);save(out,state)
                    time.sleep(2)
            log=(p/'scf.out').read_text();old=(Path(row[key])/'scf.out').read_text()
            err=errors(log);old_err=errors(old)
            assert (reused or proc.returncode==0) and 'JOB DONE.' in log and len(re.findall(r'iteration #',log))==1
            assert err and old_err and abs(err[0]-old_err[0])<=max(1e-7,1e-5*abs(old_err[0])),(row['id'],label,err,old_err[:1])
            assert log.count('The initial density is read from file')==(label=='MALA')
            assert 'Error in routine' not in log
            if label=='MALA':assert 'renormalised' not in log
            else:
                # QE's stock atomic guess is normalized before its first Hamiltonian.
                # This must reproduce the original ATOMIC path, not be rejected.
                normalization=lambda t:re.findall(r'starting charge\s+[^\n]*renormalised[^\n]*',t)
                assert normalization(log)==normalization(old)
            assert Path(row['fields']['first_'+label]).exists()
            execution_job=(json.loads((p/'launch.json').read_text())['job'] if (p/'launch.json').exists()
                else json.loads((S/'submitted_jobs.json').read_text())['first_attempt_'+group])
            result=dict(status='FIRST_RESPONSE_ONLY_NOT_CONVERGED',case=row['id'],initialization=label,
                process_wall_seconds=None if reused else time.monotonic()-start,peak_RSS_GiB=None if reused else peak/1024**2,
                first_estimated_error_Ry=err[0],original_first_estimated_error_Ry=old_err[0],
                first_residual_reproduced=True,automatic_accuracy_retry_count=log.count('Diagonalizing with lowered threshold'),
                output_density_sha256=sha(row['fields']['first_'+label]),job=execution_job,validation_job=os.environ['SLURM_JOB_ID'],MPI_ranks=ranks,
                printed_convergence_message_is_forced=True,reused_completed_diagnostic_without_rerunning=reused)
            save(p/'diagnostic.json',result);state['completed'].append(row['id']+'/'+label);save(out,state)
    state.update(status='COMPLETE');save(out,state)
except Exception as e:
    state.update(status='FAILED',error=repr(e));save(out,state);raise
