QE RESULTS FOR LATEX — 2026-11-16

Scope: CURRENT 13-case QE Gamma cohort only: pristine Al298, Al933, B298;
three B single vacancies, four B divacancy placements, three B four-vacancy
placements. This package is not the archive of all historical CP2K/QE tests.
The reused mvac04 configuration is counted once. No Al vacancies are included.

START HERE
  EXPERIMENTS.txt: human-readable counts, absolute final energies and SCF times.
  EXPERIMENTS.csv: compact table including settings and removed atom indices.
  analysis/report.html: full report with linked figures/tables (open after unzip).
  analysis/density_fourier_report.pdf: 43 pages of method, regional tables/figures.
  analysis/case_summary.csv: detailed settings, counts, energies, timing scopes.
  analysis/scf_trajectories.csv: full original per-iteration energies/residuals.
  configurations/CASE.json: exact cell, atom coordinates, snapshot, vacancy indices.
  qe_inputs_and_logs/: exact original MALA/ATOMIC production inputs and logs.
  analysis/CASE/: PNG previews and vector PDF figures for LaTeX includegraphics.
  analysis/density_errors.csv: MAE/RMSE/relative L1/L2 in all spatial regions.
  scripts/: saved analysis and diagnostic reproduction code.

IMPORTANT FOR THE LATEX MANUSCRIPT
* Reuse the original production step counts, NOT the forced one-step diagnostic
  'converged' messages. The first-response fields are intentionally bounded,
  unmixed outputs, not converged SCFs or the next mixed input density.
* Eighteen of26 first-response calculations retain original Davidson warnings
  for1-3 unconverged eigenvalues. First errors and warning counts reproduce the
  original runs. Do not present the first response as an exact inner solution.
* Common density reference: each case's converged ATOMIC-initialized QE density.
  Densities are valence electron-number density, not NLCC core density.
* Density units: e/Angstrom^3. Near surviving nuclei <=0.75Angstrom; shell0.75-1.5;
  interstitial>1.5. Vacancy-centered core/shell/far are separate regions.
* Fourier maps: h3=0 reciprocal-plane slices, |G|<=6 inverse Angstrom; spectra
  cover the native G sphere. Hartree RMS in eV is not an SCF energy residual.
* QE energy units are Ry/cell; energy curves show meV/atom relative to the
  ATOMIC endpoint. Retain finite-tolerance endpoint differences.
* SCF time, process wall and cached template/conversion overhead are separate.
  Cached totals exclude previous MALA inference. No end-to-end speedup is
  implied by iteration reduction alone.
* Retain actual cutoff and convergence labels. QE conv_thr is not CP2K EPS_SCF
  or VASP EDIFF. Original training-reference k meshes were denser than Gamma.
* Al933 official-checkpoint liquid-only training provenance remains unresolved.
* Never treat improved initial density L2 as proof of guaranteed SCF speedup.

No new science was run to create this package. Large native density arrays,
wavefunctions, model weights and pseudopotential binaries are excluded.
Their server paths/hashes remain in provenance/manifest.json and
analysis/density_sources.json. Check inputs before any future execution;
included server paths are provenance, not portable executable configuration.

Suggested instruction to GPT:
Use EXPERIMENTS.csv/txt and analysis/case_summary.csv for numerical tables,
qe_inputs_and_logs for verification, configurations for geometry, and the
individual vector PDFs for LaTeX figures. Preserve all numerical settings,
timing scopes and scientific qualifications. Do not invent unavailable data.
