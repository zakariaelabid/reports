# Author handoff: available evidence, priority manuscript changes and remaining gaps

**Audit date:** 17 November 2026, Europe/Berlin. **Purpose:** instructions and evidence for the agent editing the supervisor's LaTeX manuscript. This is a records audit, not a new simulation or a claim that missing records exist.

All paths below are relative to `/data/home2/elabid32/workspace/mala_aluminium` unless explicitly absolute. The original 16 November sharing ZIP is unchanged. This handoff and its small supporting-records ZIP supplement it; the reinjection results were omitted from that original ZIP.

## 1. Priority: include the converged-QE-density reinjection controls

**Availability: YES for all three pristine systems.** These are genuine fully converged QE calculations, not the forced first-response diagnostics. Their original inputs, logs, trajectories, source-density hashes, energies, timing records and import checks exist. All three converged in **3 SCF iterations**.

No retained boron-vacancy QE reinjection result was established by the records inspected for this audit. For those configurations, report reinjection as **not available for this manuscript**, rather than substituting a CP2K control, a pristine control, or an assumed three-step result.

### 1.1 Exact experiment and interpretation

For each pristine case, the final native QE `charge-density.hdf5` from its matched ATOMIC-initialized production calculation was copied unchanged to a fresh working directory. The only numerical input-file change was `startingpot='atomic'` to `startingpot='file'`. The Hamiltonian, geometry, cutoffs, grid, Gamma sampling, smearing, diagonalization threshold and SCF convergence criterion were retained.

The new run used `restart_mode='from_scratch'` and `startingwfc='atomic+random'`. **No wavefunctions, XML electronic restart or mixing history were copied.** The source density hashes and the one-key input difference were rechecked during this audit. Genuine convergence messages, final residuals and the saved results agree.

This is a **density-only reinjection control**. It measures the observed work required when a finite-tolerance converged density is supplied through QE's file-initialization path while orbitals and mixing history are rebuilt. It is relevant to the author's concern about external-density initialization.

**Do not describe the three remaining iterations as a direct measurement of density-import error or an external-module defect.** This is stock QE `startingpot='file'`; the native density was copied without conversion or interpolation. Fresh orbitals, finite inner diagonalization and SCF tolerances also contribute. It is not an electronic-state restart and does not establish a theoretical acceleration ceiling.

### 1.2 Counts and SCF wall times

The SCF wall column uses QE's `electrons` timer, in seconds. The three timing observations are not repeated-trial means.

| System / snapshot | ATOMIC steps | MALA steps | Reinjection steps | ATOMIC SCF s | MALA SCF s | Reinjection SCF s |
| --- | --- | --- | --- | --- | --- | --- |
| Al298 / 1 | 14 | 10 | 3 | 1328.76 | 1174.91 | 632.42 |
| Al933 / 9 | 16 | 13 | 3 | 1472.24 | 1371.95 | 664.96 |
| B298 / 6 | 11 | 8 | 3 | 78.57 | 62.29 | 39.66 |

### 1.3 The author's proposed normalized reduction

Use the author's expression with an explicitly defined cost:

\[
\eta_C=\frac{C_{\mathrm{ATOMIC}}-C_{\mathrm{MALA}}}
{C_{\mathrm{ATOMIC}}-C_{\mathrm{reinjection}}}.
\]

For iteration counts, choose \(C=N_{\rm SCF}\); for timings, choose exactly one consistent timing scope. Suggested name: **fraction of the observed reinjection-referenced reduction achieved by MALA**. It is a descriptive, empirical score against this measured control, not an ordinary multiplicative speedup and not a proven fraction of a theoretical maximum.

| System | Count calculation | Iteration score | SCF-time score |
| --- | --- | --- | --- |
| Al298 | (14−10)/(14−3) | 36.36% | 22.09% |
| Al933 | (16−13)/(16−3) | 23.08% | 12.42% |
| B298 | (11−8)/(11−3) | 37.50% | 41.84% |

For example, the Al298 count score means MALA saved 4 of the 11 iterations separating ATOMIC from the measured density-only reinjection result. It does **not** mean a 36.36% reduction relative to ATOMIC: the ordinary ATOMIC-relative iteration reduction is a different quantity, \((N_A-N_M)/N_A\).

Do not combine an ATOMIC SCF timer with a MALA cached workflow time or a reinjection process wall in one ratio. Do not call the present scores fresh end-to-end inference scores. A zero/nonpositive denominator should be reported as undefined for this interpretation. Negative scores or scores above one, if observed in future, must not be clipped to fit a presumed bound.

Additional consistently labelled bookkeeping ratios from the saved timings follow. The cached-workflow version uses ATOMIC process wall, MALA template+conversion+process wall, and reinjection process wall. It excludes prior network inference and reinjection input-copy work outside the process timer, so it remains a cached-workflow diagnostic rather than a full application benchmark.

| System | ATOMIC process s | MALA process s | Reinjection process s | MALA cached total s | Process-time score | Cached-workflow score |
| --- | --- | --- | --- | --- | --- | --- |
| Al298 | 1383.821536 | 1230.177484 | 696.852318 | 1298.939512 | 22.37% | 12.36% |
| Al933 | 1528.072235 | 1427.953763 | 727.245608 | 1486.722411 | 12.50% | 5.16% |
| B298 | 83.982425 | 69.249946 | 46.189161 | 77.505643 | 38.98% | 17.14% |

**Timing qualification:** the Al reinjection records explicitly report different Slurm-assigned physical-core indices on one socket compared with the original source calculations, despite the same node, eight physical cores, binding method, socket distribution and loaded libraries. Boron reports identical physical-core indices and library paths. Retain this limitation for small timing differences; the iteration scores are not wall-time confidence intervals.

### 1.4 Reinjection endpoints and source files

| System | Reinjection final E (Ry/cell) | Final estimated SCF error (Ry/cell) | abs(E_R − E_source) (Ry/cell) |
| --- | --- | --- | --- |
| Al298 | -1187.06614919 | 0.00014066 | 9.024e-05 |
| Al933 | -1183.71054761 | 6.974e-05 | 3.184e-05 |
| B298 | -846.41156830 | 2.319e-05 | 4.661e-05 |

The energy differences are consistent with the finite stopping tolerances; they are not proof of identical orbitals or a rigorous energy-error bound. Source paths:

- **Al298:** `qe_native_20261103/al_reinject_20261103/run-819341/Al298/` contains `input.in`, `output.out`, `results.json`, `trajectory.csv`. Source density SHA256: `313fe694d180eb47b5dca4d3d239cf327f6fcdfd10ab9b1f15183474d8b9de74`.
- **Al933:** `qe_native_20261103/al_reinject_20261103/run-819341/Al933/` contains `input.in`, `output.out`, `results.json`, `trajectory.csv`. Source density SHA256: `881d4d37511ee9eb3f1817b00605f30a81b327d635e88749d235b1919d7fc1bf`.
- **B298:** `qe_native_20261103/b_reinject_20261103/run-820105/B298/` contains `input.in`, `output.out`, `results.json`, `trajectory.csv`. Source density SHA256: `5f9b548a478ecc7d04ba2f269eb2c1858fc7c3193d7217e5c2e75ed5a3c4b545`.

The combined source summaries are `qe_native_20261103/al_reinject_20261103/summary.json` and `qe_native_20261103/b_reinject_20261103/summary.json`. This handoff also supplies `reinjection_results.csv` and a new read-only log/input/hash audit. Three-way SCF curves can be drawn from the saved production trajectories plus these saved reinjection trajectories; no new SCF is needed. The original 39-figure set did not include those three-way reinjection curves.

## 2. Priority: bold better results without changing the scientific meaning

**Availability: YES.** The numeric tables and underlying precision are available. This is a LaTeX formatting change, not a new calculation.

- Bold the smaller error for matched MALA/ATOMIC comparisons, separately for each case, region, metric and stage. This includes cases where ATOMIC is better after the first response.
- Bold the smaller genuine production iteration count and the smaller timing only where the timing scopes match. Keep reference reinjection columns visually separate; define the primary bold comparison as MALA versus ATOMIC, so the control does not obscure that comparison.
- For exact ties, bold both or neither consistently; use a caption stating the rule. If values round to the same displayed value, do not imply a meaningful winner hidden in unreported digits. A single slightly smaller timing is not evidence of statistical significance.
- Do not automatically bold the more negative final total energy as a 'better initializer'. These are finite-tolerance endpoints under the same Hamiltonian. An energy-error ranking requires a justified common independent reference.
- Do not compare seconds with iterations, differently scoped preparation totals, different systems, or different stopping thresholds as though they were matched alternatives.
- **Metric names matter:** the bundle contains MAE and RMSE, as well as relative L1/L2. RMSE is not MSE. If a manuscript table really contains MSE, verify its derivation and squared density units; do not relabel RMSE as MSE. No new MSE array calculation was performed for this handoff.

Suggested caption: “Bold indicates the smaller value within each matched MALA/ATOMIC pair; ties at the reported precision are shown equally. Reinjection is a separate density-only reference control. Timing entries are single observations.”

## 3. Priority: replace obscure vacancy names and retain the exclusion

**Availability: YES.** Use the following fixed mapping in the manuscript, plots, captions and appendix. Keep old IDs only in the reproducibility mapping. The three divacancy sets are the three newly selected placements; do not silently reuse the excluded earlier divacancy.

| Manuscript label | Internal ID | Removed parent indices, zero-based | MALA steps | ATOMIC steps |
| --- | --- | --- | --- | --- |
| B298, 1 vacancy, set 1 | `B298_vac02` | 89 | 15 | 16 |
| B298, 1 vacancy, set 2 | `B298_vac03` | 29 | 15 | 17 |
| B298, 1 vacancy, set 3 | `B298_vac06` | 62 | 16 | 18 |
| B298, 2 vacancies, set 1 | `B298_dv2_c1` | 5, 106 | 18 | 21 |
| B298, 2 vacancies, set 2 | `B298_dv2_c2` | 15, 26 | 21 | 22 |
| B298, 2 vacancies, set 3 | `B298_dv2_c3` | 45, 92 | 21 | 21 |
| B298, 4 vacancies, set 1 | `B298_mvac04` | 5, 34, 88, 95 | 17 | 18 |
| B298, 4 vacancies, set 2 | `B298_v4_c1` | 84, 91, 109, 138 | 18 | 18 |
| B298, 4 vacancies, set 3 | `B298_v4_c2` | 17, 28, 46, 71 | 17 | 17 |

Use **“pristine Al298,” “pristine Al933,” and “pristine B298”** for the three no-vacancy cases. Set numbering restarts at one for each vacancy count; set 1 at one vacancy is not a matched/nested precursor of set 1 at two or four vacancies. Periodic boundaries do not create surfaces. Re-title existing figure labels from saved plot data where necessary, preserving every trajectory and error value. Describe the retained configuration set; do not call it every divacancy experiment ever run.

**Exclude `B298_mvac02` / `mvac02` from the manuscript and all aggregates, figures and appendices.** Preserve it in the immutable archive; do not rename it as one of the retained three divacancy sets.

The retained cohort is **12 configurations**: three pristine + nine defective B configurations (three placements each at 1, 2 and 4 vacancies). It contains 24 matched production SCFs plus the three pristine reinjection SCFs. The retained first-response diagnostics number 24; 16 retain inner-eigenvalue warnings. Filtering the existing density report removes 42 regional metric rows: 450 remain, with 72 six-stage density checks and 36 per-case figures. These are dataset counts, not independent timing repetitions.

## 4. Availability overview for the seven author questions

“Available” means a specific existing record was found, not that every such file was included in the old ZIP. “Partial” separates recoverable facts from unestablished claims. “Not established” is not proof that a record cannot exist elsewhere.

| Question | Availability | Action for the LaTeX agent |
| --- | --- | --- |
| 1. Frozen models/settings | Mostly available; historical version provenance partial | Use exact checkpoint hashes/configurations below; retain runtime-version qualifications. |
| 2. Al933 liquid-only provenance | Unresolved | Keep the qualification; the official label and verified download do not settle training composition. |
| 3. Training/validation/test membership | Partial, with important explicit validation memberships | Al298 snapshot1 and B298 snapshot6 are validation entries; do not call them independent unseen tests. |
| 4. Fresh preparation/inference timings | Many raw records available; uniform fresh end-to-end benchmark unavailable | Use labelled stage timings; do not invent uniform totals or amortization. |
| 5. Repeated timing/execution provenance | Execution records largely available; repetitions/cache conditions not established | Keep timings as single observations; report available hardware/runtime/binding details. |
| 6. Transfer provenance | Converter/source and 12 case-specific audits available | The old bundle omission can be repaired; separate native projection from upstream generation. |
| 7. Endpoint/inner-solver validation | Partial | Use saved finite-tolerance endpoints and empty-band checks; no eigenstate identification or new tighter benchmark is established. |

## 5. Question1: frozen checkpoints, descriptors, network and density generation

### 5.1 Available exact model identifiers and files

**Al298:** `298K_0/model/Al_298K_0` plus the following suffix files; SHA256 values were rechecked without loading/retraining the network:

```text
Al_298K_0.network.pth  1a4bcd531feac9f1a040cb239fa2541087cdb51ecb82ff5cd341ef03f09c1f0e
Al_298K_0.params.json  c05bdbab69507ded9e8b721fd8738c115812a9255b362cebecbe34cb7be9ae4f
Al_298K_0.iscaler.pkl  549e8fdcf7dfc531e50fe1dc0a7dc34e3941dd5a8230b43843d857c1c1496147
Al_298K_0.oscaler.pkl  0faef03a1db8409ad99ca14d02a147954d2247d1f4ff4ec6af626d45f81d5212
Al_298K_0.info.json  c17bfc3d84dd166e4df079b1b5e9242737e52c18355d6735bc2ed9fca49ac5df
```

**Al933:** `933K_liquid/model_record 2725/Al_933K_liquid` plus the following suffix files; SHA256 values were rechecked without loading/retraining the network:

```text
Al_933K_liquid.network.pth  1c7edc27c7df1bfa02d76ee1f925515b6de40d02359d05a011bf9846377e8052
Al_933K_liquid.params.json  63fdae14926c09ebd705fb94feb3d7b3ec49a537a07a9f4474882e64c7fe0681
Al_933K_liquid.iscaler.pkl  1f7699d43efc0c27e9a49c660c9846ecc90b711c5cc21eebaa3ae48eaac3ffc6
Al_933K_liquid.oscaler.pkl  3e1e493b6bb41f93da0a80fad51c4f960f28602b7f42c6951a3c8d545c80596e
Al_933K_liquid.info.json  955ac6005c50c1caffe975f54b17da5a09430041d048933b9ca6e2efea66122b
```

**B298:** `boron_298K/model_archives/boron_model_multi_0` plus the following suffix files; SHA256 values were rechecked without loading/retraining the network:

```text
boron_model_multi_0.network.pth  a1d8c32983f70ba8f20351401ce32595c53f08253cf3929ce38bffe2cba169d4
boron_model_multi_0.params.json  1f1d7ebc5b4e8eb5980f3f0c6a9899f25cf3165531e36afea73737aaf36b64af
boron_model_multi_0.iscaler.pkl  d97caf2fe7979d708b11383e5a375013bae1a960827dc5ac8b21260ffa091e1a
boron_model_multi_0.oscaler.pkl  a8573d0a0757213fea453ad80908915aa0b24ed7c1cf495bf65f40968cc3dcd8
```

The `.params.json` and available `.info.json` files are copied into the supporting-records ZIP. Network weights and scalers remain available on the server at these paths, but are not silently embedded as huge binaries in this handoff. Five archived boron checkpoints exist; **member 0** is the one used throughout this matched study. No checkpoint ensemble was used. The saved `loss_function_type=mse` describes the training objective; it does not make the reported density RMSE tables MSE tables.

### 5.2 Descriptor/network/energy-grid settings read directly from saved parameters

| Setting | Al298 | Al933 | B298 |
| --- | --- | --- | --- |
| Descriptor | SNAP/bispectrum | SNAP/bispectrum | SNAP/bispectrum |
| bispectrum_twojmax | 10 | 10 | 10 |
| bispectrum_cutoff (Å) | 4.67637 | 4.67637 | 4.67637 |
| bispectrum_switchflag | 0 | 0 | 1 |
| Network feature count | 91 | 91 | 91 |
| Saved full layer_sizes | 91→800→800→800→250→250 | 91→4000→4000→4000→250→250 | 91→800→800→800→250→241 |
| Activation | LeakyReLU | LeakyReLU | LeakyReLU |
| LDOS grid points | 250 | 250 | 241 |
| LDOS start / spacing (eV) | −10 /0.1 | −10 /0.1 | −8 /0.1 |
| Last energy-grid point (eV) | 14.9 | 14.9 | 16.0 |
| Input scaling | feature-wise-standard | feature-wise-standard | feature-wise-standard |
| Output scaling | normal | normal | normal |
| Frozen LDOS restriction | zero_out_negative | zero_out_negative | zero_out_negative |

Do not simplify away the penultimate 250-neuron layer. Retained compatibility checks establish five Linear/LeakyReLU pairs including the output activation for the audited Al298 and B workers. Configuration fields such as dropout must not be mistaken for active stochastic inference: the workers use evaluation mode. A serialized activation-list compatibility adapter was applied without changing frozen tensors/scalers.

Available source establishes the density path: generate descriptors for the explicit geometry, scale features with frozen scalers, predict LDOS, apply the frozen negative-LDOS restriction, spatially integrate LDOS to DOS, solve the electron-number equation for chemical potential at the specified temperature, and analytically integrate occupied LDOS to density. This charge constraint is a consistency operation, not a density-accuracy measurement.

The current MALA DOS implementation uses `scipy.optimize.toms748`, bracketed by the LDOS energy-grid endpoints, for the number-conserving chemical potential; the integration method is `analytical`. Current source is provided as an implementation record; do not present a current source hash alone as a complete frozen environment identity for every older inference job.

B vacancy workers explicitly set `N_e=3(144−N_vac)` and 298 K, and save both density- and DOS-integrated electron counts. Their `density_fixed_pristine_mu.npy` arrays are diagnostics: **the self-consistent-number `density.npy` is the one imported into the matched QE runs.** Network arithmetic is float32 with audited float64 LDOS/density handling in the vacancy workflow. The original pristine B compatibility record explicitly notes previous float32 versus current float64 LDOS handling; do not say every historical inference had identical precision.

No extra scalar-density positivity clipping or charge renormalization was applied by the audited QE converter. That statement does not mean raw network LDOS was never clipped: the frozen `zero_out_negative` LDOS convention is part of upstream inference.

### 5.3 Version availability

The actual Al298 snapshot1 inference record `298K_0/protocol_20261019/validation05/mesh200/mala.json` saves these runtime versions:

```json
{
  "torch": "2.14.0",
  "numpy": "2.5.3",
  "scipy": "1.18.1",
  "ase": "3.29.0",
  "mpi4py": "4.1.2",
  "materials-learning-algorithms": "1.4.0"
}
```

The currently installed source also reports MALA 1.4.0. Exact checkpoint identities, compatibility tests and runtime environment scripts are available for B/Al933, but this audit did not establish an equally complete contemporaneous package-version dictionary for every older Al933/B prediction. **Do not substitute today's installed version for missing historical runtime records, or assert an exact original training-library version from the checkpoint name.** Legacy 1.2.1 compatibility evidence is not itself a complete original training-environment manifest.

The MALA generation temperature recorded for nominal Al298 is299.98637294316444K, consistent with the retained QE `degauss=0.0019 Ry`; nominal Al933 is931.5366317708792K (`degauss=0.0059 Ry`). B uses nominal298K with `degauss=0.0018874 Ry`. Keep nominal system names but report actual numerical smearing parameters.

## 6. Question2: Al933 provenance remains unresolved

**Not available:** authoritative evidence settling whether the weights were trained only on liquid configurations.

**Available:** official RODARE record 2725, unchanged checkpoint files, download identity and the audit `933K_liquid/handoff_audit_20261021/evidence.json`. Official archive MD5 is `397f2de4df02b63ee1c6023591b8c144`; SHA256 is `13076e6f2385ae8ed00cbb733f243405e337ad5c7094274ed93fe881edeb192c`.

Its saved parameters list four training and one validation `Al_mixed_snapshot0–4` entries under `phase_boundaries/solid`. The official network/scalers match the previously inspected mirror. This is a real metadata conflict; it does not prove that the weights were solid-trained, nor does a successful liquid calculation settle it. No hybrid-trained model was substituted.

Recommended wording: “The official liquid-labelled checkpoint was used unchanged; its saved training-path metadata leaves liquid-only training provenance unresolved.” Definitive training-composition confirmation still needs the model/data authors or a corrected authoritative record.

## 7. Question3: data splits, parent snapshots and defect-training status

| System | What the saved record establishes | What remains unestablished |
| --- | --- | --- |
| Al298 | Frozen manifest and supplied train_Al298K.py: snapshot 0 training; snapshot 1 validation, 200³ grid. | Independent unseen-test status cannot be claimed for snapshot1; complete original MD/training history is not reconstructed here. |
| Al933 | Published evaluation script evaluates raw indices 0–19 as test rows; snapshot9 selected before CP2K trials from nominal holdouts 5–9 by favorable published energy error. | Exact overlap with the ambiguous frozen training composition is unresolved. |
| B298 | Manifest: shuffled/mixed snapshots 0–5 training; B_snapshot6 validation, 108×108×135. Training-file hashes/profile exist. | Original parent membership of every shuffled sample and absence of overlap/leakage require the shuffle-generation provenance. |

Al933 snapshot9's published absolute energy error was 0.5059195 meV/atom (about0.506). This was favorable-case selection, not a representative-performance sample or a density-error guarantee. The published script's saved examples 7 and 17 are not a ranking that declares 7 most accurate.

No vacancy-containing training files are listed in the inspected frozen manifests; all current defective geometries were generated later by removing atoms from the retained B parent using the unchanged member 0 model. **That is not an exhaustive proof that every original training point lacked defects**, particularly where shuffled-parent provenance or Al933 composition remains unresolved. Describe these as a frozen-model vacancy stress test without retraining; avoid a categorical unseen/OOD claim based solely on a new geometry label. Existing descriptor OOD profiles provide feature-distribution diagnostics, not a proof of dataset independence.

Available B training identity: `boron_298K/vacancy_20261023/training_source_identity.json` binds six mixed/shuffled descriptor HDF5 files with hashes; `training_profile.json` and the saved numerical training-reference profiles also exist. The original MD equilibration, sampling interval, trajectory independence and full training optimization history are only partly represented by saved QE inputs/outputs and model parameters. No complete reconstruction of those histories was established by this audit.

## 8. Question4: raw preparation/inference timings do exist, but are not uniform end-to-end benchmarks

**Availability: PARTIAL, with more existing information than the old ZIP conveyed.** Do not request all timings as though no raw records existed.

### 8.1 Pristine cases

The actual Al298 `mala.json` contains model/import/geometry, SNAP, gather, scaling/check/save, network, DOS, chemical potential, density, cube write/verification, reference-accuracy and runtime-audit timers. Its process wrapper is also saved. Exact values:

| Al298 timer | Seconds |
| --- | --- |
| import_model_geometry_seconds | 3.960076431 |
| SNAP_seconds | 247.885350287 |
| gather_seconds | 2.011582904 |
| descriptor_check_scale_save_seconds | 4.836606679 |
| network_seconds | 42.070161201 |
| LDOS_check_save_seconds | 1.794870473 |
| DOS_seconds | 1.193211114 |
| fermi_seconds | 1.517042929 |
| density_seconds | 0.973655794 |
| density_checks_save_seconds | 1.745462788 |
| cube_write_seconds | 3.442925153 |
| cube_verification_seconds | 2.778987646 |
| reference_accuracy_seconds | 238.581458025 |
| runtime_identity_audit_seconds | 7.044787103 |

Al298 total worker time: **570.310661199s**; launcher process wall: **571.8559432476757s**. The worker total includes the reference-accuracy audit; it must not be presented as a clean inference-only deployment time. The actual worker uses CPU inference despite running inside a GPU-node allocation: `params.use_gpu=False`, with eight descriptor MPI ranks and root Torch threads set to 8. Do not describe allocated GPUs as used inference devices.

Al933's finalized metadata retains `T_descriptor=247.689873s`, `T_inference=773.662112s`, and `T_density=4.990563s`. These are the saved stage labels, not an established complete launch-to-export fresh total; postprocessing recovery and cube-header precision records exist and must be considered before reconstructing any total.

Pristine B's original metadata retains descriptor459.445770774s, inference18.026062857s, density4.072958279s, and cube-write2.689587183s. Those labels likewise do not establish an independently timed model-load cost or a uniform full workflow boundary matching the other materials.

### 8.2 All nine retained B vacancy predictions have raw worker timing records

“Scaling/OOD” includes diagnostic analysis. “DOS/Fermi/density” includes extra fixed-pristine-mu diagnostic work in this worker. Worker wall excludes shared model loading that precedes the per-case `predict()` timer. These are recorded local/root worker stages, not guaranteed per-stage maximum-rank critical-path timings.

| Label | SNAP s | Scaling/OOD s | Network s | DOS/Fermi/density s | Worker wall s |
| --- | --- | --- | --- | --- | --- |
| B298, 1 vacancy, set 1 | 70.444470 | 0.394547 | 8.300673 | 2.374354 | 82.465452 |
| B298, 1 vacancy, set 2 | 60.344708 | 0.385575 | 8.418988 | 2.113384 | 72.149427 |
| B298, 1 vacancy, set 3 | 62.319270 | 0.369900 | 8.420327 | 1.813594 | 73.818315 |
| B298, 2 vacancies, set 1 | 58.317760 | 0.670078 | 8.352934 | 2.151341 | 70.584242 |
| B298, 2 vacancies, set 2 | 57.303024 | 0.446493 | 8.027207 | 2.304986 | 69.156017 |
| B298, 2 vacancies, set 3 | 57.540735 | 0.470823 | 8.147634 | 2.101114 | 69.350899 |
| B298, 4 vacancies, set 1 | 56.987307 | 0.392295 | 7.940521 | 2.089448 | 68.713146 |
| B298, 4 vacancies, set 2 | 64.273980 | 0.408125 | 7.994107 | 2.068348 | 76.264098 |
| B298, 4 vacancies, set 3 | 56.959877 | 0.410731 | 7.982168 | 2.062027 | 68.726801 |

For the three new divacancies, the complete shared prediction process wall is **286.9949199060211s** (`run-mala-849771/final_status.json`), whereas the three workers are 70.58424155198736,69.15601704799337,69.35089924902422s. The difference includes shared initialization/coordination/diagnostics and is **not** an isolated measured model-load time. Do not divide it equally among cases without labelling that as an accounting convention.

Sources: individual `cases/CASE/result.json` under `boron_298K/vacancy_20261023`, `boron_298K/multivacancy_20261026`, `boron_298K/vacancy_placements_4_8_20261026`, and `qe_native_20261103/b_divacancy_three_placements_20261115` (exact retained-case values are in `vacancy_prediction_timings.csv`).

QE template-generation and conversion subprocess timers exist per case, and the existing case-summary table separates them from QE process and SCF wall. **Missing:** a consistently scoped, repeated, fresh full deployment benchmark for every retained case with standardized model-loading/amortization, diagnostics, I/O and cache policies. Do not manufacture this by adding incomparable stage labels.

## 9. Question5: hardware, execution and timing repeatability

**Available:** saved Slurm job IDs, case order in controller scripts, MPI/thread layouts, binding reports, process timer code, loaded library paths, and environment scripts. The QE private executable is pinned to SHA256 `5b9e3e77bd823d87b818fc932eef52bfea45049419277a4a34727726f7fcb203`; runtime uses QE 7.5, GCC 14.3.0, OpenMPI 5.0.8 and single-thread BLAS. Recorded QE libraries include OpenBLAS 0.3.30, FlexiBLAS 3.4.5, FFTW 3.3.10, ELPA 2025.06.002 and HDF5 1.14.6. `qe_native_20261103/runtime.sh` and per-run process/summary records are the evidence.

QE runs use AMD EPYC 9654 Genoa compute resources, eight MPI ranks for Al and four for B, one thread each. Recorded inference topology for the new B divacancies explicitly identifies AMD EPYC 9654, eight CPU ranks, no GPU inference, GCC 14.2 / OpenMPI 4.1.8 / Python 3.12.4 runtime paths. The old Al298 prediction used a GPU-node allocation but CPU-only inference, with different thread choices as noted above. Do not silently assume one common inference machine/thread policy for every historical density.

Process wall boundaries are in the controller source: monotonic timer around the launched subprocess, through exit and monitoring/polling. Those timers include launcher/startup/shutdown and polling granularity; QE's `electrons` timer is a separate internal scope. Run order and case/binding metadata are recoverable; records do not establish a randomized benchmark design.

**Not established:** controlled repetitions for the exact current matched QE pairs/reinjection controls, error bars/confidence intervals, standardized warm/cold filesystem or page-cache state, and complete noise-isolation conditions. Other historical runs must not be counted as timing repetitions if geometry, tolerances, Hamiltonian, solver, resources or cache scope differ. Keep current small timing differences as single observations.

## 10. Question6: converter source and per-case transfer audits

**Availability: YES for the converter implementation and all 12 retained native imports.** The old ZIP's incomplete inclusion is a packaging omission, not absence of these records on the server.

Converter source: `qe_native_20261103/tools/density_to_qe.py`; current SHA256 **`f11e28c4a12b2dce0d301dda8a608cfda7642240334e9ffffc82367ffe2cdf08`**, matching the frozen Al298 source hash. Native HDF bridge source: `qe_native_20261103/tools/qe_h5_bridge.c`, SHA256 **`076060c9c41e1438b28229eba1cddfc9de1a6f061931334b8f278785f59790b7`**. Treat these hashes as implementation identities; no invented semantic converter release is needed.

The converter checks the explicit source geometry, cell, full array coverage, units, electron number and native template metadata; converts e/Å³ to e/bohr³; projects onto QE's native reciprocal G sphere; writes native density coefficients and reads them back. All serialized coefficients are verified against the intended coefficients. There is no fitting to a converged reference, clipping or charge normalization in this transfer. Native G-sphere projection need not be identically zero even when the real-grid dimensions match.

Saved raw-source→native projection relative L2 values (fractions, not percentages):

| Case | Projection relative L2 | Native electrons |
| --- | --- | --- |
| Al298, pristine | 0.00112248931455 | 767.999999999999 |
| Al933, pristine | 0.00167178106484 | 767.999999999999 |
| B298, pristine | 0.00143788565142 | 432.000000000000 |
| B298, 1 vacancy, set 1 | 0.00143976967198 | 429.000000000000 |
| B298, 1 vacancy, set 2 | 0.00143961895844 | 429.000000000001 |
| B298, 1 vacancy, set 3 | 0.00143789827872 | 429.000000000001 |
| B298, 4 vacancies, set 1 | 0.00145803978219 | 419.999999999999 |
| B298, 4 vacancies, set 2 | 0.00145504861564 | 420.000000000000 |
| B298, 4 vacancies, set 3 | 0.00145496682837 | 419.999999999999 |
| B298, 2 vacancies, set 1 | 0.00144654484031 | 426.000000000000 |
| B298, 2 vacancies, set 2 | 0.00144186184105 | 426.000000000000 |
| B298, 2 vacancies, set 3 | 0.00144339634681 | 426.000000000000 |

Each audit is at `ORIGINAL_CASE_MALA_BRANCH/scratch/case.save_charge-density_conversion/validation.json`; `import_audits.csv` gives its exact path and source/native hashes. This handoff rechecked that the source array and actual initial native density match the hashes in each saved audit. No density FFT or new projection was performed here.

The small supporting ZIP includes all 12 audit JSONs, converter/bridge sources and the actual Al/B UPF files. Large native HDF densities and model-weight binaries remain on the server; their existence/identities can be checked there, while the LaTeX agent should not pretend to have inspected omitted binary contents locally. Upstream model and generation-version limitations remain distinct from the verified native-transfer step.

## 11. Question7: endpoint, occupation and inner-solver checks

**Available:** original production convergence histories; finite-tolerance final energy/density comparisons for matched pairs; final Fermi energies and highest-band occupations in the saved results/XML records; occupation/empty-band guards in the controller scripts; and the three converged density-only reinjection controls. Pristine ATOMIC highest-band occupations are approximately8.26e−66 (Al298),3.61e−19 (Al933),3.65e−81 (B298). Reinjection highest-band occupations are approximately9.46e−66,3.65e−19,3.61e−81 respectively.

These establish ample empty top bands under the saved checks; **they do not identify which eigenstates triggered a first-Davidson warning**. QE native XML files and occupation data remain available on the server, but the printed warning gives a count rather than a usable identity for those individual states.

For the retained12-case cohort, all 24 first-response diagnostics reproduce the original first printed SCF error and inner-warning counts;16 contain warnings for 1–3 unconverged eigenvalues. Full retained checks are provided in `retained_first_response_checks.json`. Their forced one-step completion flags must never be used as genuine production convergence counts. Raw first responses also differ from the next mixed solver input.

**Not established by this audit:** an additional same-settings tighter-endpoint convergence study for every retained case, exact orbital/electronic-state identity, or state-resolved identification/occupation of the warning eigenstates. Other tighter/alternative historical experiments are not automatically matched controls for this cohort. Do not fill this gap with CP2K checks, unrelated QE settings or an assumption that the warned states are unoccupied.

## 12. Instructions for the LaTeX agent and remaining genuine questions

1. Preserve the supervisor's scientific intent and valid citations. Update Methods, Results, Discussion and relevant summary sections only as supported by the supplied evidence.
2. Implement Sections1–3 of this handoff first: reinjection controls and explicitly scoped empirical score; honest bolding; clear vacancy labels with the fixed exclusion.
3. Add the frozen-model settings, validation-set memberships and existing timing/transfer evidence. Do not continue listing available files/timers as completely missing.
4. Retain author questions for unresolved Al933 composition, shuffled-data ancestry/independence and full MD/training history, missing historical environment identities, clean full fresh runtime accounting, timing repetitions/cache policy, and tighter/state-resolved checks.
5. Recompute every aggregate after excluding `B298_mvac02`. Do not reuse the old 13-case counts,18/26 warnings,492-row or39-figure totals for the filtered manuscript.
6. Do not infer additional DFT calculations, retraining, formation energies, density accuracy versus an independent Hamiltonian, or genuine uncertainty estimates where not supplied. The printed final QE energies are not direct MALA energy predictions.
7. No new SCF, QE, MALA inference, density projection or FFT is authorized by this handoff. Existing curve data may be used to redraw manuscript figures.
8. If evidence is missing, omit the unsupported manuscript statement and list a focused question outside the LaTeX. **Do not invent values or insert “TBD”/placeholder prose.**

### Files to send with this handoff

- Original `QE_results_for_LaTeX_20261116.zip` for the existing report, figures and full production tables; apply the explicit exclusion.
- This Markdown file for the priority instructions, numerical reinjection results and availability distinctions.
- `QE_author_support_20261117.zip` for the newly supplied small raw records, configs, converter audits/source and reinjection logs. Its `SHA256.json` indexes copied file identities. It excludes huge densities, weight tensors, and wavefunctions. Server paths inside records are provenance paths, not proof of portability or instruction to execute them.

The supplement preserves the original experiments and does not change their numerical results. No new scientific job was launched during this availability audit.
